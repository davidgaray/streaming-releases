#!/usr/bin/env python3
"""resolve.py - match page (or player page) -> playable stream, driven by
../se-site/rules.json. Replaces the bash se-resolve (which now just execs
this) with the same --print contract build.py and relay_server.py parse:

    M3U8=<url>  REFERER=<url>  [ORIGIN=<origin>]  [EXPIRES=<epoch>]  [CHAIN=<type>]  [IFRAME=<url>]

How it works: fetch the start page, then walk its player iframes depth-first
(skipping the rules' iframe_exclude list). On every page, try each rule in
rules["chains"]: a rule whose `detect` regex matches the page is handed to
the code for its `type`. The patterns (variable names, token paths, hosts)
live in the rules file; only the mechanism per type lives here, so a
renamed variable or host is a rules edit, not a code change.

Exit codes - the failure *kind*, so callers can react differently:
    0 ok          stream resolved
    1 transient   network error / odd response; retry soon
    2 blocked     start page rate-limited or challenged (429/403/503)
    3 gone        the match has ended
    4 changed     page loaded fine but no rule matched its player chain
                  (a player type we don't support, or the site changed)
"""
import json, os, re, subprocess, sys, tempfile, time, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "se-site"))
import ratelimit  # noqa: E402  - shared with crawl.py
RULES_PATH = os.environ.get("SE_RULES") or os.path.join(HERE, "..", "se-site", "rules.json")
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
# Absolute path: under `su -c` root's PATH lacks Termux's bin dir and a bare
# "curl" silently resolves to nothing (TROUBLESHOOTING.md, 2026-10-18).
_TERMUX_CURL = "/data/data/com.termux/files/usr/bin/curl"
CURL = _TERMUX_CURL if os.path.exists(_TERMUX_CURL) else "curl"

OK, TRANSIENT, BLOCKED, GONE, CHANGED = 0, 1, 2, 3, 4


def log(msg):
    print(msg, file=sys.stderr)


class Fetcher:
    """curl, not urllib: Cloudflare 403s urllib's TLS fingerprint on these
    hosts (TROUBLESHOOTING.md, 2026-10-18). One cookie jar per resolve - the
    match page redirects through an SSO handoff that sets a session cookie."""

    def __init__(self):
        fd, self.jar = tempfile.mkstemp(prefix="se-resolve-cj-")
        os.close(fd)

    def get(self, url, referer=None, origin=None, timeout=25):
        if ratelimit.before(url) is not None:
            return 429, ""          # the site has us blocked; don't make it worse
        code, body = self._get(url, referer, origin, timeout)
        ratelimit.after(url, code, body)
        return code, body

    def _get(self, url, referer, origin, timeout):
        cmd = [CURL, "-sk", "-L", "--max-redirs", "10", "--max-time", str(timeout),
               "-A", UA, "-b", self.jar, "-c", self.jar, "-w", "\n%{http_code}"]
        if referer:
            cmd += ["-e", referer]
        if origin:
            cmd += ["-H", "Origin: " + origin]
        try:
            out = subprocess.run(cmd + [url], capture_output=True, timeout=timeout + 5).stdout
        except Exception as e:
            return 0, f"ERR {e}"
        body, _, code = out.decode("utf-8", "replace").rpartition("\n")
        return int(code) if code.isdigit() else 0, body

    def close(self):
        try:
            os.remove(self.jar)
        except OSError:
            pass


def origin_of(url):
    p = urllib.parse.urlsplit(url)
    return f"{p.scheme}://{p.netloc}"


def first(regex, text):
    m = re.search(regex, text)
    return m.group(1) if m else None


def player_iframes(html, page_url, exclude):
    out = []
    for tag in re.findall(r"<iframe\b[^>]*>", html, re.I):
        m = re.search(r"""(?<![\w-])src\s*=\s*["']([^"']+)["']""", tag, re.I)
        if not m:
            continue
        src = m.group(1).replace("&amp;", "&").strip()
        if src.startswith("//"):
            src = "https:" + src
        elif src.startswith("/"):
            src = origin_of(page_url) + src
        if src.startswith(("http://", "https://")) and not re.search(exclude, src, re.I) and src not in out:
            out.append(src)
    return out


# --- chain types: the mechanism; rules supply the patterns -----------------

def chain_hls_php(rule, html, page_url, fetch):
    hls = first("(" + rule["hls_url"] + ")", html)
    if not hls:
        return None
    if hls.startswith("//"):
        hls = "https:" + hls
    code, body = fetch.get(hls, referer=page_url)
    url = first(rule["stream_url"], body) if code == 200 else None
    if not url:
        log(f"    hls.php HTTP {code}, no stream url")
        return None
    return {"M3U8": url.replace("\\u0026", "&"), "REFERER": origin_of(page_url)}


def chain_edge_token(rule, html, page_url, fetch):
    src, edge, chan = first(rule["src"], html), first(rule["edge"], html), first(rule["channel"], html)
    if not src and edge and chan:
        src = f"{edge}/{chan}/index.m3u8"
    if not src:
        return None
    org = origin_of(page_url)
    out = {"M3U8": src, "REFERER": org + "/", "ORIGIN": org}
    if not (edge and chan):
        return out
    path = first(rule["token_path"], html) or rule["token_path_default"]
    code, body = fetch.get(edge + path + urllib.parse.quote(chan, safe=""), referer=org + "/", origin=org)
    try:
        j = json.loads(body)
        tok = j[rule["token_field"]]
        ttl = int(j.get(rule["ttl_field"]) or rule["ttl_default"])
    except Exception:
        log(f"    token request HTTP {code}: {body[:120]!r}")
        return out
    sep = "&" if "?" in src else "?"
    out["M3U8"] = f"{src}{sep}t={urllib.parse.quote(tok, safe='')}&_={int(time.time() * 1000)}"
    out["EXPIRES"] = str(int(time.time()) + ttl - 10)
    return out


def chain_vttp(rule, html, page_url, fetch):
    if rule.get("require") and not re.search(rule["require"], html):
        return None
    return {"M3U8": page_url, "REFERER": origin_of(page_url) + "/", "CHAIN": "vttp"}


CHAIN_TYPES = {"hls_php": chain_hls_php, "edge_token": chain_edge_token, "vttp": chain_vttp}


def try_chains(rules, html, page_url, fetch):
    for rule in rules["chains"]:
        if not re.search(rule["detect"], html):
            continue
        impl = CHAIN_TYPES.get(rule["type"])
        if impl is None:
            log(f"  rule {rule['name']}: unknown type {rule['type']!r} (needs a code update)")
            continue
        log(f"  {rule['name']} chain on {page_url}")
        res = impl(rule, html, page_url, fetch)
        if res:
            return res
    return None


def walk(rules, html, page_url, fetch, depth, seen):
    res = try_chains(rules, html, page_url, fetch)
    if res or depth >= rules.get("max_depth", 4):
        return res
    for child in player_iframes(html, page_url, rules["iframe_exclude"]):
        if child in seen:
            continue
        seen.add(child)
        code, body = fetch.get(child, referer=origin_of(page_url) + "/")
        log(f"  [{depth + 1}] {child}  HTTP {code}")
        if code == 200 and body:
            res = walk(rules, body, child, fetch, depth + 1, seen)
            if res:
                return res
    return None


def verify(res, fetch):
    """The manifest must actually answer with a playlist."""
    if res.get("CHAIN") == "vttp":
        return True      # playlists come over the relay's websocket, nothing to fetch here
    code, body = fetch.get(res["M3U8"], referer=res["REFERER"], origin=res.get("ORIGIN"))
    if "#EXTM3U" in body[:200]:
        return True
    log(f"  manifest HTTP {code}, not a playlist: {body[:120]!r}")
    return False


def resolve(start_url):
    """(exit code, result dict or None)"""
    with open(RULES_PATH, encoding="utf-8") as f:
        rules = json.load(f)
    fetch = Fetcher()
    try:
        log(f"[resolve] {start_url}  (rules {rules.get('version')})")
        code, html = fetch.get(start_url, referer=start_url)
        # While rate-limited the site can answer 429 with the real page still in
        # the body, so gate on content, not just the status.
        if "<iframe" not in html:
            if code in (403, 429, 503):
                log(f"  start page HTTP {code} - rate-limited or challenged")
                return BLOCKED, None
            if code != 200 or not html:
                log(f"  start page HTTP {code}")
                return TRANSIENT, None
        if re.search(rules["crawl"]["ended"], html):
            log("  match has ended")
            return GONE, None
        res = walk(rules, html, start_url, fetch, 0, {start_url})
        frames = player_iframes(html, start_url, rules["iframe_exclude"])
        if not res:
            log(f"  no rule matched the player chain (first player iframe: {frames[0] if frames else '<none>'})")
            return CHANGED, None
        if frames:
            res["IFRAME"] = frames[0]     # se-resolve --browse opens this
        return (OK, res) if verify(res, fetch) else (TRANSIENT, None)
    finally:
        fetch.close()


def main(argv):
    args = [a for a in argv if not a.startswith("--")]
    mode = next((a for a in argv if a.startswith("--")), "")
    if not args:
        log(f"usage: {argv[0] if argv else 'resolve.py'} <match-or-player-url> [--print]")
        return 2
    code, res = resolve(args[0])
    if code != OK:
        return code
    if mode == "--print":
        for k in ("M3U8", "REFERER", "ORIGIN", "EXPIRES", "CHAIN", "IFRAME"):
            if res.get(k):
                print(f"{k}={res[k]}")
    else:
        print(res["M3U8"])
    return OK


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
