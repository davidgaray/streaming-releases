#!/usr/bin/env bash
# refresh-loop.sh — repeatedly crawl + rebuild the live-games board so dist/
# stays current on its own: newly-live games appear, ended ones drop off,
# without anyone running anything by hand.
#
# Each cycle is a full crawl.py run from scratch (not a merge with the
# previous site.json) - that's what makes "remove when inactive" free: a
# game that's no longer found live simply isn't in the new output. Combined
# with crawl.py's own mirror health-check (fastest working mirror wins each
# cycle, not a hardcoded fixed order), this also self-heals if today's
# "best" mirror goes down between cycles.
#
# The wait between cycles is adaptive, based on build.py's own
# data/resolve_status.json (resolved vs total_live games this cycle) -
# confirmed live 2026-10-02, a game stuck on the browser-only fallback
# otherwise just sits there for a full fixed interval before the next real
# attempt, with no way back into VLC in the meantime:
#   - everything resolved (or nothing was live to resolve) -> normal $INTERVAL
#   - a few games still stuck, most resolved fine -> retry soon (30s) - a
#     small sample failing looks like a per-game hiccup worth chasing fast
#   - 0 resolved out of 3+ live games -> back off to 2x $INTERVAL instead of
#     retrying faster - that pattern looks like rate-limiting (see
#     README.md "mirrors 429 aggressively"), and hammering it harder on
#     purpose would make that worse, not better
#
# Usage: ./refresh-loop.sh [interval_seconds]   (default 180 = 3 min)
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INTERVAL="${1:-180}"
LOG="$HERE/refresh-loop.log"
PY="${PYTHON:-python3}"

log() { echo "[$(date +%H:%M:%S)] $*" | tee -a "$LOG"; }

# Each cycle's exit codes and durations, for notify.py: a crawl or build
# that crashes every cycle used to be invisible (the traceback went to this
# log and nothing read it; build.py kept rebuilding from the old site.json,
# so the board looked fine). Written beside + renamed so a reader never sees
# a half-written file.
STATUS="$HERE/data/cycle_status.json"
write_status() {
  mkdir -p "$HERE/data"
  printf '{"ts": %d, "crawl_rc": %d, "build_rc": %d, "crawl_s": %d, "build_s": %d}\n' \
    "$(date +%s)" "$1" "$2" "$3" "$4" > "$STATUS.tmp" && mv -f "$STATUS.tmp" "$STATUS"
}

log "refresh loop starting (pid $$), interval=${INTERVAL}s, log=$LOG"
while :; do
  log "crawling…"
  T0=$(date +%s)
  "$PY" "$HERE/crawl.py" >> "$LOG" 2>&1; CRAWL_RC=$?
  T1=$(date +%s)
  [[ $CRAWL_RC -ne 0 ]] && log "crawl.py exited $CRAWL_RC"
  log "building…"
  "$PY" "$HERE/build.py" >> "$LOG" 2>&1; BUILD_RC=$?
  T2=$(date +%s)
  [[ $BUILD_RC -ne 0 ]] && log "build.py exited $BUILD_RC"
  write_status "$CRAWL_RC" "$BUILD_RC" $((T1 - T0)) $((T2 - T1))
  read -r N_LIVE RESOLVED TOTAL_LIVE <<< "$("$PY" -c "
import json
try:
    d = json.load(open('$HERE/data/site.json'))
    n_live = sum(1 for g in d.get('games', []) if g.get('live'))
except Exception:
    n_live = '?'
try:
    r = json.load(open('$HERE/data/resolve_status.json'))
    resolved, total_live = r.get('resolved', 0), r.get('total_live', 0)
except Exception:
    resolved, total_live = 0, 0
print(n_live, resolved, total_live)
")"
  if [[ "$TOTAL_LIVE" -eq 0 || "$RESOLVED" -eq "$TOTAL_LIVE" ]]; then
    NEXT_SLEEP="$INTERVAL"
    REASON="all resolved (or nothing live to resolve)"
  elif [[ "$RESOLVED" -eq 0 && "$TOTAL_LIVE" -ge 3 ]]; then
    NEXT_SLEEP=$((INTERVAL * 2))
    REASON="0/$TOTAL_LIVE resolved - looks rate-limited, backing off"
  else
    NEXT_SLEEP=30
    REASON="$RESOLVED/$TOTAL_LIVE resolved - retrying the rest soon"
  fi
  log "cycle done — $N_LIVE live now. $REASON. sleeping ${NEXT_SLEEP}s"
  sleep "$NEXT_SLEEP"
done
