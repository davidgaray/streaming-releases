#!/usr/bin/env python3
"""
crawl.py — walk a Streams East mirror home page, pull every match card, and for
each LIVE match extract the stable player-iframe URL (streame.center/.../chNN.php).

Output:  data/site.json  (consumed by build.py)

Design notes
------------
* Match URLs are stable; the final m3u8 tokens are not. We stop at the
  chNN.php player page — it is per-game, no token, and the browser sends the
  Referer automatically when we open it. That is what "Play" links to.
* The mirror home can 429 aggressively. We rotate mirrors and back off.
* The card markup varies by mirror build; we match on the classes we saw in
  the portal (match-card / match-title-link / sports-matches-list) plus the
  universal signal: any <a> whose href is a real game path (/sport/slug-N/).
"""
import json, os, re, subprocess, sys, tempfile, time

import fsutil, ratelimit
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "data")
os.makedirs(DATA_DIR, exist_ok=True)

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")

MIRRORS_FILE = os.path.join(HERE, "mirrors.txt")


def load_mirrors():
    """Mirrors live in mirrors.txt, not hardcoded here, specifically so a
    mirror rotation - or the site moving to new domains entirely - is a
    one-line file edit instead of a code change. Re-read fresh every call,
    which in practice means every crawl cycle (crawl.py runs as a new
    subprocess each time - see refresh-loop.sh), so an edit takes effect on
    the next cycle with no restart needed."""
    if not os.path.exists(MIRRORS_FILE):
        sys.exit(f"no mirrors file: {MIRRORS_FILE} - create it, one mirror URL per line")
    mirrors = []
    with open(MIRRORS_FILE, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith("#"):
                mirrors.append(line)
    if not mirrors:
        sys.exit(f"{MIRRORS_FILE} has no mirror URLs in it")
    return mirrors


# Site markers come from rules.json (pushed remotely - see resolver/README.md)
# so a renamed attribute is a rules edit; the defaults here are what the site
# used when this was written, and keep the crawler working if the file is
# missing or broken.
RULES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rules.json")
try:
    with open(RULES_FILE, encoding="utf-8") as _f:
        RULES = json.load(_f)
except Exception as _e:
    print(f"[crawl] rules.json unreadable ({_e}) - using built-in markers", file=sys.stderr)
    RULES = {}


def _rule(key, default):
    return (RULES.get("crawl") or {}).get(key, default)


# Mirrors to try. The crawler stops at the first one that yields cards, in
# health-ranked (fastest-working-first) order - see rank_mirrors() below.
MIRRORS = load_mirrors()

# A "game" link on a mirror home looks like /nfl/colts-vs-chiefs-1/ or
# /f1/qatar-airways-azerbaijan-grand-prix-f1-fp2-401839109/. Capture the slug
# so we can normalise + de-dupe across mirrors.
# NFL matchups have no trailing numeric id ("/nfl/team-a-vs-team-b/"), so the
# numbered form alone drops them - the m-card__link class catches those.
GAME_LINK_RE = re.compile(
    r'class="m-card__link"\s+href="(?P<card>/[a-z0-9-]+/[a-z0-9][a-z0-9-]*/)"'
    r'|href="(?P<href>/[a-z0-9-]+/[a-z0-9][a-z0-9-]*-\d+/)"', re.I)
TITLE_RE = re.compile(
    r'class="[^"]*match-title[^"]*"[^>]*>(?:\s*<[^>]+>)*\s*(?P<t>[^<]+?)\s*<', re.I)

# Primary liveness signal: the explicit data-state attribute the page itself
# sets. Confirmed live 2026-11-02 against a currently-live NHL match: this is
# present and accurate ("live"/"ended"/"finished") even now that the embed
# chain below it has moved to a JS-rendered/SSO-gated player the static HTML
# never exposes - keying liveness off *that* (LIVE_IFRAME_RE below) silently
# mislabeled every game on the new chain as not-live, which is the actual
# root cause of the "all unhealthy" board symptom. class="se-ended" was
# dropped from the ended check the same day - confirmed it matches on a page
# that is very much still live (a template/CSS artifact present regardless
# of actual state, not a reliable per-game signal).
LIVE_STATE_RE = re.compile(_rule("live_state", r'data-state="live"'), re.I)
ENDED_RE = re.compile(_rule("ended", r'data-state="(?:ended|finished)"'), re.I)
# Secondary/best-effort: the old direct player-iframe URL, kept for games
# still on that chain (gives build.py's "Play (browser)" fallback a real
# link) but domain-agnostic now - matched by path shape (ch<N>.php) instead
# of a specific hostname, since the embed domain itself has already been
# renamed once (streame*.center -> dembed.st) and will likely be renamed
# again. Absence of a match is NOT treated as "not live" any more - see
# resolve_player_iframe() below.
LIVE_IFRAME_RE = re.compile(
    r'https?://[a-z0-9.-]+/(?:stream-east/)?ch[0-9]+\.php', re.I)

# The player itself: the first iframe on the match page that isn't one of
# the page's own utility frames. Recorded as g["player"] so build.py and the
# relay resolve streams starting from the player page, never re-fetching the
# match page - the mirror 429s bursts, and build.py runs right after this
# crawl has just fetched every match page (confirmed 2026-11-02: a build
# resolving 20 games straight off the mirror got 20 rate-limited empty pages).
# The player host doesn't care about Referer (checked: 200 with none).
IFRAME_TAG_RE = re.compile(r'<iframe\b[^>]*>', re.I)
IFRAME_SRC_RE = re.compile(r'''(?<![\w-])src\s*=\s*["']([^"']+)["']''', re.I)
NOT_PLAYER_RE = re.compile(RULES.get("iframe_exclude", r'about:blank|sso-frame|chat|twitch\.tv|^javascript:'), re.I)


# Premium-only ("Pro") games: the page's player is a paywall, not a stream.
# Checked 2026-11-03 on a live WTA event: the player root is
# data-state="gate" with the site's own showProGate: true flag, its
# background is /img/premium-gate/..., there is no player iframe, and every
# listed source is a crown-marked pro source. Free games show
# showProGate: false (and data-state "countdown"/"live").
GATE_STATE_RE = re.compile(_rule("gate_state", r'data-state="gate"'), re.I)
PRO_GATE_RE = re.compile(_rule("pro_gate", r'showProGate\s*:\s*true'), re.I)
TIME_UNTIL_START_RE = re.compile(_rule("time_until_start", r'timeUntilStart\s*:\s*(-?\d+)'))


def classify_match_page(body):
    """(live, player_url, premium) for a fetched match page. premium is
    None for a free game, else "live" (already started) or "upcoming"."""
    if ENDED_RE.search(body):
        return False, None, None
    if GATE_STATE_RE.search(body) and PRO_GATE_RE.search(body):
        m = TIME_UNTIL_START_RE.search(body)
        started = m is not None and int(m.group(1)) <= 0
        return False, None, "live" if started else "upcoming"
    if LIVE_STATE_RE.search(body):
        return True, player_iframe(body), None
    # No explicit data-state at all (older page variant?) - fall back to the
    # legacy chNN.php iframe as the only signal we have.
    m = LIVE_IFRAME_RE.search(body)
    return (True, m.group(0), None) if m else (False, None, None)


def player_iframe(body):
    for tag in IFRAME_TAG_RE.findall(body):
        m = IFRAME_SRC_RE.search(tag)
        if not m:
            continue
        src = m.group(1).replace("&amp;", "&").strip()
        if src.startswith("//"):
            src = "https:" + src
        if src.startswith(("http://", "https://")) and not NOT_PLAYER_RE.search(src):
            return src
    return None


# Shelled out to curl, not urllib - confirmed live 2026-10-18 that Cloudflare's
# bot-management 403s urllib's request on this exact URL ("Just a moment...",
# their JS-challenge interstitial - urllib/OpenSSL's TLS fingerprint reads as
# a scraper) while curl's fingerprint sails through untouched on the very same
# network path (same device, same VPN), no special flags needed beyond a
# cookie jar. See docs/TROUBLESHOOTING.md ("urllib gets Cloudflare-challenged,
# curl doesn't - same request, same network").
#
# A persistent on-disk cookie jar, reused for every http_get() call in this
# process, is required too and is a *separate* issue from the above - the
# mirror home sits behind an SSO handoff (v2.streameast.ga -> 302 ->
# auth.streamea.st/SsoHandoff.php?... -> 302 back with a session cookie set on
# the first hop); a cookie-less request (or a fresh jar per call) dead-ends on
# the first redirect with an empty body. curl -L with -c/-b pointed at the same
# jar file gets a real 200 in 3 redirects.
_COOKIE_JAR = os.path.join(DATA_DIR, ".curl_cookies.txt")
try:
    os.remove(_COOKIE_JAR)
except FileNotFoundError:
    pass

# Absolute path, not just "curl" - this runs fine when refresh-loop.sh invokes
# it (python3 on Termux's own PATH), but a plain "curl" silently resolves to
# nothing under e.g. `su -c` (root's PATH doesn't include Termux's bin dir),
# which looks exactly like a network failure (status 0) with no hint it's
# actually a PATH problem. Same reasoning as relay_server.py's own BASH
# constant for se-resolve.
_TERMUX_CURL = "/data/data/com.termux/files/usr/bin/curl"
CURL = _TERMUX_CURL if os.path.exists(_TERMUX_CURL) else "curl"


def http_get(url, referer=None, timeout=25):
    """GET with redirects followed; returns (final_status, body_text).
    Requests to the stream site go through ratelimit.py: spaced out, and
    while the site has us blocked this returns (429, "") without asking."""
    wait = ratelimit.before(url)
    if wait is not None:
        return 429, ""
    status, body = _curl_get(url, referer, timeout)
    ratelimit.after(url, status, body)
    return status, body


def _curl_get(url, referer, timeout):
    headers = [
        "-H", f"User-Agent: {UA}",
        "-H", "Accept: text/html,application/xhtml+xml",
        "-H", "Accept-Language: en-US,en;q=0.9",
    ]
    if referer:
        headers += ["-H", f"Referer: {referer}"]
    body_fd, body_path = tempfile.mkstemp(prefix="se-http-", dir=DATA_DIR)
    os.close(body_fd)
    try:
        result = subprocess.run(
            [CURL, "-sL", "-k", "-c", _COOKIE_JAR, "-b", _COOKIE_JAR,
             "-o", body_path, "-w", "%{http_code}",
             "--max-time", str(timeout), *headers, url],
            capture_output=True, text=True, timeout=timeout + 5,
        )
        status = int(result.stdout.strip()) if result.stdout.strip().isdigit() else 0
        with open(body_path, encoding="utf-8", errors="replace") as f:
            body = f.read()
        return status, body
    except Exception as e:
        return 0, f"ERR {e}"
    finally:
        try:
            os.remove(body_path)
        except OSError:
            pass


# Each game card's container is class="m-card ..."; live ones carry
# m-card--live (seen 2026-11-03 on the homepage's LIVE cards).
CARD_LIVE_CLASS = _rule("card_live_class", "m-card--live")
CARD_OPEN_RE = re.compile(r'class="(m-card(?:\s[^"]*)?)"', re.I)


def card_live_map(home_html):
    """slug -> True/False from the homepage's own live markers, or {} if the
    page has no recognisable cards (markup changed: caller must not trust it)."""
    out = {}
    opens = list(CARD_OPEN_RE.finditer(home_html))
    for i, m in enumerate(opens):
        chunk = home_html[m.end():opens[i + 1].start() if i + 1 < len(opens) else len(home_html)]
        link = GAME_LINK_RE.search(chunk)
        if link:
            slug = (link.group("card") or link.group("href")).rstrip("/").rsplit("/", 1)[-1]
            out.setdefault(slug, CARD_LIVE_CLASS in m.group(1).split())
    return out


def extract_games(home_html):
    """Return list of {href, slug, card_live} unique game links from a mirror
    home page. card_live is the homepage's own live marker, None if unknown."""
    cards = card_live_map(home_html)
    seen, games = set(), []
    for m in GAME_LINK_RE.finditer(home_html):
        href = m.group("card") or m.group("href")
        slug = href.rstrip("/").rsplit("/", 1)[-1]
        if slug in seen:
            continue
        seen.add(slug)
        games.append({"href": href, "slug": slug, "title": None, "card_live": cards.get(slug)})
    # Best-effort: pair a nearby match-title text with the first game we saw.
    titles = re.findall(r'class="[^"]*match-title[^"]*"[^>]*>(?:\s*<[^>]+>)*\s*([^<]+?)\s*<',
                        home_html, re.I)
    for i, g in enumerate(games):
        g["title"] = (titles[i].strip() if i < len(titles) else g["slug"].replace("-", " ").title())
    return games


def resolve_player_iframe(base, game_href, retries=1, retry_delay=2.0):
    """Given a match page, pull its live state, player iframe URL and
    premium-gate state (see classify_match_page()).
    Returns (live: bool|None, player_url: str|None, premium: str|None):
      - (True, url)   - confirmed live, iframe found in a real response.
      - (False, None) - confirmed NOT live: either a real response with no
        player iframe, or an explicit ENDED_RE match. We got a straight
        answer and it's negative.
      - (None, None)  - inconclusive: every attempt got a non-200 status
        (almost always 429), so we never actually got a page to check.
        Distinct from False on purpose - the caller can fall back to a
        game's last known state instead of wrongly reporting "not live"
        for a game we simply couldn't ask about this cycle.

    Mirrors 429 aggressively - confirmed live 2026-10-02, most per-game
    detail-page fetches in a single crawl run hit 429 on every one of several
    retries a couple seconds apart, and an *actual* 200 response with no
    iframe (a real "not live" answer) was being miscounted as inconclusive
    and retried pointlessly too, before this was split into three outcomes
    instead of two.
    """
    full = base.rstrip("/") + game_href if game_href.startswith("/") else game_href
    for attempt in range(retries + 1):
        status, body = http_get(full, referer=base)
        if status in (200, 301, 302):
            return classify_match_page(body)
        if attempt < retries:
            print(f"[crawl]   {status} (rate-limited?) for {game_href}, "
                  f"retry {attempt + 1}/{retries}…", file=sys.stderr)
            time.sleep(retry_delay)
    return None, None, None


def check_mirror_health(base, timeout=12):
    """One GET against a mirror home; returns a dict describing whether it's
    usable right now and how fast. Same 200+2000b heuristic crawl() already
    used to decide "is this a real page vs an error/challenge page" - kept
    identical so ranking and the actual crawl agree on what "ok" means."""
    t0 = time.time()
    status, body = http_get(base, timeout=timeout)
    latency = time.time() - t0
    ok = status == 200 and len(body) >= 2000
    return {"mirror": base, "ok": ok, "status": status, "bytes": len(body),
            "latency_s": round(latency, 2), "_body": body if ok else None}


def rank_mirrors(mirrors=MIRRORS, prev_health=None):
    """Health-check mirrors in last cycle's order (fastest working first)
    until one works; the rest are reported as not checked this cycle.

    Used to check every mirror every cycle, but they share one backend and
    one rate limit: 8 homepage hits + the crawl's own fetch + a match page
    per listed game every 3 minutes kept our own IP throttled for hours
    (2026-11-08). One working mirror is all a cycle needs."""
    order = list(mirrors)
    if prev_health:
        rank = {h["mirror"]: i for i, h in enumerate(prev_health) if h.get("ok")}
        pos = {m: i for i, m in enumerate(order)}   # not order.index(): sort() empties the list while it runs
        order.sort(key=lambda m: rank.get(m, len(rank) + pos[m]))
    results = []
    for m in order:
        if any(r["ok"] for r in results):
            results.append({"mirror": m, "ok": None, "status": None, "bytes": 0, "latency_s": None})
        else:
            results.append(check_mirror_health(m))
    return results


def _load_prev_health():
    try:
        with open(os.path.join(DATA_DIR, "site.json"), encoding="utf-8") as f:
            return json.load(f).get("mirror_health") or []
    except Exception:
        return []


def _load_prev_games():
    """Last cycle's games_by_slug, for carrying forward a game's last known
    live state across a purely-inconclusive crawl (see resolve_player_iframe's
    None vs False). Best-effort - a missing/corrupt/first-ever site.json just
    means nothing carries forward, not a crawl failure."""
    path = os.path.join(DATA_DIR, "site.json")
    try:
        with open(path, encoding="utf-8") as f:
            prev = json.load(f)
        return {g["slug"]: g for g in prev.get("games", [])}
    except Exception:
        return {}


def _prev_games_as_of():
    try:
        with open(os.path.join(DATA_DIR, "site.json"), encoding="utf-8") as f:
            prev = json.load(f)
        return prev.get("games_as_of") or prev.get("generated_at")
    except Exception:
        return None


def crawl():
    games_by_slug = {}
    live_used_mirror = None
    prev_by_slug = _load_prev_games()
    health = rank_mirrors(prev_health=_load_prev_health())
    bodies = {r["mirror"]: r.pop("_body", None) for r in health}
    for r in health:
        if r["ok"] is None:
            continue
        tag = "ok  " if r["ok"] else "bad "
        print(f"[health] {tag}{r['mirror']}  {r['status']}  {r['bytes']}b  {r['latency_s']}s",
              file=sys.stderr)
    ranked = [r["mirror"] for r in health if r["ok"]]
    for base in ranked:
        print(f"[crawl] {base}", file=sys.stderr)
        body = bodies.get(base) or ""
        status = 200 if body else http_get(base)[0]
        if status != 200 or len(body) < 2000:
            print(f"[crawl]   skip: HTTP {status}, {len(body)}b", file=sys.stderr)
            time.sleep(1.0)  # soft backoff
            continue
        games = extract_games(body)
        if not games:
            print(f"[crawl]   no game cards found in body", file=sys.stderr)
            time.sleep(1.0)
            continue
        print(f"[crawl]   {len(games)} game cards; probing live state…", file=sys.stderr)
        live_used_mirror = base
        idle_count = 0
        # Only open match pages that can change the board: games the homepage
        # marks live, plus ones that were live/premium-live last cycle (to see
        # them end). If no card carries a live marker at all, the homepage
        # markup may have changed - fall back to checking every game rather
        # than silently showing nothing live.
        markers = any(g["card_live"] is not None for g in games)
        blocked = 0
        for g in games:
            prev = prev_by_slug.get(g["slug"]) or {}
            worth_it = (not markers or g["card_live"] or prev.get("live")
                        or prev.get("premium") == "live")
            if not worth_it:
                live, player, premium = False, None, None
            elif blocked >= 3:
                # Rate-limited three times this cycle: stop asking, keep what we knew.
                live, player, premium = None, None, None
            else:
                live, player, premium = resolve_player_iframe(base, g["href"])
                blocked = blocked + 1 if live is None else 0
            carried = False
            if live is None:
                prev = prev_by_slug.get(g["slug"])
                premium = prev.get("premium") if prev else None
                if prev and prev.get("live"):
                    live, player, carried = True, prev.get("player"), True
                else:
                    live = False  # never confirmed live before - don't invent it
            g["live"] = live
            g["player"] = player
            g["premium"] = premium
            # Only log LIVE/carried games individually - idle games are the
            # overwhelming majority on any given cycle (dozens on a heavy
            # sports day) and printing one line each, every ~180s, is what
            # drove refresh-loop.log to ~1.5MB/4hrs - see docs/
            # GOLD_IMAGE_PLAN.md. A per-cycle count still shows the crawl is
            # alive without the per-idle-game noise.
            if carried or live:
                tag = "LIVE*" if carried else "LIVE "
                print(f"[crawl]   {tag} {g['slug']}"
                      + (f"  →  {player}" if player else ""), file=sys.stderr)
            elif premium == "live":
                print(f"[crawl]   LIVE (premium only) {g['slug']}", file=sys.stderr)
            else:
                idle_count += 1
            g["mirror_base"] = base.rstrip("/")
            g["url_in_site"] = base.rstrip("/") + g["href"]
            g["title"] = g["title"] or g["slug"].replace("-", " ").title()
            games_by_slug[g["slug"]] = g
        if idle_count:
            print(f"[crawl]   {idle_count} idle (not logged individually)", file=sys.stderr)
        # We found a working mirror + game list — that is enough; the other
        # mirrors would return the same slugs (they are mirrors).
        break
    games_as_of = None
    if not games_by_slug:
        print("[crawl] WARNING: no mirror returned a game list this run.", file=sys.stderr)
        blocked_for = ratelimit.status()
        if blocked_for:
            print("[crawl]         rate-limited; not asking again for "
                  + ", ".join(f"{k} {int(v)}s" for k, v in blocked_for.items()), file=sys.stderr)
        # Keep showing the last list we had rather than blanking the board -
        # a stream that's already playing doesn't need the site, and most
        # outages here are a temporary block. games_as_of marks it as old.
        if prev_by_slug:
            games_by_slug = prev_by_slug
            games_as_of = _prev_games_as_of()
            print(f"[crawl]         keeping the previous game list (from {games_as_of})", file=sys.stderr)

    # "down" vs "degraded" vs "ok" - a risk-analysis finding (2026-10-03,
    # see docs/GOLD_IMAGE_PLAN.md) is that this board has no signal anywhere
    # distinguishing "can't reach the internet at all" (VPN down, or no
    # network) from "mirrors reachable but legitimately nothing live" - both
    # looked identical. http_get() returns status 0 specifically for a
    # connection-level failure (timeout/refused/DNS/SSL - never even reached
    # a server), vs. a real status code for "reached a server, didn't like
    # the response" (429 rate-limit, a block/challenge page, etc.) - that
    # distinction is what separates these two states:
    #   down     - every mirror failed at the connection level - the
    #              strongest possible "no usable network path" signal
    #              (what you'd see if the VPN is down with lockdown on).
    #   degraded - every mirror failed its health check, but at least one
    #              got a real HTTP response - more ambiguous (could be a
    #              VPN-disconnected raw-traffic leak that mirrors reject,
    #              could just be mirrors coincidentally all rate-limiting
    #              at once), so build.py words this one more cautiously.
    if all(r["status"] == 0 for r in health):
        network_status = "down"
    elif all(not r["ok"] for r in health):
        network_status = "degraded"
    else:
        network_status = "ok"

    site = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "generator": "se-site/crawl.py",
        "mirrors": MIRRORS,
        "mirror_health": health,
        "network_status": network_status,
        "source_mirror": live_used_mirror,
        "games": list(games_by_slug.values()),
        "games_as_of": games_as_of,     # set when the list is carried over from an earlier crawl
    }
    out = os.path.join(DATA_DIR, "site.json")
    fsutil.write_json_atomic(out, site, indent=2, ensure_ascii=False)
    n_live = sum(1 for g in site["games"] if g.get("live"))
    print(f"[crawl] wrote {out}  ({len(site['games'])} games, {n_live} live)", file=sys.stderr)


if __name__ == "__main__":
    t0 = time.time()
    crawl()
    print(f"[crawl] done in {time.time()-t0:.1f}s", file=sys.stderr)
