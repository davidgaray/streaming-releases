#!/usr/bin/env bash
# watchdog.sh — supervises refresh-loop.sh and relay_server.py, restarting
# whichever one dies. This is now the ONE thing to launch (via Termux's
# RUN_COMMAND service, same as the two it supervises - see README "What's
# running on-device") - it starts both children itself if they aren't up yet,
# then polls forever.
#
# Why this exists: both children have been confirmed (see README "The relay
# had to stream..." and firestick-build/docs/TROUBLESHOOTING.md) to die
# silently with no crash trace - the process just stops showing up in `ps`,
# nothing in their own log explains why (suspected low-memory killer). A
# process can also stay resident but wedged rather than disappear, so the
# relay side gets a real HTTP check, not just a liveness check.
#
# Usage: ./watchdog.sh [refresh_interval_s] [relay_port] [check_interval_s]
set -u
# HERE is the *logical* path (pwd, not pwd -P): invoked as
# ~/streaming/current/se-site/watchdog.sh it stays "current/se-site", so
# after updater.py flips the `current` symlink, every $HERE/... below
# resolves into the new release - restarted children run the new code.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REFRESH_INTERVAL="${1:-180}"
PORT="${2:-8080}"
CHECK_INTERVAL="${3:-60}"
PY="${PYTHON:-python3}"
# State shared across releases lives in ~/streaming/state (see updater.py);
# the legacy flat layout (~/streaming/se-site) keeps it next to the code.
ROOT="$(dirname "$HERE")"
[[ -L "$ROOT" ]] && ROOT="$(dirname "$ROOT")"
STATE_DIR="$ROOT/state"
[[ -d "$STATE_DIR" ]] || STATE_DIR="$HERE"
LOG="$HERE/watchdog.log"
LOCKDIR="$STATE_DIR/.watchdog.lock"
RELAY_LOG="$HERE/relay.log"
REFRESH_LOG="$HERE/refresh-loop.log"
UPDATER_LOG="$STATE_DIR/updater.log"

# Caps all three of this supervisor's log files (its own, relay_server.py's
# stdout/stderr, and refresh-loop.sh's own log). Confirmed live 2026-10-03:
# refresh-loop.log alone hit ~1.5MB / 25k lines in ~4hrs on a heavy crawl day
# (one line per idle game, every cycle - see crawl.py) with nothing ever
# capping it - see docs/GOLD_IMAGE_PLAN.md. Truncates the file IN PLACE
# (`cat tmp > "$f"`, same inode) rather than renaming a replacement over it -
# relay_server.py and refresh-loop.sh hold their log fds open in append
# mode for their whole run, and only an in-place truncate is safe for an
# open O_APPEND writer (a rename would orphan their fd on a now-nameless
# inode that silently keeps growing until they next restart).
MAX_LOG_BYTES=$((2 * 1024 * 1024))
LOG_KEEP_BYTES=$((400 * 1024))
rotate_if_big() {
  local f="$1" size
  [[ -f "$f" ]] || return 0
  size=$(wc -c < "$f" 2>/dev/null) || return 0
  if (( size > MAX_LOG_BYTES )); then
    tail -c "$LOG_KEEP_BYTES" "$f" > "$f.keep" 2>/dev/null && cat "$f.keep" > "$f"
    rm -f "$f.keep"
    log "rotated $(basename "$f") (was ${size} bytes, kept last ${LOG_KEEP_BYTES})"
  fi
}

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "$LOG"; }

# Refuse to run two supervisors at once - both would race to restart the
# same children. Confirmed live 2026-10-03: something (most likely Android
# restarting Termux's backgrounded RunCommandService after it gets killed
# under memory pressure, since this is launched via RUN_COMMAND_BACKGROUND
# true, not a real foreground service) re-fires this launch every few
# minutes on its own, with no new RUN_COMMAND call from us - found 3 live
# watchdog.sh processes at once, 2 of them having each independently started
# one of the two children. A plain "check file, then write file" lock has a
# TOCTOU race that two simultaneous launches can both slip through (both
# see no lock yet, both proceed). `mkdir` is atomic at the filesystem level -
# exactly one concurrent caller can ever succeed - so use a lock *directory*
# instead of a lock file to actually close that race, however many times
# this script gets (re)launched.
if ! mkdir "$LOCKDIR" 2>/dev/null; then
  owner_pid="$(cat "$LOCKDIR/pid" 2>/dev/null)"
  if [[ -n "$owner_pid" ]] && kill -0 "$owner_pid" 2>/dev/null; then
    log "already running as pid $owner_pid — exiting"
    exit 1
  fi
  # Lock dir exists but its owner is dead (stale from a crash) - reclaim it.
  rm -rf "$LOCKDIR"
  if ! mkdir "$LOCKDIR" 2>/dev/null; then
    log "lost the race reclaiming a stale lock — exiting"
    exit 1
  fi
fi
echo $$ > "$LOCKDIR/pid"
trap 'rm -rf "$LOCKDIR"' EXIT

refresh_running() { pgrep -f 'refresh-loop\.sh' >/dev/null 2>&1; }
relay_running()   { pgrep -f 'relay_server\.py' >/dev/null 2>&1; }

start_refresh() {
  log "starting refresh-loop.sh (interval=${REFRESH_INTERVAL}s)"
  # Invoke via `bash <script>`, not `./refresh-loop.sh` - a direct exec relies
  # on the script's own `#!/usr/bin/env bash` shebang resolving, which needs
  # termux-exec's shebang-fixup hook. That hook isn't present when this
  # supervisor itself was launched via Termux's RUN_COMMAND service (confirmed
  # live 2026-10-01 - the same shebang works fine from an interactive Termux
  # session but silently fails, with zero trace, under RUN_COMMAND).
  # refresh-loop.sh's own log() already tees every line into refresh-loop.log
  # itself - redirecting our wrapper's stdout/stderr to that *same* file would
  # double every line (tee's direct write, plus this redirect catching tee's
  # passed-through copy). /dev/null here only drops a startup crash that
  # happens before refresh-loop.sh's log() runs, which is as good as nothing.
  #
  # `exec` inside the subshell (not `nohup cmd & disown`) - confirmed live
  # 2026-10-03: `disown` only actually detaches a background job when job
  # control is on, which a non-interactive script like this one doesn't have
  # by default. With disown silently a no-op, this subshell was reaching its
  # own end and implicitly wait()-ing on the child it had backgrounded -
  # forever, since that child (refresh-loop.sh) never exits on its own. Found
  # 2 of these permanently-stuck subshells still alive and attached to their
  # child minutes after launch (visible in `ps` as a phantom extra
  # "watchdog.sh" process parenting the real refresh-loop.sh/relay_server.py).
  # Harmless to function (the real children ran fine regardless) but a real
  # leaked process-table entry every restart. `exec` replaces the subshell's
  # own process image with the target instead of forking-then-waiting for
  # it - nothing left behind to get stuck.
  ( cd "$HERE" && exec nohup bash ./refresh-loop.sh "$REFRESH_INTERVAL" ) >> /dev/null 2>&1 &
}

start_relay() {
  log "starting relay_server.py (port=${PORT})"
  ( cd "$HERE" && exec nohup "$PY" relay_server.py "$PORT" ) >> "$RELAY_LOG" 2>&1 &
}

HEALTH_URL="http://127.0.0.1:${PORT}/health"

relay_healthy() {
  # A process can stay resident but wedged (see README's PCR/clock-desync
  # writeup) - only a real request tells us it's actually serving. /health is
  # the relay's own verdict; a 404 means a relay from before /health existed,
  # which still answered, so it's alive. Anything else (no answer, 5xx) isn't.
  local out code
  out="$(curl -s -m 5 -w $'\n%{http_code}' "$HEALTH_URL" 2>/dev/null)"
  code="${out##*$'\n'}"
  case "$code" in
    200) [[ "$out" == *'"ok": true'* ]] ;;
    404) return 0 ;;
    *)   return 1 ;;
  esac
}

relay_idle() {
  # True when nobody is watching: /health says no stream was polled in the
  # last 30s. A relay without /health is judged by its log instead - every
  # manifest poll writes a line, so a quiet relay.log means an idle relay.
  local out age
  out="$(curl -sf -m 5 "$HEALTH_URL" 2>/dev/null)"
  if [[ -n "$out" ]]; then
    [[ "$out" == *'"active_streams": 0'* ]]
    return
  fi
  age=$(( $(date +%s) - $(stat -c %Y "$RELAY_LOG" 2>/dev/null || echo 0) ))
  (( age > 45 ))
}

# "Restart the relay, but not while someone's watching." Anything that
# replaced relay code (the deploy script, the updater) touches this file
# with a one-line reason instead of killing the relay itself; the restart
# happens at the first idle check, or after FORCE_RESTART_AFTER_S regardless
# (a stream that's been going that long is a stuck VLC, not a game).
RESTART_MARKER="$HERE/.restart-relay"
FORCE_RESTART_AFTER_S=$((6 * 3600))

restart_relay() {
  log "restarting relay_server.py ($1)"
  pkill -f 'relay_server\.py' 2>/dev/null
  sleep 1
  start_relay
  rm -f "$RESTART_MARKER"
}

check_restart_request() {
  [[ -f "$RESTART_MARKER" ]] || return 0
  local reason age
  reason="$(head -c 200 "$RESTART_MARKER" 2>/dev/null)"
  age=$(( $(date +%s) - $(stat -c %Y "$RESTART_MARKER" 2>/dev/null || echo 0) ))
  if relay_idle; then
    restart_relay "requested: ${reason:-no reason given}"
  elif (( age > FORCE_RESTART_AFTER_S )); then
    restart_relay "requested ${age}s ago (${reason:-no reason given}); forcing despite an active stream"
  fi
}

# updater.py asks for this after installing a release (or rolling one back):
# refresh-loop restarts between cycles, the relay at the first idle moment,
# and this watchdog re-executes itself from $HERE - which, being the logical
# path through `current`, is now the new release.
RESTART_REQUEST="$STATE_DIR/restart-services"

check_services_restart_request() {
  [[ -f "$RESTART_REQUEST" ]] || return 0
  local reason i
  reason="$(head -c 200 "$RESTART_REQUEST" 2>/dev/null)"
  rm -f "$RESTART_REQUEST"
  log "services restart requested (${reason:-no reason}): refresh-loop now, relay when idle, then myself"
  echo "${reason:-services restart}" > "$HERE/.restart-relay"
  for i in $(seq 1 40); do
    tail -1 "$REFRESH_LOG" 2>/dev/null | grep -q "sleeping" && break
    sleep 5
  done
  pkill -f 'refresh-loop\.sh' 2>/dev/null
  sleep 1
  start_refresh
  rm -rf "$LOCKDIR"
  exec bash "$HERE/watchdog.sh" "$REFRESH_INTERVAL" "$PORT" "$CHECK_INTERVAL"
}

run_updater_tick() {
  # Quick when nothing is pending; a real install can take a minute, so it
  # runs detached. updater.py holds its own lock against overlapping runs.
  [[ -f "$HERE/updater.py" ]] || return 0
  ( cd "$HERE" && exec nohup "$PY" updater.py --tick ) >> "$UPDATER_LOG" 2>&1 &
}

log "watchdog starting (pid $$) — refresh_interval=${REFRESH_INTERVAL}s port=${PORT} check_interval=${CHECK_INTERVAL}s state=${STATE_DIR}"

refresh_running || start_refresh
relay_running   || start_relay

while :; do
  sleep "$CHECK_INTERVAL"

  rotate_if_big "$LOG"
  rotate_if_big "$RELAY_LOG"
  rotate_if_big "$REFRESH_LOG"
  rotate_if_big "$UPDATER_LOG"

  check_services_restart_request
  run_updater_tick

  if ! refresh_running; then
    log "refresh-loop.sh is DOWN — restarting"
    start_refresh
  fi

  if ! relay_running; then
    log "relay_server.py is DOWN — restarting"
    start_relay
    rm -f "$RESTART_MARKER"      # a fresh start already runs whatever code is on disk
  elif ! relay_healthy; then
    restart_relay "running but not answering on :${PORT}"
  else
    check_restart_request
  fi
done
