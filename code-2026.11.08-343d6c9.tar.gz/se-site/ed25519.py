"""ed25519.py - the reference Ed25519 in plain Python (no openssl, no pip).

Used to sign releases on the Mac (tools/release.py) and to verify them on
the stick (updater.py). Slow by design (~1s per verify on the stick), which
is irrelevant at one check every 30 minutes, and it has no dependencies on
either side - Termux's openssl build and macOS's LibreSSL disagree about
ed25519, and a dependency the updater can't satisfy is an updater that
can't update. Follows the original ed25519.py from the paper, with the
RFC 8032 clamping; test vectors in tests/test_updater.py.

    sk = os.urandom(32); pk = publickey(sk)
    sig = sign(message, sk, pk); verify(sig, message, pk) -> bool
"""
import hashlib

b = 256
q = 2 ** 255 - 19
l = 2 ** 252 + 27742317777372353535851937790883648493


def H(m):
    return hashlib.sha512(m).digest()


def inv(x):
    return pow(x, q - 2, q)


d = -121665 * inv(121666) % q
I = pow(2, (q - 1) // 4, q)


def xrecover(y):
    xx = (y * y - 1) * inv(d * y * y + 1)
    x = pow(xx, (q + 3) // 8, q)
    if (x * x - xx) % q != 0:
        x = (x * I) % q
    if x % 2 != 0:
        x = q - x
    return x


By = 4 * inv(5)
Bx = xrecover(By)
B = (Bx % q, By % q)


def edwards(P, Q):
    x1, y1 = P
    x2, y2 = Q
    x3 = (x1 * y2 + x2 * y1) * inv(1 + d * x1 * x2 * y1 * y2)
    y3 = (y1 * y2 + x1 * x2) * inv(1 - d * x1 * x2 * y1 * y2)
    return (x3 % q, y3 % q)


def scalarmult(P, e):
    Q = (0, 1)
    while e:
        if e & 1:
            Q = edwards(Q, P)
        P = edwards(P, P)
        e >>= 1
    return Q


def encodepoint(P):
    x, y = P
    return (y | ((x & 1) << 255)).to_bytes(32, "little")


def bit(h, i):
    return (h[i // 8] >> (i % 8)) & 1


def _clamp(h):
    return 2 ** (b - 2) + sum(2 ** i * bit(h, i) for i in range(3, b - 2))


def publickey(sk):
    return encodepoint(scalarmult(B, _clamp(H(sk))))


def Hint(m):
    return int.from_bytes(H(m), "little")


def sign(m, sk, pk):
    h = H(sk)
    a = _clamp(h)
    r = Hint(h[32:64] + m)
    R = scalarmult(B, r)
    S = (r + Hint(encodepoint(R) + pk + m) * a) % l
    return encodepoint(R) + S.to_bytes(32, "little")


def isoncurve(P):
    x, y = P
    return (-x * x + y * y - 1 - d * x * x * y * y) % q == 0


def decodepoint(s):
    y = int.from_bytes(s, "little") & ((1 << 255) - 1)
    x = xrecover(y)
    if x & 1 != bit(s, b - 1):
        x = q - x
    P = (x, y)
    if not isoncurve(P):
        raise ValueError("point not on curve")
    return P


def verify(s, m, pk):
    if len(s) != 64 or len(pk) != 32:
        return False
    try:
        R = decodepoint(s[:32])
        A = decodepoint(pk)
    except ValueError:
        return False
    S = int.from_bytes(s[32:64], "little")
    if S >= l:
        return False
    h = Hint(encodepoint(R) + pk + m)
    return scalarmult(B, S) == edwards(R, scalarmult(A, h))
