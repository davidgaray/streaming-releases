"""unwrap.py - undo transport wrappers some stream CDNs put around otherwise
ordinary HLS media segments, so a plain player (VLC) gets real media bytes.

relay_server.py calls unwrap_segment() on every segment it relays. Anything
it doesn't recognise comes back as None and is passed through untouched, so
an unwrapper only ever changes bytes it positively identified.

Known wrappers:

  PNG pixel wrapper (seen 2026-11-02 on the dembed.st / edge.*.top chain):
  each segment is a valid PNG served as image/png from an image CDN
  (*.tiktokcdn-us.com). Its decoded RGB pixel bytes are
      b"TIKTIKPX" | uint32 big-endian length n | n bytes of gzip | padding
  and the gzip member inflates to plain MPEG-TS. Format read from the site's
  own player (unwrapPixels/pngRGB in daddy.php), which checks the same magic,
  length, gzip header and TS sync byte this code does. The CDN re-encodes
  the PNG with all five PNG row filters in use, so the pixels have to be
  properly reconstructed - zlib-inflating the IDAT stream alone isn't enough.
"""
import gzip
import io
import json
import os
import struct
import zlib

try:  # optional: ~100x faster PNG decode (Termux: pkg install python-pillow)
    from PIL import Image
except ImportError:
    Image = None

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"
# The wrapper's magic is in rules.json (transport.png_magic) so a renamed
# marker is a rules push; the default is the one seen in Nov 2026. The relay
# runs for days, so it calls reload() periodically instead of restarting.
RULES_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rules.json")
_rules_mtime = None


def _magic():
    try:
        with open(RULES_PATH, encoding="utf-8") as f:
            return json.load(f)["transport"]["png_magic"].encode("ascii")
    except Exception:
        return b"TIKTIKPX"


def reload():
    """Re-read the magic if rules.json changed on disk. True when it did."""
    global TIKTIK_MAGIC, _rules_mtime
    try:
        mtime = os.stat(RULES_PATH).st_mtime
    except OSError:
        mtime = None
    if mtime == _rules_mtime:
        return False
    _rules_mtime = mtime
    before = globals().get("TIKTIK_MAGIC")
    TIKTIK_MAGIC = _magic()
    return before is not None and before != TIKTIK_MAGIC


TIKTIK_MAGIC = _magic()
reload()


def unwrap_segment(data):
    """Real media bytes if `data` is a recognised wrapper, else None."""
    if not data.startswith(PNG_MAGIC):
        return None
    rgb = png_rgb(data)
    m = len(TIKTIK_MAGIC)
    if rgb is None or len(rgb) < m + 4 or rgb[:m] != TIKTIK_MAGIC:
        return None
    n = int.from_bytes(rgb[m:m + 4], "big")
    if n <= 0 or m + 4 + n > len(rgb):
        return None
    gz = rgb[m + 4:m + 4 + n]
    if gz[:2] != b"\x1f\x8b":
        return None
    try:
        ts = gzip.decompress(gz)
    except (OSError, EOFError, zlib.error):
        return None
    return ts if ts[:1] == b"\x47" else None


def png_rgb(data):
    """Decoded pixel bytes of an 8-bit RGB/RGBA PNG as packed RGB (alpha
    dropped), or None for anything else."""
    if Image is not None:
        try:
            return Image.open(io.BytesIO(data)).convert("RGB").tobytes()
        except Exception:
            return None
    return _png_rgb_pure(data)


def _png_rgb_pure(data):
    pos, end = 8, len(data)
    w = h = 0
    depth = ctype = interlace = None
    idat = []
    while pos + 8 <= end:
        ln = int.from_bytes(data[pos:pos + 4], "big")
        typ = data[pos + 4:pos + 8]
        if pos + 12 + ln > end:
            return None
        if typ == b"IHDR":
            w, h, depth, ctype, _, _, interlace = struct.unpack(">IIBBBBB", data[pos + 8:pos + 21])
        elif typ == b"IDAT":
            idat.append(data[pos + 8:pos + 8 + ln])
        elif typ == b"IEND":
            break
        pos += 12 + ln
    if not w or not h or depth != 8 or interlace or ctype not in (2, 6):
        return None
    try:
        raw = zlib.decompress(b"".join(idat))
    except zlib.error:
        return None
    bpp = 4 if ctype == 6 else 3
    stride = w * bpp
    if len(raw) < h * (stride + 1):
        return None

    # Up and Sub are byte-wise mod-256 adds, done on whole rows at once as big
    # integers with the carries masked off between bytes (SWAR). Average and
    # Paeth depend non-linearly on the pixel to the left, so they stay
    # byte-at-a-time.
    lo = int.from_bytes(b"\x7f" * stride, "big")
    hi = int.from_bytes(b"\x80" * stride, "big")

    def add(a, b):
        return ((a & lo) + (b & lo)) ^ ((a ^ b) & hi)

    out = bytearray()
    prev = bytes(stride)
    off = 0
    for _ in range(h):
        f = raw[off]
        row = raw[off + 1:off + 1 + stride]
        off += 1 + stride
        if f == 0:
            recon = row
        elif f == 1:
            x = int.from_bytes(row, "big")
            shift = bpp
            while shift < stride:
                x = add(x, x >> (shift * 8))
                shift *= 2
            recon = x.to_bytes(stride, "big")
        elif f == 2:
            recon = add(int.from_bytes(row, "big"), int.from_bytes(prev, "big")).to_bytes(stride, "big")
        elif f == 3:
            recon = bytearray(stride)
            for i in range(bpp):
                recon[i] = (row[i] + (prev[i] >> 1)) & 255
            for i in range(bpp, stride):
                recon[i] = (row[i] + ((recon[i - bpp] + prev[i]) >> 1)) & 255
        elif f == 4:
            recon = bytearray(stride)
            for i in range(bpp):
                recon[i] = (row[i] + prev[i]) & 255
            for i in range(bpp, stride):
                a = recon[i - bpp]
                b = prev[i]
                c = prev[i - bpp]
                pa = b - c
                pb = a - c
                pc = pa + pb
                if pa < 0:
                    pa = -pa
                if pb < 0:
                    pb = -pb
                if pc < 0:
                    pc = -pc
                if pa <= pb and pa <= pc:
                    recon[i] = (row[i] + a) & 255
                elif pb <= pc:
                    recon[i] = (row[i] + b) & 255
                else:
                    recon[i] = (row[i] + c) & 255
        else:
            return None
        if bpp == 3:
            out += recon
        else:
            del_alpha = bytearray(recon)
            del del_alpha[3::4]
            out += del_alpha
        prev = recon
    return bytes(out)
