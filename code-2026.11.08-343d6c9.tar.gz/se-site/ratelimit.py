"""ratelimit.py - one per-site request budget shared by crawl.py and
resolve.py (separate processes), plus a circuit breaker kept on disk.

Most of the 429/1015 blocks we've had were self-inflicted: the crawler,
build and relay re-resolves each hammered the mirror on their own schedule,
and kept going while blocked, which extends a Cloudflare block. So:

  - requests to a rate-limited site (rules.json rate_limit.hosts) are spaced
    at least min_interval_s apart, across every process on the stick;
  - a 429 / Cloudflare 1015 opens the breaker for that site: no requests at
    all for backoff_base_s, doubling per repeat (+-20% jitter) up to
    backoff_max_s. After that one probe goes through; success closes it.

Hosts are grouped by their last two labels (www./v2.streameast.ga are one
site - Cloudflare counts them together). Players and CDNs aren't throttled.

    wait = before(url)       # None: go ahead (may have slept); else seconds still blocked
    after(url, status, body) # record the outcome
"""
import fcntl, json, os, random, re, time, urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
STATE = os.path.join(DATA, "ratelimit.json")
DEFAULTS = {"hosts": "streameast", "min_interval_s": 1.5,
            "backoff_base_s": 120, "backoff_max_s": 1800}


def _cfg():
    try:
        with open(os.path.join(HERE, "rules.json"), encoding="utf-8") as f:
            return {**DEFAULTS, **json.load(f).get("rate_limit", {})}
    except Exception:
        return dict(DEFAULTS)


CFG = _cfg()


def site_of(url):
    host = (urllib.parse.urlsplit(url).hostname or "").lower()
    if not re.search(CFG["hosts"], host):
        return None
    return ".".join(host.split(".")[-2:])


class _Locked:
    """Read-modify-write of the state file under an exclusive lock."""

    def __enter__(self):
        os.makedirs(DATA, exist_ok=True)
        self.fd = os.open(STATE + ".lock", os.O_CREAT | os.O_RDWR, 0o600)
        fcntl.flock(self.fd, fcntl.LOCK_EX)
        try:
            with open(STATE, encoding="utf-8") as f:
                self.st = json.load(f)
        except Exception:
            self.st = {}
        return self.st

    def __exit__(self, *exc):
        tmp = STATE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.st, f)
        os.replace(tmp, STATE)
        fcntl.flock(self.fd, fcntl.LOCK_UN)
        os.close(self.fd)


def before(url):
    site = site_of(url)
    if site is None:
        return None
    with _Locked() as st:
        s = st.setdefault(site, {})
        now = time.time()
        if s.get("blocked_until", 0) > now:
            return s["blocked_until"] - now
        # Reserve the next slot, then sleep outside the lock.
        slot = max(now, s.get("next_ok", 0))
        s["next_ok"] = slot + CFG["min_interval_s"]
    if slot > now:
        time.sleep(slot - now)
    return None


def is_block(status, body):
    if status == 429:
        return True
    return status in (403, 503) and bool(re.search(r"error code: 10\d\d|cf-chl|Just a moment", body[:4000]))


def after(url, status, body=""):
    site = site_of(url)
    if site is None or status == 0:
        return
    with _Locked() as st:
        s = st.setdefault(site, {})
        if is_block(status, body):
            s["strikes"] = s.get("strikes", 0) + 1
            delay = min(CFG["backoff_base_s"] * 2 ** (s["strikes"] - 1), CFG["backoff_max_s"])
            s["blocked_until"] = time.time() + delay * random.uniform(0.8, 1.2)
            s["last_block_status"] = status
        elif status < 400:
            s["strikes"] = 0
            s.pop("blocked_until", None)


def status():
    """{site: seconds still blocked} for sites whose breaker is open."""
    try:
        with open(STATE, encoding="utf-8") as f:
            st = json.load(f)
    except Exception:
        return {}
    now = time.time()
    return {k: v["blocked_until"] - now for k, v in st.items() if v.get("blocked_until", 0) > now}
