"""fsutil.py - atomic file writes for everything another process watches.

notify.py judges the board by file mtimes and contents (site.json,
resolve_status.json, dist/index.html). A plain open(path, "w") truncates
first and fills later, so a crash mid-write leaves a fresh-looking empty or
half file that reads as "fine" to a watcher. Write beside, then rename: the
reader sees either the old file or the complete new one.
"""
import json, os


def write_atomic(path, data, encoding="utf-8"):
    """Write str or bytes to path via a temp file + rename."""
    tmp = f"{path}.{os.getpid()}.tmp"
    mode = "wb" if isinstance(data, (bytes, bytearray)) else "w"
    try:
        with open(tmp, mode, **({} if mode == "wb" else {"encoding": encoding})) as f:
            f.write(data)
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass


def write_json_atomic(path, obj, **dump_kw):
    write_atomic(path, json.dumps(obj, **dump_kw))
