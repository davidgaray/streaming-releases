#!/usr/bin/env python3
"""notify.py - phone alerts (ntfy.sh) for problems the stick can't fix itself.

Run once a minute, as root, by the Magisk boot supervisor
(firestick-build/scripts/service.d/boot_start_watchdog.sh). Root because the
supervisor's event log lives in /data/local/tmp, which Android won't let the
Termux app read; root can read that and everything under se-site/data.

Reads:  se-site/data/site.json, data/resolve_status.json, data/cycle_status.json
        (board state), dist/index.html (what the TV shows),
        /data/local/tmp/supervisor.events (restarts, VLC relaunches)
Config: se-site/notify.conf - TOPIC=<private ntfy topic>, NAME=<stick name>.
        No config, no alerts (and no network calls).
State:  se-site/data/notify_state.json - what was already sent, so each
        problem alerts once (plus a "recovered" message), not every minute.
        An alert only counts as sent once ntfy accepted it; a failed send is
        retried on the next run.

Alerts:
  board_stale    site.json not rewritten for 15 min (crawler stuck/dead)
  page_stale     dist/index.html not rewritten for 15 min (build stuck/dead)
  crawl_failing  crawl.py exited non-zero two cycles running (with the error)
  build_failing  build.py exited non-zero two cycles running (with the error)
  site_blocked   every mirror failing its health check for 20 min
  nothing_plays  free live games on the board but none resolve, 3 cycles running
  new_player     a player host the resolver doesn't support shows up for the
                 first time, or live games whose page has no player at all
  services       the supervisor had to relaunch the board services
  low_memory     Android killed the board 3+ times today
  vlc_gave_up    VLC kept dying on a stream and the keeper stopped relaunching
  vpn_on         a VPN tunnel is up (streams crawl through it)
  low_storage    less than 500 MB free on /data
  update_*       a release was applied / rolled back / refused (updater.py);
                 updates_stale when the channel hasn't been readable for 36 h
  daily          once a day at 09:00: one-line "all good" summary
"""
import json, os, re, sys, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data")
DIST = os.path.join(HERE, "dist")
CONF = os.path.join(HERE, "notify.conf")
STATE = os.path.join(DATA, "notify_state.json")
EVENTS = "/data/local/tmp/supervisor.events"
REFRESH_LOG = os.path.join(HERE, "refresh-loop.log")

STALE_S = 15 * 60
BLOCKED_S = 20 * 60
NOTHING_PLAYS_CYCLES = 3
FAILING_CYCLES = 2
NEW_PLAYER_REPEAT_S = 3 * 24 * 3600
EVENT_REPEAT_S = 30 * 60          # "restarted itself" / "VLC gave up" at most this often
LOW_STORAGE_BYTES = 500 * 1024 * 1024
UPDATES_STALE_S = 36 * 3600
RESTARTS_PER_DAY_BAD = 3
DAILY_HOUR = 9


def load(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def conf():
    out = {}
    try:
        for line in open(CONF, encoding="utf-8"):
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    except FileNotFoundError:
        pass
    return out


def send(cfg, title, body, priority="default", tags=""):
    req = urllib.request.Request(
        "https://ntfy.sh/" + cfg["TOPIC"], data=body.encode("utf-8"), method="POST",
        headers={"Title": f"{cfg.get('NAME', 'Stick')}: {title}", "Priority": priority, "Tags": tags})
    try:
        urllib.request.urlopen(req, timeout=15).read()
        return True
    except Exception as e:
        print(f"[notify] send failed: {e}", file=sys.stderr)
        return False


def mtime_age(path, now):
    try:
        return now - os.path.getmtime(path)
    except OSError:
        return 1e9


def last_error_line(log_path, max_tail=200_000):
    """The last traceback's final line (e.g. 'ValueError: ...') from a log."""
    try:
        with open(log_path, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - max_tail))
            tail = f.read().decode("utf-8", "replace")
    except OSError:
        return ""
    errs = re.findall(r"^(?:\w+\.)*\w*(?:Error|Exception)\b.*$", tail, re.M)
    return errs[-1][:200] if errs else ""


def read_new_events(st, path=None):
    """Event names appended since the last run. Tracked by byte offset plus
    the file's first line: a trimmed file (the supervisor keeps its tail) is
    detected and skipped past rather than re-read from the start."""
    try:
        with open(path or EVENTS, "rb") as f:
            data = f.read()
    except FileNotFoundError:
        return []
    head = data.split(b"\n", 1)[0].decode("utf-8", "replace")
    pos = st.get("events_pos")
    old_head = st.get("events_head")
    if pos is None or pos > len(data) or (old_head and old_head != head):
        pos = len(data)      # first run, or the file was trimmed/replaced: start from here
    new = data[pos:].decode("utf-8", "replace")
    st["events_pos"], st["events_head"] = len(data), head
    return [l.split()[1] for l in new.splitlines() if len(l.split()) >= 2]


def vpn_active():
    """A VPN tunnel interface exists. Confirmed 2026-11-08: ProtonVPN turned
    itself back on and tunnelled the stick through a ~58 KB/s server; every
    stream froze and nothing said why. The deploy script disables the VPN
    apps, so a tunnel here means something re-enabled one."""
    return os.path.exists("/sys/class/net/tun0") or os.path.exists("/sys/class/net/tun1")


def free_bytes(path):
    try:
        s = os.statvfs(path)
        return s.f_bavail * s.f_frsize
    except OSError:
        return None


def run(cfg, st, now=None, send_fn=None, local_hour=None):
    """One pass: decide what to say, send it, update st. Returns the keys sent."""
    now = time.time() if now is None else now
    send_fn = send_fn or (lambda *a: send(cfg, *a))
    active = st.setdefault("active", {})        # problem key -> first seen / alerted
    out = []                                    # (key, title, body, priority, tags, on_sent)

    def problem(key, is_bad, title, body, priority="high", tags="warning", after_s=0):
        """Alert once when a condition has been bad for after_s; say so when it clears."""
        a = active.get(key)
        if is_bad:
            if a is None:
                active[key] = a = {"since": now, "sent": False}
            if not a["sent"] and now - a["since"] >= after_s:
                out.append((key, title, body, priority, tags, lambda a=a: a.__setitem__("sent", True)))
        elif a is not None:
            if a["sent"]:
                mins = int((now - a["since"]) / 60)
                out.append((key + "_ok", "recovered", f"{title} - fixed itself after {mins} min.",
                            "low", "white_check_mark", None))
            del active[key]

    def event(key, title, body, priority, tags):
        """Something that happened (not a state): at most once per EVENT_REPEAT_S."""
        last = st.setdefault("event_sent", {})
        if now - last.get(key, 0) >= EVENT_REPEAT_S:
            out.append((key, title, body, priority, tags, lambda: last.__setitem__(key, now)))

    site_path = os.path.join(DATA, "site.json")
    site = load(site_path, {})
    status = load(os.path.join(DATA, "resolve_status.json"), {})
    cycle = load(os.path.join(DATA, "cycle_status.json"), {})

    age = mtime_age(site_path, now)
    problem("board_stale", age > STALE_S, "board isn't updating",
            f"The game list hasn't refreshed in {int(age / 60)} min - the crawler may be stuck.")
    page_age = mtime_age(os.path.join(DIST, "index.html"), now)
    problem("page_stale", page_age > STALE_S and age <= STALE_S, "board page isn't updating",
            f"The page on the TV hasn't been rebuilt in {int(page_age / 60)} min - the build step may be stuck.")

    # Crash streaks: cycle_status.json is written every cycle with exit codes.
    streaks = st.setdefault("fail_streak", {"crawl": 0, "build": 0})
    if cycle.get("ts") and cycle.get("ts") != st.get("last_cycle_ts"):
        for step in ("crawl", "build"):
            streaks[step] = streaks[step] + 1 if cycle.get(f"{step}_rc", 0) != 0 else 0
        st["last_cycle_ts"] = cycle["ts"]
    for step in ("crawl", "build"):
        err = last_error_line(REFRESH_LOG) if streaks[step] >= FAILING_CYCLES else ""
        problem(f"{step}_failing", streaks[step] >= FAILING_CYCLES, f"{step} step is crashing",
                f"{step}.py has failed {streaks[step]} cycles in a row"
                + (f": {err}" if err else "") + ". The board is showing old data.")

    health = site.get("mirror_health") or []
    blocked = bool(health) and not any(h.get("ok") for h in health)
    codes = sorted({str(h.get("status")) for h in health})
    problem("site_blocked", blocked, "can't reach the stream site",
            f"Every mirror is failing (HTTP {', '.join(codes)}). Blocked, or the VPN turned itself back on?",
            after_s=BLOCKED_S)

    live = status.get("total_live", 0)
    if live and not status.get("resolved"):
        st["nothing_plays_cycles"] = st.get("nothing_plays_cycles", 0) + (status.get("ts") != st.get("last_status_ts"))
    else:
        st["nothing_plays_cycles"] = 0
    st["last_status_ts"] = status.get("ts")
    problem("nothing_plays", st["nothing_plays_cycles"] >= NOTHING_PLAYS_CYCLES, "no games will play",
            f"{live} free games are live but none of them resolve to a stream. The site probably changed.")

    # Unsupported players: by player host when there is one; live games whose
    # page has no player at all are their own kind of news.
    known = st.setdefault("known_unsupported", {})
    games = status.get("unsupported_games") or [{"slug": None, "host": h} for h in status.get("unsupported_hosts", [])]
    by_key = {}
    for g in games:
        by_key.setdefault(g.get("host") or "no-player", []).append(g.get("slug") or "?")
    fresh = {k: v for k, v in by_key.items() if now - known.get(k, 0) > NEW_PLAYER_REPEAT_S}
    if fresh:
        parts = []
        for k, slugs in sorted(fresh.items()):
            names = ", ".join(sorted(set(slugs))[:4])
            parts.append(f"{names}: page has no player (premium-only, or a new page layout?)" if k == "no-player"
                         else f"{names}: player on {k}, which the resolver doesn't know yet")
        out.append(("new_player", "games that won't play in VLC", " | ".join(parts), "default", "mag",
                    lambda fresh=fresh: known.update({k: now for k in fresh})))

    # Supervisor / VLC keeper events since the last run.
    new = read_new_events(st)
    day = st.setdefault("day", {"restarts": 0, "vlc_relaunches": 0})
    day["restarts"] += new.count("watchdog_relaunched")
    day["vlc_relaunches"] += new.count("vlc_relaunched")
    if "watchdog_relaunched" in new:
        event("services", "board restarted itself",
              "Android stopped the board's background services; they were relaunched automatically.",
              "low", "arrows_counterclockwise")
    problem("low_memory", day["restarts"] >= RESTARTS_PER_DAY_BAD, "Android keeps killing the board",
            f"The board's services were killed {day['restarts']} times today - the stick is short on memory.",
            priority="default", tags="brain")
    if "vlc_gave_up" in new:
        event("vlc_gave_up", "stream keeps dropping",
              "VLC died 3 times in 10 minutes on the same game, so it stopped relaunching. "
              "The stream source is probably failing.", "high", "warning")

    problem("vpn_on", vpn_active(), "a VPN is on",
            "The stick is routing through a VPN tunnel, which makes streams freeze. "
            "Turn the VPN app off (it should be disabled on this stick).", tags="no_entry")

    # Update channel (updater.py writes data/update_status.json).
    upd = load(os.path.join(DATA, "update_status.json"), None)
    if upd:
        seen = st.get("update_events_seen", 0)
        for ev in upd.get("events", []):
            if ev.get("ts", 0) <= seen:
                continue
            kind, text = ev.get("kind"), ev.get("text", "")
            if kind == "applied_code":
                out.append(("update_applied", "updated", text, "low", "package", None))
            elif kind == "applied_rules":
                out.append(("rules_applied", "rules updated", text, "min", "package", None))
            elif kind == "rolled_back":
                out.append(("update_rolled_back", "update rolled back", text + " David should look at this release.",
                            "high", "rewind", None))
            elif kind == "rejected":
                out.append(("update_rejected", "update refused", text, "default", "no_entry", None))
        if upd.get("events"):
            st["update_events_seen"] = max(e.get("ts", 0) for e in upd["events"])
        last_ok = upd.get("last_ok_check", 0)
        problem("updates_stale", bool(last_ok) and now - last_ok > UPDATES_STALE_S, "can't check for updates",
                f"The stick hasn't been able to read the update channel for {int((now - last_ok) / 3600)} h"
                f" ({upd.get('last_error', 'no detail')}).", priority="default", tags="satellite")

    free = free_bytes(DATA)
    problem("low_storage", free is not None and free < LOW_STORAGE_BYTES, "stick is almost out of space",
            f"Only {(free or 0) // (1024 * 1024)} MB free on the stick. Android gets flaky when storage is full - "
            "remove some ROMs or apps.", priority="default", tags="floppy_disk")

    # Daily heartbeat - silence from the stick then means something.
    hour = time.localtime(now).tm_hour if local_hour is None else local_hour
    today = time.strftime("%Y-%m-%d", time.localtime(now))
    if hour >= DAILY_HOUR and st.get("daily_sent") != today:
        n_live = sum(1 for g in site.get("games", []) if g.get("live"))
        problems = ", ".join(k for k, a in active.items() if a.get("sent")) or "none"
        body = (f"{n_live} live now, {status.get('resolved', 0)} playable. Last 24h: "
                f"{day['restarts']} service restarts, {day['vlc_relaunches']} VLC relaunches. "
                f"Open problems: {problems}.")

        def daily_done():
            st["daily_sent"] = today
            st["day"] = {"restarts": 0, "vlc_relaunches": 0}
        out.append(("daily", "daily check", body, "min", "calendar", daily_done))

    sent = []
    for key, title, body, priority, tags, on_sent in out:
        if send_fn(title, body, priority, tags):
            if on_sent:
                on_sent()
            sent.append(key)
            print(f"[notify] sent {key}: {title}", file=sys.stderr)
        else:
            print(f"[notify] could not send {key}; will retry", file=sys.stderr)
    return sent


def main():
    cfg = conf()
    if not cfg.get("TOPIC"):
        return
    st = load(STATE, {})
    run(cfg, st)
    tmp = STATE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f)
    os.replace(tmp, STATE)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        c = conf()
        sys.exit(0 if c.get("TOPIC") and send(c, "test", "Alerts from this stick are working.", "default", "tada") else 1)
    main()
