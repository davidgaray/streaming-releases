#!/usr/bin/env python3
"""
build.py — turn data/site.json into a self-contained static site:
  dist/index.html          root: mirror list + live-now board
  dist/mirrors/<host>.html per-mirror subsite: full game list w/ Play links

For each live game, "Play" is an intent:// link that Brave/Chromium turns
into a real Android VIEW intent straight into VLC (org.videolan.vlc/.
StartActivity), pointed at that game's resolved stream routed through
relay_server.py's /relay endpoint. That relay hop exists because VLC on this
device does not reliably honor #EXTVLCOPT:http-referrer when a stream is
opened via an Android intent (confirmed live 2026-09-29: the CDN 200s with
the Referer and 403s without it, and libvlc's own demux log showed exactly
that 403 body being mistaken for media) - relay_server.py injects the
correct per-game Referer server-side instead, so VLC never needs to send it.

Earlier this pointed "Play" at the mirror's own streame.center/.../chNN.php
player page and separately wrote a dist/live.m3u playlist for VLC to open
directly - both abandoned 2026-09-29: the chNN.php page's splash button
isn't remote-focusable, and VLC's Android-intent launch path won't expand a
hand-written #EXTM3U wrapper file into playable content (it tries to demux
the wrapper file itself and fails), it only works pointed at a real resolved
stream URL. Direct per-game intent links sidestep both problems.

If a match isn't live yet, only the mirror's own match page is offered
(which flips into the player once the game starts, for mouse/touch users).
"""
import html, json, os, re, subprocess, sys, time
import fsutil
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from urllib.parse import quote, urlparse
from zoneinfo import ZoneInfo

# The operator's timezone, hardcoded rather than read from the device/system
# clock - confirmed live 2026-10-02, the device itself defaulted to
# America/Los_Angeles despite being used from Central, and relying on system
# config means this would silently go wrong again on a device/profile reset.
# Needs the `tzdata` pip package on Termux specifically (confirmed live
# 2026-10-02: Android ships its own packed tz database at
# /system/usr/share/zoneinfo, but in Android's own binary format, not the
# per-zone-file layout Python's zoneinfo module reads - `python3 -m pip
# install tzdata` pulls the real IANA data as pure package data instead).
LOCAL_TZ = ZoneInfo("America/Chicago")

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "data", "site.json")
DIST = os.path.join(HERE, "dist")
RESOLVER = os.path.join(HERE, "..", "resolver", "se-resolve")
BASH = "/data/data/com.termux/files/usr/bin/bash"
LAST_RESOLVED = os.path.join(HERE, "data", "last_resolved.json")
STALE_MAX_AGE_S = 20 * 60  # see resolve_live_games() for why
UNSUPPORTED = "unsupported"  # resolve_stream(): the game's player isn't one se-resolve knows

CSS = """
:root{color-scheme:dark;--bg:#0d1117;--card:#161b22;--line:#30363d;
--txt:#e6edf3;--dim:#8b949e;--live:#3fb950;--accent:#58a6ff}
*{box-sizing:border-box}body{margin:0;font:15px/1.5 -apple-system,system-ui,Segoe UI,Roboto,sans-serif;
background:var(--bg);color:var(--txt);max-width:900px;margin:0 auto;padding:24px 16px}
h1{font-size:22px}h2{font-size:17px;color:var(--dim);font-weight:600;margin:28px 0 10px}
a{color:var(--accent)}code{background:var(--card);padding:1px 6px;border-radius:4px;font-size:13px}
.meta{color:var(--dim);font-size:13px}
table{width:100%;border-collapse:collapse}
td,th{padding:8px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{color:var(--dim);font-size:13px;font-weight:600}
.badge{display:inline-block;padding:1px 8px;border-radius:10px;font-size:12px;font-weight:700;text-transform:lowercase}
.badge.live{background:#12351c;color:var(--live);border:1px solid var(--live);text-transform:uppercase}
.badge.countdown{background:#3a2a08;color:#e3b341;border:1px solid #e3b341}
.badge.idle{background:var(--card);color:var(--dim);border:1px solid var(--line)}
.badge.gate{background:#2a1a3a;color:#bc8cff;border:1px solid #bc8cff}
.badge.stale{margin-left:4px;vertical-align:middle}
.net-banner{margin:14px 0;padding:12px 14px;border-radius:8px;font-weight:600;font-size:14px}
.net-banner.down{background:#3a1215;color:#ff7b72;border:1px solid #ff7b72}
.net-banner.degraded{background:#3a2a08;color:#e3b341;border:1px solid #e3b341}
.plays{white-space:nowrap}
.plays a{display:inline-block;margin:2px 6px 2px 0;padding:3px 10px;border-radius:6px;
font-size:13px;font-weight:600;text-decoration:none}
.plays .player{background:var(--live);color:#04120a}
.plays .match{background:var(--card);color:var(--txt);border:1px solid var(--line)}
.plays .match.fallback{background:none;border:none;color:var(--dim);font-weight:400;padding:3px 4px}
.footer{margin-top:32px;color:var(--dim);font-size:13px;border-top:1px solid var(--line);padding-top:14px}
a:focus{outline:3px solid var(--accent);outline-offset:2px;border-radius:6px}
#launch-overlay{position:fixed;inset:0;background:rgba(13,17,23,.94);z-index:999;
display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px}
#launch-overlay[hidden]{display:none}
#launch-overlay .spinner{width:52px;height:52px;border:5px solid var(--line);
border-top-color:var(--live);border-radius:50%;animation:spin .8s linear infinite}
#launch-overlay .msg{font-size:19px;font-weight:600;color:var(--txt)}
@keyframes spin{to{transform:rotate(360deg)}}
"""

# Fire TV remote D-pad presses arrive in Brave as plain ArrowUp/Down/Left/Right
# keydown events - Chromium does NOT translate them into focus movement on an
# ordinary web page the way Tab does (confirmed live 2026-09-29: the remote's
# physical D-pad has no Tab key at all, and every earlier "it's remote-navigable"
# check in this project used `adb shell input keyevent KEYCODE_TAB`, which the
# real remote can never send - a synthetic pass, not a real one). Without this,
# there is no way to reach any link on this page from the couch. Grid nav: Down/Up
# move between table rows (spanning both the live and idle tables, in document
# order, since `rows()` queries the whole page), Left/Right move between the
# links within whichever row currently has focus. Falls through to the browser's
# own default (page scroll) at the top/bottom/each row's ends rather than
# wrapping, matching how most TV UIs behave.
JS = """
(function () {
  function rows() {
    return Array.from(document.querySelectorAll('tr')).filter(function (tr) {
      return tr.querySelector('td.plays a');
    });
  }
  function linksIn(tr) {
    return Array.from(tr.querySelectorAll('td.plays a'));
  }
  function locate() {
    var active = document.activeElement;
    var rs = rows();
    for (var r = 0; r < rs.length; r++) {
      var links = linksIn(rs[r]);
      var c = links.indexOf(active);
      if (c !== -1) return { row: r, col: c, rows: rs, links: links };
    }
    return { row: -1, col: -1, rows: rs, links: null };
  }
  function focusAt(r, c) {
    var rs = rows();
    if (!rs.length) return;
    r = Math.max(0, Math.min(r, rs.length - 1));
    var links = linksIn(rs[r]);
    if (!links.length) return;
    c = Math.max(0, Math.min(c, links.length - 1));
    links[c].focus();
  }
  document.addEventListener('keydown', function (e) {
    if (['ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight'].indexOf(e.key) === -1) return;
    var here = locate();
    if (here.row === -1) { e.preventDefault(); focusAt(0, 0); return; }
    if (e.key === 'ArrowDown') {
      if (here.row >= here.rows.length - 1) return;
      e.preventDefault(); focusAt(here.row + 1, here.col);
    } else if (e.key === 'ArrowUp') {
      if (here.row <= 0) return;
      e.preventDefault(); focusAt(here.row - 1, here.col);
    } else if (e.key === 'ArrowRight') {
      if (here.col >= here.links.length - 1) return;
      e.preventDefault(); focusAt(here.row, here.col + 1);
    } else if (e.key === 'ArrowLeft') {
      if (here.col <= 0) return;
      e.preventDefault(); focusAt(here.row, here.col - 1);
    }
  });
})();

// Activating a "Play in VLC" link (click or a remote's select button on a
// focused link - both fire a normal DOM click event) hands off to Android and
// then just sits there: cold-starting VLC and resolving the stream both take a
// few real seconds, during which nothing on screen changes at all (confirmed
// live 2026-09-29 - looked exactly like the click hadn't registered). The
// intent:// hand-off doesn't navigate this page away, so a full-screen overlay
// shown the instant the click fires stays up for that gap and self-clears via
// visibilitychange once Android actually switches to VLC (and switches back
// when the user returns here) - a fixed timeout alone can't do this because
// the actual delay varies with whether VLC's process was already warm.
(function () {
  var overlay = document.getElementById('launch-overlay');
  if (!overlay) return;
  var fallback = null;
  function hide() {
    overlay.hidden = true;
    if (fallback) { clearTimeout(fallback); fallback = null; }
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a.player');
    if (!a) return;
    overlay.hidden = false;
    fallback = setTimeout(hide, 8000); // in case visibilitychange never fires
  });
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'visible') hide();
  });
  window.addEventListener('pageshow', hide);
  overlay.addEventListener('click', hide); // manual escape hatch
})();

// The board is a static snapshot from the last crawl+build cycle (every
// ~180s, see refresh-loop.sh) - nothing on the page itself ever changes
// without a reload. Confirmed live 2026-10-02: left sitting open in Brave,
// it just shows whatever was current whenever it was last opened/reloaded,
// indefinitely. Poll and reload periodically so new data shows up on its
// own. A plain <meta http-equiv="refresh"> would be simpler but fires
// unconditionally - including mid VLC-handoff (yanking the launch overlay
// away right as Android is switching apps) and while this tab is sitting in
// the background (wasted reloads, and briefly stealing focus back on some
// browsers). Only reload when actually visible and not mid-handoff.
(function () {
  var REFRESH_MS = 60000; // well under the ~180s build cycle
  setInterval(function () {
    if (document.visibilityState !== 'visible') return;
    var overlay = document.getElementById('launch-overlay');
    if (overlay && !overlay.hidden) return;
    location.reload();
  }, REFRESH_MS);
})();
"""


def esc(s):
    return html.escape(s or "", quote=True)


TRAILING_EPOCH_RE = re.compile(r'^(.*?)\s+(\d{10})$')


# League label from the game's path (/nfl/..., /ncaab/...). Short codes are
# acronyms; anything else is a word ("Soccer"). /other-events/ gets none.
LEAGUE_NAMES = {"other-events": "", "soccer": "Soccer", "boxing": "Boxing", "tennis": "Tennis",
                "golf": "Golf", "racing": "Racing", "motorsport": "Racing"}
# Words the slug lowercased that are really acronyms or odd capitalisation.
WORD_FIXES = {w.lower(): w for w in (
    "LA NY NFL NBA NHL MLB WTA ATP PGA LPGA UFC USA UK FC AC AFC SC CF US WWT MVPW "
    "LSU UCLA USC TCU BYU UNLV SMU UCF UTEP UTSA UConn UMass UAlbany RedZone NASCAR TSG NEC PSG PSV "
    "Atlético Vitória Málaga Cádiz Alavés Mönchengladbach Köln München").split()}
# The slug drops accented letters entirely ("atltico"), so key those by the stripped form.
WORD_FIXES.update({"atltico": "Atlético", "vitria": "Vitória", "mlaga": "Málaga", "cdiz": "Cádiz",
                   "alavs": "Alavés", "mnchengladbach": "Mönchengladbach", "kln": "Köln", "mnchen": "München"})
# Slug noise: duplicate-listing counters ("-1", "-2") and soccer team ids ("e7911", "t133661").
TEAM_ID_RE = re.compile(r"\s[et]\d{2,}\b", re.I)
DUP_SUFFIX_RE = re.compile(r"\s\d{1,2}$")


def league_of(g):
    seg = (g.get("href") or "").strip("/").split("/")[0].lower()
    if seg in LEAGUE_NAMES:
        return LEAGUE_NAMES[seg]
    return seg.upper() if len(seg) <= 5 else seg.replace("-", " ").title()


def display_title(g):
    """"NFL - New York Giants vs Philadelphia Eagles" from crawl.py's
    slug-derived title ("New York Giants Vs Philadelphia Eagles 1")."""
    t = g.get("title") or g.get("slug", "")
    if not TRAILING_EPOCH_RE.match(t):
        t = DUP_SUFFIX_RE.sub("", t)        # before the id strip, so "Schalke 04 T133661" keeps its 04
    t = TEAM_ID_RE.sub("", t)
    words = []
    for w in t.split():
        lw = w.lower()
        if lw == "vs":
            words.append("vs")
        elif lw in WORD_FIXES:
            words.append(WORD_FIXES[lw])
        elif w[0].isdigit():
            words.append(lw)                      # "76Ers" -> "76ers"
        else:
            words.append(w[0].upper() + w[1:].lower())
    name = clean_title(" ".join(words))
    league = league_of(g)
    return f"{league} - {name}" if league else name


def sort_key(g):
    return (league_of(g) == "", display_title(g).lower())     # league-less events last


def clean_title(title):
    """crawl.py's slug-derived fallback title for a scheduled-but-not-live
    event is literally "<name> <epoch>" (e.g. "Lpga Round 1 1790899200" -
    the mirror encodes the kickoff time in the slug, crawl.py just title-
    cases the whole thing with no idea that trailing word is a timestamp,
    not part of the name). Confirmed live 2026-10-02: genuinely confusing
    with zero context for what that number even is. Swap it for an actual
    local start time instead - Unix epoch is an absolute instant with no
    timezone of its own, so converting it to LOCAL_TZ here is correct
    regardless of whatever timezone the mirror's server itself runs in."""
    m = TRAILING_EPOCH_RE.match(title)
    if not m:
        return title
    base, epoch_str = m.groups()
    try:
        dt = datetime.fromtimestamp(int(epoch_str), tz=LOCAL_TZ)
    except (ValueError, OSError, OverflowError):
        return title
    time_str = dt.strftime("%a %I:%M %p %Z").replace(" 0", " ")
    return f"{base} — {time_str}"


def resolve_stream(match_url, slug):
    """Run se-resolve --print for one live game. Returns a dict with m3u8,
    referer and (when the stream needs them) origin / expires, or None -
    failure here is routine (token expired, game just ended between crawl
    and build, mirror hiccup) and callers should just skip the entry rather
    than treat it as an error."""
    try:
        # Explicit bash, not relying on se-resolve's own #!/usr/bin/env bash
        # shebang - subprocess.run() execs directly with no shell/PATH
        # environment behind it, so /usr/bin/env can't resolve bash here even
        # though it works fine from an interactive Termux session (confirmed
        # live 2026-09-29: the same call via the shebang alone raised "No such
        # file or directory" for se-resolve itself, which is Python's
        # confusing way of reporting a bad interpreter path, not a missing
        # script).
        result = subprocess.run(
            [BASH, RESOLVER, match_url, "--print"],
            capture_output=True, text=True, timeout=30,
        )
    except Exception as e:
        print(f"[build]   se-resolve failed for {slug}: {e}", file=sys.stderr)
        return None
    if result.returncode != 0:
        why = [l.strip() for l in result.stderr.splitlines() if l.strip()][-2:]
        print(f"[build]   se-resolve exited {result.returncode} for {slug}: "
              f"{' | '.join(why) or 'no output'}", file=sys.stderr)
        # 4 = player chain se-resolve doesn't support (see its exit comment)
        return UNSUPPORTED if result.returncode == 4 else None
    fields = dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)
    if not fields.get("M3U8") or not fields.get("REFERER"):
        print(f"[build]   se-resolve gave no stream for {slug}", file=sys.stderr)
        return None
    return {"m3u8": fields["M3U8"], "referer": fields["REFERER"],
            "origin": fields.get("ORIGIN"), "expires": fields.get("EXPIRES"),
            "chain": fields.get("CHAIN")}


def resolve_live_games(live_games):
    """Resolve each live game once and stash the result on the game dict
    (g["_relay_url"]) for game_play_cells() to build an intent:// link from.
    One resolve per game per build, shared - not called separately per
    template that needs it.

    A resolve failure this cycle for a game that resolved fine last cycle
    doesn't drop straight to the browser-only fallback - it carries forward
    the last-known-good link instead (marked g["_relay_stale"], with
    g["_relay_age_s"] for the template to show how old it is). Confirmed
    live 2026-10-02: a single bad cycle (mirror hiccup, momentary
    rate-limit) was otherwise enough to yank the VLC button away entirely
    mid-watch, with no way back in except waiting for a later cycle to
    resolve again - frustrating given the link usually still basically
    works (tokens last "a few hours", see resolver/README.md) or, if it
    doesn't, relay_server.py's own re-resolve-on-failure (see its module
    docstring) recovers it anyway once VLC actually hits it. Bounded by
    STALE_MAX_AGE_S so a game that's actually stopped resolving for a long
    while (not just one bad cycle) still correctly falls back rather than
    offering an indefinitely-stale button."""
    try:
        with open(LAST_RESOLVED, encoding="utf-8") as f:
            last_good = json.load(f)
    except Exception:
        last_good = {}

    resolved = 0
    still_good = {}
    now = time.time()
    todo = [g for g in live_games if g.get("player") or g.get("url_in_site")]
    # Resolve from the player iframe crawl.py already found, not the match
    # page: crawl.py has just fetched every match page and the mirror 429s
    # bursts (see crawl.py's player_iframe()). The player hosts aren't the
    # mirror, so a few run in parallel - a resolve walks 2-3 player pages,
    # ~5-10s per game on the stick.
    with ThreadPoolExecutor(max_workers=3) as pool:
        results = list(pool.map(
            lambda g: resolve_stream(g.get("player") or g["url_in_site"], g["slug"]), todo))
    unsupported = 0
    unsupported_hosts = set()
    unsupported_games = []      # what notify.py reports: which game, and which player (if any)
    for g, res in zip(todo, results):
        url = g.get("player") or g["url_in_site"]
        slug = g["slug"]
        if res == UNSUPPORTED:
            unsupported += 1
            host = urlparse(g["player"]).netloc if g.get("player") else None
            if host:                # a real player page, not the match-page fallback
                unsupported_hosts.add(host)
            unsupported_games.append({"slug": slug, "host": host})
            res = None
        if res:
            resolved += 1
            still_good[slug] = dict(res, match=url, ts=now)
        else:
            prev = last_good.get(slug)
            age = now - prev["ts"] if prev else None
            if prev and age <= STALE_MAX_AGE_S:
                print(f"[build]   se-resolve failed for {slug} - reusing last-good "
                      f"link from {int(age)}s ago", file=sys.stderr)
                res, url = prev, prev["match"]
                g["_relay_stale"] = True
                g["_relay_age_s"] = int(age)
                still_good[slug] = prev  # not re-confirmed, but not stale enough to drop either
            else:
                continue
        # `match` lets the relay re-resolve from scratch (fresh se-resolve
        # call -> new edge node + token) if this edge node later goes bad
        # mid-playback - see relay_server.py's own retry/re-resolve logic.
        # Without it the relay has no way back to the original match page,
        # only the already-resolved (and potentially now-dead) CDN URL.
        # `org`/`exp`: the Origin header the upstream needs, and when the
        # tokened URL expires so the relay can refresh it ahead of time.
        relay = ("http://127.0.0.1:8080/relay?url=" + quote(res["m3u8"], safe="")
                 + "&ref=" + quote(res["referer"], safe="")
                 + "&match=" + quote(url, safe=""))
        if res.get("origin"):
            relay += "&org=" + quote(res["origin"], safe="")
        if res.get("expires"):
            relay += "&exp=" + quote(res["expires"], safe="")
        if res.get("chain") == "vttp":
            # Playlists come over a WebSocket the relay keeps open (vttp.py).
            relay = ("http://127.0.0.1:8080/vttp.m3u8?embed=" + quote(res["m3u8"], safe="")
                     + "&ref=" + quote(res["referer"], safe=""))
        g["_relay_url"] = relay

    try:
        fsutil.write_json_atomic(LAST_RESOLVED, still_good)
    except Exception as e:
        print(f"[build]   couldn't write last_resolved.json: {e}", file=sys.stderr)

    print(f"[build]   resolved {resolved}/{len(live_games)} live games"
          + (f" ({unsupported} on player chains se-resolve doesn't support)" if unsupported else ""),
          file=sys.stderr)
    # refresh-loop.sh reads this to decide how long to wait before the next
    # cycle - fast when a few games are stuck on the browser fallback
    # (probably a per-game hiccup, worth retrying soon), slower when nothing
    # is resolving (probably rate-limiting, where retrying faster would only
    # make that worse). See refresh-loop.sh's own comment on this file.
    # Unsupported chains are left out of total_live: they won't resolve on a
    # retry, and counting them kept the loop on its 30s "retry soon" cadence
    # all evening (a full crawl + build every ~90s while a stream played).
    try:
        fsutil.write_json_atomic(os.path.join(HERE, "data", "resolve_status.json"),
                                 {"resolved": resolved, "total_live": len(live_games) - unsupported,
                                  "unsupported": unsupported, "unsupported_hosts": sorted(unsupported_hosts),
                                  "unsupported_games": unsupported_games, "ts": int(now)})
    except Exception as e:
        print(f"[build]   couldn't write resolve_status.json: {e}", file=sys.stderr)


def game_play_cells(g):
    """Play (live only) deep-links straight into VLC via Chromium's intent://
    scheme - Brave turns it into a real Android VIEW intent at
    org.videolan.vlc/.StartActivity, remote-clickable like any other link.
    Confirmed live end-to-end 2026-09-29 (real broadcast video on-device).
    Falls back to the mirror's own player page if this cycle's resolve
    didn't produce a stream (routine - token expiry, game just ended, etc);
    that fallback has an unclickable-by-remote splash button in front of the
    actual video, so it's only useful for mouse/touch users.

    Previously also showed a "terminal" hint and a "browse" button surfacing
    the raw `se-resolve --browse` command - removed 2026-09-29, they never
    did anything on the TV itself (the alert just displayed text with no
    keyboard/clipboard to do anything with it) and were leftover from before
    Play in VLC did the real work end-to-end."""
    out = []
    url = g.get("url_in_site", "")
    has_direct_play = False
    if g.get("live"):
        relay_url = g.get("_relay_url")
        if relay_url:
            intent = ("intent://" + relay_url[len("http://"):] +
                       "#Intent;scheme=http;package=org.videolan.vlc;"
                       "component=org.videolan.vlc/.StartActivity;"
                       "type=application/vnd.apple.mpegurl;"
                       "action=android.intent.action.VIEW;end")
            out.append(f'<a class="player" href="{esc(intent)}">▶ Play in VLC</a>')
            if g.get("_relay_stale"):
                # This cycle's resolve failed but we're still offering last
                # cycle's link rather than yanking VLC away (see
                # resolve_live_games()) - say so, don't let it look like a
                # clean, freshly-confirmed link when it isn't one. relay_
                # server.py's own re-resolve-on-failure (its module
                # docstring) is what actually gets this working again if the
                # old token really has died by the time it's clicked.
                age_m = max(1, g["_relay_age_s"] // 60)
                out.append(f'<span class="badge countdown stale" title="last confirmed '
                            f'{age_m}m ago - resolve hiccupped this cycle">'
                            f'⚠ reconnecting</span>')
            has_direct_play = True
        elif g.get("player"):
            out.append(f'<a class="player" href="{esc(g["player"])}">▶ Play (browser)</a>')
    if url:
        # When a direct Play link is already there, "Match page" is only a
        # last-resort fallback (unclickable-by-remote splash screen, plus the
        # mirror's own page can show its own premium/crown upsell UI that has
        # nothing to do with whether the direct stream is actually gated -
        # confirmed live 2026-10-02, a game that resolved and played cleanly
        # through se-resolve/relay still showed a premium graphic on this
        # link's destination). De-emphasize + label it as such so it doesn't
        # read as an equal, equally-good alternative to the real Play button.
        # No target="_blank": Fully Kiosk runs a single WebView with nowhere
        # to open a new tab, so a _blank link silently did nothing there
        # (confirmed dead 2026-11-02). Same-tab navigation; Back returns.
        if has_direct_play:
            out.append(f'<a class="match fallback" href="{esc(url)}">Match page (fallback)</a>')
        else:
            out.append(f'<a class="match" href="{esc(url)}">Match page</a>')
    return "".join(out)


def pages():
    # Watchable in VLC first, then live games with no VLC link (player we
    # can't play yet), then premium-only; each group by league, then name.
    live = sorted((g for g in games if g.get("live")),
                  key=lambda g: (not g.get("_relay_url"), sort_key(g)))
    # In progress but behind the site's premium gate (crawl.py's
    # classify_match_page()) - listed with the live games so they don't read
    # as "crawler missed it", after the ones you can actually play.
    premium_live = sorted((g for g in games if not g.get("live") and g.get("premium") == "live"), key=sort_key)
    idle = [g for g in games if not g.get("live") and g.get("premium") != "live"]

    # crawl.py's schema sets the "live" boolean and a "premium" state
    # ("live"/"upcoming"/None), never a single "state" string - derive the
    # badge from those.
    def badge(g):
        if g.get("live"):
            return "live", "live"
        if g.get("premium") == "live":
            return "gate", "live · premium only"
        if g.get("premium") == "upcoming":
            return "gate", "premium only"
        return "idle", "idle"

    def row(g):
        cls, text = badge(g)
        return (f'<tr><td>{esc(display_title(g))}<div class="meta">{esc(g["slug"])}</div></td>'
                f'<td><span class="badge {cls}">{text}</span></td>'
                f'<td class="plays">{game_play_cells(g)}</td></tr>')

    top = live + premium_live
    board = (
        "<table><tr><th>Sport / Game</th><th>Status</th><th>Watch</th></tr>"
        + "".join(map(row, top)) + "</table>"
        if top else
        '<p class="meta">No live matches at the time of the last crawl.</p>')
    if premium_live and not live:
        board = ('<p class="meta">Nothing free is live right now - these are on, '
                 'but premium-only on the site.</p>' + board)
    if idle:
        board += ("<h2>Upcoming / idle</h2>"
                  "<table><tr><th>Sport / Game</th><th>Status</th><th>Watch</th></tr>"
                  + "".join(map(row, idle)) + "</table>")

    # crawl.py deliberately queries only the first healthy mirror for an actual
    # game list each cycle, then stops - "the other mirrors would return the
    # same slugs (they are mirrors)" (see crawl.py's crawl()). The other
    # mirrors were never asked for games that cycle, so "0 games listed" is
    # misleading - it reads as "checked, found nothing" when it's really
    # "not checked, a sibling already answered". Label those as skipped
    # instead, and separate out mirrors that failed their own health check
    # (a genuinely different, worse signal) from ones that were simply
    # redundant.
    source_host = urlparse(site.get("source_mirror") or "").netloc
    health_by_host = {urlparse(h.get("mirror", "")).netloc: h
                       for h in site.get("mirror_health", [])}
    mirrors_rows = ""
    seen = set()
    for m in site["mirrors"]:
        host = urlparse(m).netloc
        if host in seen:
            continue
        seen.add(host)
        slug = re.sub(r"[^a-z0-9]+", "-", host.lower()).strip("-")
        h = health_by_host.get(host)
        if host == source_host:
            n = sum(1 for g in games if (g.get("mirror_base") or "").endswith(host))
            status = f"{n} games listed"
        elif h is not None and h.get("ok") is False:   # None = not checked this cycle
            status = f'<span class="badge idle">unhealthy</span> (HTTP {h.get("status", "?")})'
        elif source_host:
            status = (f'<span class="meta">skipped — same catalog as '
                      f'<a href="mirrors/{re.sub(r"[^a-z0-9]+", "-", source_host.lower()).strip("-")}.html">{esc(source_host)}</a></span>')
        else:
            # No mirror produced a game list this cycle at all - "skipped" would
            # be misleading too (nothing "won"); say so plainly instead.
            status = '<span class="meta">no game list this cycle</span>'
        mirrors_rows += (
            f'<tr><td><a href="mirrors/{slug}.html">{esc(host)}</a></td>'
            f'<td class="meta">{status}</td></tr>')

    # crawl.py writes this in UTC (datetime.now(timezone.utc).isoformat()) -
    # convert to LOCAL_TZ for display rather than showing UTC, which was
    # confirmed confusing live 2026-10-02 (the device's own system clock
    # defaulted to Pacific, not even UTC, making this doubly disconnected
    # from any clock actually nearby).
    try:
        generated_dt = datetime.fromisoformat(site.get("generated_at", ""))
        generated = generated_dt.astimezone(LOCAL_TZ).strftime("%Y-%m-%d %I:%M %p %Z").replace(" 0", " ")
    except (ValueError, TypeError):
        generated = site.get("generated_at", "?")

    # Plain-language signal for "can't reach the internet" vs "nothing's
    # live" - see crawl.py's network_status computation for what sets this.
    # Risk-analysis finding (2026-10-03, docs/GOLD_IMAGE_PLAN.md): before
    # this, a VPN/network outage looked pixel-identical to a quiet night of
    # sports - nothing on the page distinguished them.
    net_status = site.get("network_status", "ok")
    banner = ""
    # The VPN advice is gone: since 2026-10-26 the stick runs without one.
    as_of = ""
    if site.get("games_as_of"):
        try:
            as_of = (datetime.fromisoformat(site["games_as_of"]).astimezone(LOCAL_TZ)
                     .strftime("%I:%M %p").lstrip("0"))
        except (ValueError, TypeError):
            pass
    kept = f" Showing the game list from {as_of}." if as_of else ""
    if net_status == "down":
        banner = ('<div class="net-banner down">⚠ Can\'t reach the internet right now — '
                  f'check the stick\'s Wi-Fi.{kept}</div>')
    elif net_status == "degraded":
        banner = ('<div class="net-banner degraded">⚠ The game site is busy right now.'
                  f'{kept} It usually clears up on its own; a game that\'s already playing isn\'t affected.</div>')

    # --- per-mirror subsite (same content, canonical mirror base) ---
    mirror_links = ""
    seen2 = set()
    for m in site["mirrors"]:
        host = urlparse(m).netloc
        if host in seen2:
            continue
        seen2.add(host)
        slug = re.sub(r"[^a-z0-9]+", "-", host.lower()).strip("-")
        cur = ' style="color:var(--live);text-decoration:none"' if host == current_base_host else ""
        mirror_links += (f'<a href="../mirrors/{slug}.html" class="{("cur" if "/mirrors/" in cur else "")}"{cur}>{esc(host)}</a> ')

    index_html = f"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Streams East — live board</title><style>{CSS}</style></head><body>
<div id="launch-overlay" hidden><div class="spinner"></div><div class="msg">Launching VLC…</div></div>
<h1>📺 Streams East — live sports board</h1>
<p class="meta">Generated {esc(generated)} from <code>se-site/crawl.py</code>.
Tokens rotate, so re-run <code>se-site/run.sh</code> before watching.
Remote: ↑↓ between games, ←→ between buttons, center button to select.</p>
{banner}
{board}
<h2>Mirror sites</h2>
<table><tr><th>Mirror</th><th></th></tr>{mirrors_rows}</table>
<div class="footer">Play launches VLC directly via an intent:// link, remote-clickable
like any other link — no browser page to navigate once you're in. <a href="../">…</a></div>
<script>{JS}</script>
</body></html>"""

    mirror_html = f"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Streams East — {esc(current_base_host)}</title><style>{CSS}</style></head><body>
<div id="launch-overlay" hidden><div class="spinner"></div><div class="msg">Launching VLC…</div></div>
<p class="meta"><a href="../index.html">← all mirrors</a> &nbsp; {mirror_links}</p>
<h1>📺 {esc(current_base_host)}</h1>
<p class="meta">Generated {esc(generated)}. Re-run <code>se-site/run.sh</code> to refresh live status.
Remote: ↑↓ between games, ←→ between buttons, center button to select.</p>
{banner}
{board}
<div class="footer">Play launches VLC directly via an intent:// link;
<code>--browse</code> mode of resolver/se-resolve does the same from a terminal.</div>
<script>{JS}</script>
</body></html>"""
    return index_html, mirror_html


def main():
    global games, site, current_base_host
    if not os.path.exists(DATA):
        sys.exit(f"no data: {DATA} — run ./run.sh or crawl.py first")
    with open(DATA, encoding="utf-8") as f:
        site = json.load(f)
    games = site.get("games", [])
    src = site.get("source_mirror") or (site.get("mirrors") or [""])[0]
    current_base_host = urlparse(src).netloc

    os.makedirs(os.path.join(DIST, "mirrors"), exist_ok=True)
    # wipe stale artifacts so only the current mirror set survives
    for old in os.listdir(os.path.join(DIST, "mirrors")):
        p = os.path.join(DIST, "mirrors", old)
        if old.endswith(".html") and os.path.isfile(p):
            os.remove(p)
    live_games = [g for g in games if g.get("live")]
    resolve_live_games(live_games)  # populates g["_relay_url"] before pages() renders Play links
    index_html, mirror_html = pages()
    # Atomic: Fully Kiosk reloads this page every minute and notify.py judges
    # the board by its mtime - neither should ever see a half-written file.
    fsutil.write_atomic(os.path.join(DIST, "index.html"), index_html)
    slug = re.sub(r"[^a-z0-9]+", "-", current_base_host.lower()).strip("-")
    fsutil.write_atomic(os.path.join(DIST, "mirrors", slug + ".html"), mirror_html)
    # one subsite page per mirror for the nav links (same board, different label)
    for m in site.get("mirrors", []):
        h = urlparse(m).netloc
        s = re.sub(r"[^a-z0-9]+", "-", h.lower()).strip("-")
        if s == slug:
            continue
        base = m.rstrip("/")
        label = h
        page = mirror_html.replace(f"Streams East — {current_base_host}", f"Streams East — {label}").replace(
            f"<h1>📺 {current_base_host}</h1>", f"<h1>📺 {label}</h1>")
        fsutil.write_atomic(os.path.join(DIST, "mirrors", s + ".html"), page)
    print(f"[build] dist/index.html + dist/mirrors/*.html  "
          f"({len(games)} games, {len(live_games)} live)", file=sys.stderr)


if __name__ == "__main__":
    main()
