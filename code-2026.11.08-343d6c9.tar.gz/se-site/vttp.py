"""vttp.py - client for the "vttp" player chain (seen 2026-11-08 on NFL games:
www.playhaxballl.com/NflStreamEmbed.php), so relay_server.py can hand VLC a
normal HLS playlist.

The embed page's Shaka player gets its playlists over a WebSocket instead of
HTTP: it connects to wss://<host>/websocket, sends a JSON-RPC "start" for the
channel, and receives "paint" messages whose result.renditions maps a
rendition name (e.g. "video2_falcons") to a live media playlist with
relative .ts segment names. The page's window.masterinf gives each
rendition's EXT-X-STREAM-INF line and the CDN folder its segments live in
("subfolder", only set for the renditions actually served). Segments are
plain MPEG-TS on Akamai - no DRM, no wrapper.

Stdlib only (Termux has no websocket package): a minimal RFC 6455 client
that's enough for this one text-message protocol.
"""
import base64, json, os, re, socket, ssl, struct, threading, time, urllib.parse

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")


def parse_embed(html):
    """(ws hosts, channel, {rendition file: {"inf", "subfolder"}}) from the embed page, or None."""
    hosts = re.search(r'var wsHosts\s*=\s*(\[[^\]]*\])', html)
    chan = re.search(r'var channel\s*=\s*"([^"]+)"', html)
    inf = re.search(r'window\.masterinf\s*=\s*(\{.*?\});\s*\n', html, re.S)
    if not (hosts and chan and inf):
        return None
    return json.loads(hosts.group(1)), chan.group(1), json.loads(inf.group(1))


class _WS:
    def __init__(self, host, origin, timeout=15):
        raw = socket.create_connection((host, 443), timeout=timeout)
        self.s = ssl.create_default_context().wrap_socket(raw, server_hostname=host)
        key = base64.b64encode(os.urandom(16)).decode()
        self.s.sendall((f"GET /websocket HTTP/1.1\r\nHost: {host}\r\nUpgrade: websocket\r\n"
                        f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\n"
                        f"Sec-WebSocket-Version: 13\r\nOrigin: {origin}\r\nUser-Agent: {UA}\r\n\r\n").encode())
        head = b""
        while b"\r\n\r\n" not in head:
            chunk = self.s.recv(4096)
            if not chunk:
                raise ConnectionError("websocket handshake: connection closed")
            head += chunk
        if b" 101 " not in head.split(b"\r\n", 1)[0]:
            raise ConnectionError("websocket handshake: " + head.split(b"\r\n", 1)[0].decode("latin1"))
        self.buf = head.split(b"\r\n\r\n", 1)[1]

    def _read(self, n):
        while len(self.buf) < n:
            chunk = self.s.recv(65536)
            if not chunk:
                raise ConnectionError("websocket closed")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def send_text(self, text):
        data = text.encode()
        mask = os.urandom(4)
        n = len(data)
        hdr = b"\x81" + (bytes([0x80 | n]) if n < 126 else
                         b"\xfe" + struct.pack(">H", n) if n < 65536 else b"\xff" + struct.pack(">Q", n))
        self.s.sendall(hdr + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    def recv_text(self):
        msg = b""
        while True:
            b0, b1 = self._read(2)
            n = b1 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._read(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._read(8))[0]
            payload = self._read(n)
            op = b0 & 0x0F
            if op == 8:
                raise ConnectionError("websocket closed by server")
            if op == 9:                      # ping -> pong
                self.s.sendall(b"\x8a\x80" + os.urandom(4))
                continue
            if op in (0, 1):
                msg += payload
                if b0 & 0x80:
                    return msg.decode("utf-8", "replace")

    def close(self):
        try:
            self.s.close()
        except OSError:
            pass


class VttpChannel:
    """Keeps a websocket open in the background and the latest playlists in memory."""

    def __init__(self, hosts, channel, masterinf, origin):
        self.hosts, self.channel, self.masterinf, self.origin = hosts, channel, masterinf, origin
        self.renditions = {}
        self.updated = 0.0
        self.last_used = time.time()
        self.ready = threading.Event()
        self.alive = True
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        try:
            self._loop()
        finally:
            self.alive = False

    def _loop(self):
        attempt = 0
        while time.time() - self.last_used < 120:     # stop when nobody's watching
            host = self.hosts[attempt % len(self.hosts)]
            try:
                ws = _WS(host, self.origin)
                ws.send_text(json.dumps({"jsonrpc": "2.0", "method": "start", "id": 0, "params": {
                    "connid": base64.b16encode(os.urandom(16)).decode().lower(), "channel": self.channel,
                    "is_publisher": False, "is_cdn": False, "version": 1}}))
                attempt = 0
                while time.time() - self.last_used < 120:
                    data = json.loads(ws.recv_text())
                    if data.get("type") == "paint" and data.get("result", {}).get("renditions"):
                        self.renditions = data["result"]["renditions"]
                        self.updated = time.time()
                        self.ready.set()
                ws.close()
            except Exception:
                attempt += 1
                time.sleep(min(30, 2 ** attempt))

    def best(self):
        """(rendition file, its media playlist with absolute segment URLs) for the
        highest-bandwidth rendition that has a CDN folder and live content."""
        self.last_used = time.time()
        def bw(item):
            m = re.search(r"BANDWIDTH=(\d+)", item[1]["inf"])
            return int(m.group(1)) if m else 0
        for name, info in sorted(self.masterinf.items(), key=bw, reverse=True):
            text = self.renditions.get(name.rsplit(".", 1)[0])
            if not text or ".ts" not in text:
                continue
            sub = info.get("subfolder") or ""
            lines = []
            for l in text.split("\n"):
                if l.strip() and not l.startswith("#") and not l.startswith("http"):
                    if not sub:
                        break                          # relative segments, nowhere to fetch them from
                    l = sub + l.strip()
                lines.append(l)
            else:
                return name, "\n".join(lines)
        return None, None
