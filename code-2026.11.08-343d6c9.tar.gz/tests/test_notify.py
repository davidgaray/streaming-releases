"""Offline tests for notify.py's decisions. Everything it reads is pointed at
a temp directory and sending is a fake, so no network and no real state.

    python3 -m unittest discover -s tests
"""
import json, os, shutil, sys, tempfile, time, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "se-site"))
import fsutil, notify  # noqa: E402


class NotifyTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.orig = notify.DATA, notify.DIST, notify.EVENTS, notify.REFRESH_LOG
        self.orig_vpn = notify.vpn_active
        notify.vpn_active = lambda: False
        notify.DATA = os.path.join(self.tmp, "data")
        notify.DIST = os.path.join(self.tmp, "dist")
        notify.EVENTS = os.path.join(self.tmp, "events")
        notify.REFRESH_LOG = os.path.join(self.tmp, "refresh-loop.log")
        os.makedirs(notify.DATA)
        os.makedirs(notify.DIST)
        self.now = time.time()
        self.sent = []
        self.st = {}
        # A healthy board: fresh files, one mirror ok, everything resolving.
        self.write("data/site.json", {"games": [{"live": True}], "mirror_health": [{"ok": True, "status": 200}]})
        self.write("data/resolve_status.json", {"resolved": 1, "total_live": 1, "ts": int(self.now)})
        self.write("data/cycle_status.json", {"ts": int(self.now), "crawl_rc": 0, "build_rc": 0})
        self.write("dist/index.html", "<html>")

    def tearDown(self):
        notify.DATA, notify.DIST, notify.EVENTS, notify.REFRESH_LOG = self.orig
        notify.vpn_active = self.orig_vpn
        shutil.rmtree(self.tmp)

    def test_vpn_tunnel_alerts_and_recovers(self):
        notify.vpn_active = lambda: True
        self.assertEqual(self.run_once(), ["vpn_on"])
        notify.vpn_active = lambda: False
        self.assertEqual(self.run_once(), ["vpn_on_ok"])

    def write(self, rel, obj):
        path = os.path.join(self.tmp, rel)
        fsutil.write_atomic(path, obj if isinstance(obj, str) else json.dumps(obj))
        return path

    def run_once(self, ok=True, now=None, hour=8):
        def fake_send(title, body, priority, tags):
            self.sent.append((title, body, priority))
            return ok
        return notify.run({"TOPIC": "t"}, self.st, now or self.now, fake_send, local_hour=hour)

    def test_healthy_board_is_silent(self):
        self.assertEqual(self.run_once(), [])

    def test_failed_send_is_retried_next_run(self):
        self.write("data/cycle_status.json", {"ts": 1, "crawl_rc": 1, "build_rc": 0})
        self.run_once()
        self.write("data/cycle_status.json", {"ts": 2, "crawl_rc": 1, "build_rc": 0})
        self.assertEqual(self.run_once(ok=False), [])          # ntfy down: nothing counts as sent
        self.assertEqual(self.run_once(ok=True), ["crawl_failing"])
        self.assertEqual(self.run_once(ok=True), [])           # and only once

    def test_crawl_crash_two_cycles_alerts_with_the_error(self):
        with open(notify.REFRESH_LOG, "w") as f:
            f.write("Traceback...\n  File x\nValueError: list.index(x): x not in list\n[13:43] building…\n")
        self.write("data/cycle_status.json", {"ts": 1, "crawl_rc": 1, "build_rc": 0})
        self.assertEqual(self.run_once(), [])                  # one bad cycle: wait
        self.write("data/cycle_status.json", {"ts": 2, "crawl_rc": 1, "build_rc": 0})
        self.assertEqual(self.run_once(), ["crawl_failing"])
        self.assertIn("ValueError: list.index", self.sent[-1][1])
        self.write("data/cycle_status.json", {"ts": 3, "crawl_rc": 0, "build_rc": 0})
        self.assertEqual(self.run_once(), ["crawl_failing_ok"])

    def test_build_page_stale_alerts_even_when_crawl_is_fine(self):
        old = self.now - 20 * 60
        os.utime(os.path.join(notify.DIST, "index.html"), (old, old))
        self.assertEqual(self.run_once(), ["page_stale"])

    def test_new_player_names_the_game_and_the_player(self):
        self.write("data/resolve_status.json", {
            "resolved": 1, "total_live": 1, "ts": 5,
            "unsupported_games": [{"slug": "nfl-redzone-31", "host": None},
                                  {"slug": "a-vs-b", "host": "xstream.st"}]})
        self.assertEqual(self.run_once(), ["new_player"])
        body = self.sent[-1][1]
        self.assertIn("nfl-redzone-31: page has no player", body)
        self.assertIn("a-vs-b: player on xstream.st", body)
        self.assertEqual(self.run_once(), [])                  # remembered for 3 days

    def test_events_after_trim_are_not_replayed(self):
        with open(notify.EVENTS, "w") as f:
            f.write("1 watchdog_relaunched\n2 watchdog_relaunched\n")
        self.run_once()                                        # first run: history is not news
        self.assertEqual(self.sent, [])
        with open(notify.EVENTS, "a") as f:
            f.write("3 watchdog_relaunched\n")
        self.assertEqual(self.run_once(), ["services"])
        with open(notify.EVENTS, "w") as f:                   # supervisor trimmed it to its tail
            f.write("3 watchdog_relaunched\n")
        self.assertEqual(self.run_once(now=self.now + 60), [])

    def test_repeated_restarts_are_rate_limited_and_flag_low_memory(self):
        open(notify.EVENTS, "w").close()
        self.run_once()                                        # learn the (empty) file
        expect = {1: ["services"], 2: [], 3: ["low_memory"]}   # 2: inside the 30 min window
        for i in range(1, 4):
            with open(notify.EVENTS, "a") as f:
                f.write(f"{i} watchdog_relaunched\n")
            self.assertEqual(self.run_once(now=self.now + i * 120), expect[i], f"run {i}")

    def test_update_events_are_relayed_once(self):
        self.write("data/update_status.json", {"last_ok_check": self.now, "events": [
            {"ts": 10, "kind": "installed", "text": "code v1 installed"},
            {"ts": 11, "kind": "rolled_back", "text": "code v1 rolled back to v0: crash"}]})
        self.assertEqual(self.run_once(), ["update_rolled_back"])
        self.assertEqual(self.sent[-1][2], "high")
        self.assertEqual(self.run_once(), [])
        self.write("data/update_status.json", {"last_ok_check": self.now, "events": [
            {"ts": 11, "kind": "rolled_back", "text": "old"}, {"ts": 12, "kind": "applied_code", "text": "code v2 live"}]})
        self.assertEqual(self.run_once(), ["update_applied"])

    def test_unreadable_channel_alerts_after_36h(self):
        self.write("data/update_status.json", {"last_ok_check": self.now - 40 * 3600, "last_error": "curl 6", "events": []})
        self.assertEqual(self.run_once(), ["updates_stale"])

    def test_daily_only_counts_as_sent_when_delivered(self):
        self.assertEqual(self.run_once(ok=False, hour=9), [])
        self.assertIsNone(self.st.get("daily_sent"))
        self.assertEqual(self.run_once(ok=True, hour=9), ["daily"])
        self.assertEqual(self.run_once(ok=True, hour=10), [])


if __name__ == "__main__":
    unittest.main()
