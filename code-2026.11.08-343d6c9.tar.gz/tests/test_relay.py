"""Offline tests for relay_server.py's observability: /health, stream
activity tracking, idle-state eviction and the rules.json hot reload.

    python3 -m unittest discover -s tests
"""
import json, os, sys, tempfile, threading, time, unittest, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "se-site"))
import relay_server, unwrap  # noqa: E402


class HealthTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = relay_server.Server(("127.0.0.1", 0), relay_server.Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()

    def setUp(self):
        with relay_server._activity_lock:
            relay_server._activity.clear()

    def get(self, path):
        with urllib.request.urlopen(f"http://127.0.0.1:{self.port}{path}", timeout=5) as r:
            return r.status, r.headers.get("Content-Type"), r.read()

    def test_health_reports_state(self):
        status, ctype, body = self.get("/health")
        self.assertEqual(status, 200)
        self.assertEqual(ctype, "application/json")
        h = json.loads(body)
        self.assertTrue(h["ok"])
        self.assertEqual(h["active_streams"], 0)
        self.assertIn("version", h)
        self.assertEqual(h["rules_version"], json.load(open(relay_server.RULES_PATH))["version"])
        self.assertGreaterEqual(h["uptime_s"], 0)

    def test_active_streams_counts_recent_polls_only(self):
        relay_server._touch("match-a")
        relay_server._touch("vttp:embed-b")
        self.assertEqual(relay_server.active_streams(), 2)
        self.assertEqual(json.loads(self.get("/health")[2])["active_streams"], 2)
        self.assertEqual(relay_server.active_streams(time.time() + relay_server.ACTIVE_S + 1), 0)

    def test_housekeeping_evicts_idle_streams_but_not_busy_ones(self):
        now = time.time()
        old = now - relay_server.EVICT_AFTER_S - 1
        with relay_server._streams_lock:
            relay_server._streams["idle"] = {"busy": False, "polled": old}
            relay_server._streams["busy"] = {"busy": True, "polled": old}
            relay_server._streams["fresh"] = {"busy": False, "polled": now}
        with relay_server._lives_lock:
            relay_server._lives["idle-live"] = {"polled": old}
        dropped = relay_server.housekeep(now)
        self.assertEqual(dropped, 2)
        self.assertEqual(sorted(relay_server._streams), ["busy", "fresh"])
        self.assertEqual(relay_server._lives, {})


class UnwrapReloadTest(unittest.TestCase):
    def setUp(self):
        self.orig = unwrap.RULES_PATH, unwrap.TIKTIK_MAGIC, unwrap._rules_mtime
        self.tmp = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False)
        self.tmp.close()
        unwrap.RULES_PATH = self.tmp.name

    def tearDown(self):
        unwrap.RULES_PATH, unwrap.TIKTIK_MAGIC, unwrap._rules_mtime = self.orig
        os.unlink(self.tmp.name)

    def write(self, magic):
        with open(self.tmp.name, "w") as f:
            json.dump({"transport": {"png_magic": magic}}, f)
        os.utime(self.tmp.name, (time.time() + 5, time.time() + 5))   # guarantee a new mtime

    def test_reload_picks_up_a_changed_magic(self):
        self.write("NEWMAGIC")
        self.assertTrue(unwrap.reload())
        self.assertEqual(unwrap.TIKTIK_MAGIC, b"NEWMAGIC")
        self.assertFalse(unwrap.reload())            # unchanged file: nothing to do

    def test_broken_rules_fall_back_to_default(self):
        with open(self.tmp.name, "w") as f:
            f.write("{not json")
        os.utime(self.tmp.name, (time.time() + 5, time.time() + 5))
        unwrap.reload()
        self.assertEqual(unwrap.TIKTIK_MAGIC, b"TIKTIKPX")


if __name__ == "__main__":
    unittest.main()
