"""Offline tests for the rules-driven parts of se-site: the crawler's page
markers and the PNG segment unwrapper.

    python3 -m unittest discover -s tests
"""
import gzip, os, struct, sys, tempfile, time, unittest, zlib

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "se-site"))
import crawl, ratelimit, unwrap  # noqa: E402


def png(rgb_bytes, width=64):
    """Minimal 8-bit RGB PNG holding rgb_bytes (zero-padded to whole rows)."""
    row = width * 3
    rgb_bytes += b"\0" * (-len(rgb_bytes) % row)
    raw = b"".join(b"\0" + rgb_bytes[i:i + row] for i in range(0, len(rgb_bytes), row))
    def chunk(t, d):
        return struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    ihdr = struct.pack(">IIBBBBB", width, len(rgb_bytes) // row, 8, 2, 0, 0, 0)
    return unwrap.PNG_MAGIC + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")


class UnwrapTest(unittest.TestCase):
    def test_round_trip(self):
        ts = b"\x47" + bytes(187) * 1 + b"\x47" + bytes(187)
        gz = gzip.compress(ts)
        seg = png(unwrap.TIKTIK_MAGIC + struct.pack(">I", len(gz)) + gz)
        self.assertEqual(unwrap.unwrap_segment(seg), ts)

    def test_plain_ts_passes_through_as_none(self):
        self.assertIsNone(unwrap.unwrap_segment(b"\x47" + bytes(187)))

    def test_wrong_magic(self):
        gz = gzip.compress(b"x")
        self.assertIsNone(unwrap.unwrap_segment(png(b"NOTMAGIC" + struct.pack(">I", len(gz)) + gz)))


class CrawlMarkersTest(unittest.TestCase):
    def test_live_free_game(self):
        body = ('<div data-state="live"><script>showProGate: false</script>'
                '<iframe src="https://example.com/sso-frame"></iframe>'
                '<iframe src="https://thedaddy.top/stream/stream-44.php"></iframe></div>')
        live, player, premium = crawl.classify_match_page(body)
        self.assertTrue(live)
        self.assertIsNone(premium)

    def test_premium_gate_started(self):
        body = '<div data-state="gate"></div><script>showProGate: true, timeUntilStart: -600</script>'
        self.assertEqual(crawl.classify_match_page(body), (False, None, "live"))

    def test_premium_gate_upcoming(self):
        body = '<div data-state="gate"></div><script>showProGate: true, timeUntilStart: 900</script>'
        self.assertEqual(crawl.classify_match_page(body)[2], "upcoming")

    def test_ended(self):
        self.assertEqual(crawl.classify_match_page('<div data-state="ended">'), (False, None, None))

    def test_homepage_card_live_class(self):
        home = ('<a class="m-card m-card--live" ><a class="m-card__link" href="/nfl/falcons-vs-colts/">'
                '<a class="m-card"><a class="m-card__link" href="/nba/a-vs-b/">')
        m = crawl.card_live_map(home)
        self.assertTrue(any(m.values()))
        self.assertFalse(all(m.values()))

    def test_rank_mirrors_uses_last_cycles_order(self):
        checked = []
        orig = crawl.check_mirror_health
        crawl.check_mirror_health = lambda m: checked.append(m) or {"mirror": m, "ok": m == "b", "status": 200}
        try:
            prev = [{"mirror": "b", "ok": True}, {"mirror": "a", "ok": False}]
            res = crawl.rank_mirrors(["a", "b", "c"], prev)
        finally:
            crawl.check_mirror_health = orig
        self.assertEqual(checked, ["b"])                     # stopped at the first working one
        self.assertEqual([r["mirror"] for r in res], ["b", "a", "c"])


class RateLimitTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.orig = ratelimit.DATA, ratelimit.STATE
        ratelimit.DATA, ratelimit.STATE = self.tmp, os.path.join(self.tmp, "ratelimit.json")

    def tearDown(self):
        ratelimit.DATA, ratelimit.STATE = self.orig

    def test_only_the_stream_site_is_limited(self):
        self.assertEqual(ratelimit.site_of("https://v2.streameast.ga/x"), "streameast.ga")
        self.assertIsNone(ratelimit.site_of("https://o300801.mp.lura.live/seg.ts"))

    def test_429_opens_breaker_for_all_mirrors_of_the_site(self):
        ratelimit.after("https://www.streameast.ga/", 429, "error code: 1015")
        self.assertIsNotNone(ratelimit.before("https://v2.streameast.ga/"))
        self.assertIsNone(ratelimit.before("https://dembed.st/player"))

    def test_backoff_doubles_then_success_closes(self):
        url = "https://www.streameast.ga/"
        ratelimit.after(url, 429)
        first = ratelimit.status()["streameast.ga"]
        ratelimit.after(url, 429)
        second = ratelimit.status()["streameast.ga"]
        self.assertGreater(second, first * 1.3)
        ratelimit.after(url, 200)
        self.assertEqual(ratelimit.status(), {})

    def test_challenge_page_counts_as_block(self):
        self.assertTrue(ratelimit.is_block(403, "<title>Just a moment...</title>"))
        self.assertFalse(ratelimit.is_block(403, "forbidden"))

    def test_spacing(self):
        t0 = time.time()
        for _ in range(3):
            ratelimit.before("https://www.streameast.ga/")
        self.assertGreaterEqual(time.time() - t0, 2 * ratelimit.CFG["min_interval_s"] - 0.05)


if __name__ == "__main__":
    unittest.main()
