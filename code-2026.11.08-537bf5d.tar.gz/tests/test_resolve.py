"""Offline tests for resolver/resolve.py against saved real pages.

    python3 -m unittest discover -s tests

No network: a fake fetcher serves fixtures by URL. Run before every release
so a rules.json edit for a new chain can't silently break an old one.
"""
import copy, json, os, sys, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
FIX = os.path.join(HERE, "fixtures")
sys.path.insert(0, os.path.join(HERE, "..", "resolver"))
import resolve  # noqa: E402

with open(resolve.RULES_PATH, encoding="utf-8") as f:
    RULES = json.load(f)


def fixture(name):
    with open(os.path.join(FIX, name), encoding="utf-8", errors="replace") as f:
        return f.read()


MATCH = "https://www.streameast.ga/nfl/falcons-colts-live"
MATCH_HTML = """<html><body><div class="match" data-state="live">
<iframe src="https://example.com/sso-frame"></iframe>
<iframe
  class="player" src="{src}" allowfullscreen></iframe></div></body></html>"""
LEGACY_PLAYER = '<script src="//cdn.streame.center/hls.php?stream=ch12"></script>'
LEGACY_HLS = 'var x; const streamUrl = "https://hls.example.net/live/ch12.m3u8?a=1\\u0026b=2";'
PLAYLIST = "#EXTM3U\n#EXT-X-VERSION:3\n#EXTINF:6,\nseg1.ts\n"


class FakeFetcher:
    def __init__(self, pages):
        self.pages, self.calls = pages, []

    def get(self, url, referer=None, origin=None, timeout=25):
        self.calls.append((url, referer, origin))
        for prefix, resp in self.pages.items():
            if url.startswith(prefix):
                return resp
        return 404, "not found"

    def close(self):
        pass


class ResolveTest(unittest.TestCase):
    def setUp(self):
        import tempfile
        self.snaps = tempfile.mkdtemp()
        self.orig_snap = resolve.SNAP_DIR
        resolve.SNAP_DIR = self.snaps

    def tearDown(self):
        import shutil
        resolve.SNAP_DIR = self.orig_snap
        shutil.rmtree(self.snaps)

    def test_inline_clappr_match_page(self):
        manifest = "https://u.steast.io/ps/c463/index.m3u8"
        code, res, fake = self.run_resolve({
            MATCH: (200, fixture("inline_clappr_match.html")),
            manifest: (200, PLAYLIST),
        })
        self.assertEqual(code, resolve.OK)
        self.assertEqual(res["M3U8"], manifest)
        self.assertEqual(res["REFERER"], "https://www.streameast.ga/")
        self.assertNotIn("ORIGIN", res)
        verify = [c for c in fake.calls if c[0] == manifest][0]
        self.assertEqual(verify[1], "https://www.streameast.ga/")     # Referer sent: required upstream

    def test_inline_plain_string_variant(self):
        page = '<div data-state="live"><script>var streamUrl = "https://cdn.example/x/index.m3u8";</script></div>'
        code, res, _ = self.run_resolve({MATCH: (200, page), "https://cdn.example/x/index.m3u8": (200, PLAYLIST)})
        self.assertEqual(code, resolve.OK)
        self.assertEqual(res["M3U8"], "https://cdn.example/x/index.m3u8")

    def test_inline_with_unknown_decode_step_is_changed_not_a_crash(self):
        rules = copy.deepcopy(RULES)
        for r in rules["chains"]:
            if r["name"] == "inline_clappr":
                r["decode"] = ["base64", "rot47"]
        code, _, _ = self.run_resolve({MATCH: (200, fixture("inline_clappr_match.html"))}, rules)
        self.assertEqual(code, resolve.CHANGED)

    def test_unmatched_page_is_snapshotted_once(self):
        page = MATCH_HTML.format(src="https://new-player.example/embed/1")
        pages = {MATCH: (200, page), "https://new-player.example/embed/1": (200, "<video id=v></video>")}
        code, _, _ = self.run_resolve(pages)
        self.assertEqual(code, resolve.CHANGED)
        files = os.listdir(self.snaps)
        self.assertEqual(len(files), 1)
        body = open(os.path.join(self.snaps, files[0]), encoding="utf-8").read()
        self.assertIn("new-player.example/embed/1", body)
        self.assertIn("<video id=v>", body)          # the child page is in it too
        self.run_resolve(pages)
        self.assertEqual(len(os.listdir(self.snaps)), 1)   # same URL, same day: not duplicated

    def run_resolve(self, pages, rules=RULES):
        fake = FakeFetcher(pages)
        orig_fetcher, orig_load = resolve.Fetcher, resolve.json.load
        resolve.Fetcher = lambda: fake
        resolve.json.load = lambda f: copy.deepcopy(rules)
        try:
            code, res = resolve.resolve(MATCH)
        finally:
            resolve.Fetcher, resolve.json.load = orig_fetcher, orig_load
        return code, res, fake

    def test_edge_token_through_wrapper(self):
        code, res, fake = self.run_resolve({
            MATCH: (200, MATCH_HTML.format(src="https://thedaddy.top/stream/stream-44.php")),
            "https://thedaddy.top/stream/stream-44.php": (200, fixture("edge_token_wrapper.html")),
            "https://dembed.st/premiumtv/daddy.php": (200, fixture("edge_token_player.html")),
            "https://edge.wedd48c.top/api/playlist-token": (200, '{"token":"abc/def","ttl":120}'),
            "https://edge.wedd48c.top/premium44/index.m3u8": (200, PLAYLIST),
        })
        self.assertEqual(code, resolve.OK)
        self.assertTrue(res["M3U8"].startswith("https://edge.wedd48c.top/premium44/index.m3u8?t=abc%2Fdef&_="))
        self.assertEqual(res["ORIGIN"], "https://dembed.st")
        self.assertEqual(res["REFERER"], "https://dembed.st/")
        self.assertIn("EXPIRES", res)
        self.assertEqual(res["IFRAME"], "https://thedaddy.top/stream/stream-44.php")
        tok = [c for c in fake.calls if "playlist-token" in c[0]][0]
        self.assertEqual(tok[0], "https://edge.wedd48c.top/api/playlist-token?slug=premium44")
        self.assertEqual(tok[2], "https://dembed.st")      # Origin is required by the edge
        self.assertFalse(any("sso-frame" in c[0] for c in fake.calls))

    def test_vttp(self):
        embed = "https://playhaxballl.com/NflStreamEmbed.php?ch=falcons"
        code, res, _ = self.run_resolve({
            MATCH: (200, MATCH_HTML.format(src=embed)),
            embed: (200, fixture("vttp_embed.html")),
        })
        self.assertEqual(code, resolve.OK)
        self.assertEqual(res["CHAIN"], "vttp")
        self.assertEqual(res["M3U8"], embed)

    def test_legacy_hls_php(self):
        code, res, _ = self.run_resolve({
            MATCH: (200, MATCH_HTML.format(src="https://streame.center/ch12.php")),
            "https://streame.center/ch12.php": (200, LEGACY_PLAYER),
            "https://cdn.streame.center/hls.php": (200, LEGACY_HLS),
            "https://hls.example.net/": (200, PLAYLIST),
        })
        self.assertEqual(code, resolve.OK)
        self.assertEqual(res["M3U8"], "https://hls.example.net/live/ch12.m3u8?a=1&b=2")
        self.assertEqual(res["REFERER"], "https://streame.center")

    def test_unknown_player_is_changed(self):
        code, _, _ = self.run_resolve({
            MATCH: (200, MATCH_HTML.format(src="https://xstream.st/embed/1")),
            "https://xstream.st/": (200, "<html><video id=v></video></html>"),
        })
        self.assertEqual(code, resolve.CHANGED)

    def test_broken_rule_is_changed_not_crash(self):
        rules = copy.deepcopy(RULES)
        for r in rules["chains"]:
            r["detect"] = "this-will-never-match"
        embed = "https://playhaxballl.com/NflStreamEmbed.php?ch=falcons"
        code, _, _ = self.run_resolve({
            MATCH: (200, MATCH_HTML.format(src=embed)),
            embed: (200, fixture("vttp_embed.html")),
        }, rules)
        self.assertEqual(code, resolve.CHANGED)

    def test_ended(self):
        code, _, _ = self.run_resolve({MATCH: (200, '<div data-state="ended"></div><iframe src="x">')})
        self.assertEqual(code, resolve.GONE)

    def test_rate_limited(self):
        code, _, _ = self.run_resolve({MATCH: (429, "error code: 1015")})
        self.assertEqual(code, resolve.BLOCKED)

    def test_429_with_real_page_still_resolves(self):
        embed = "https://playhaxballl.com/NflStreamEmbed.php?ch=falcons"
        code, _, _ = self.run_resolve({
            MATCH: (429, MATCH_HTML.format(src=embed)),
            embed: (200, fixture("vttp_embed.html")),
        })
        self.assertEqual(code, resolve.OK)

    def test_bad_manifest_is_transient(self):
        code, _, _ = self.run_resolve({
            MATCH: (200, MATCH_HTML.format(src="https://streame.center/ch12.php")),
            "https://streame.center/ch12.php": (200, LEGACY_PLAYER),
            "https://cdn.streame.center/hls.php": (200, LEGACY_HLS),
            "https://hls.example.net/": (403, "forbidden"),
        })
        self.assertEqual(code, resolve.TRANSIENT)


if __name__ == "__main__":
    unittest.main()
