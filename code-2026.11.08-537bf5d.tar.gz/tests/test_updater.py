"""Offline tests for the signed update channel: ed25519, channel verification,
rules hot-apply, code install + flip, canary pass/rollback. A fake channel
directory stands in for GitHub; the stick layout is built in a temp dir.

    python3 -m unittest discover -s tests
"""
import io, json, os, shutil, sys, tarfile, tempfile, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "se-site"))
import ed25519, updater  # noqa: E402

SK = bytes.fromhex("9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60")
PK = ed25519.publickey(SK)

PASSING_TEST = "import unittest\nclass T(unittest.TestCase):\n    def test_ok(self): pass\n"
FAILING_TEST = "import unittest\nclass T(unittest.TestCase):\n    def test_bad(self): self.fail('broken')\n"


class Ed25519Test(unittest.TestCase):
    def test_rfc8032_vector_1(self):
        self.assertEqual(PK.hex(), "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a")
        sig = ed25519.sign(b"", SK, PK)
        self.assertEqual(sig.hex(), "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e0652249015"
                                    "55fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b")
        self.assertTrue(ed25519.verify(sig, b"", PK))
        self.assertFalse(ed25519.verify(sig, b"x", PK))
        self.assertFalse(ed25519.verify(sig[:-1] + b"\0", b"", PK))


def build_tree(path, version, tests_pass=True):
    shutil.rmtree(path, ignore_errors=True)
    os.makedirs(os.path.join(path, "se-site"))
    os.makedirs(os.path.join(path, "resolver"))
    os.makedirs(os.path.join(path, "tests"))
    for f in ("relay_server.py", "watchdog.sh", "updater.py"):
        with open(os.path.join(path, "se-site", f), "w") as fh:
            fh.write("# stub\n")
    with open(os.path.join(path, "se-site", "rules.json"), "w") as fh:
        json.dump({"version": "r-bundled", "chains": {}, "crawl": {}}, fh)
    with open(os.path.join(path, "se-site", "VERSION"), "w") as fh:
        fh.write(version)
    with open(os.path.join(path, "tests", "test_x.py"), "w") as fh:
        fh.write(PASSING_TEST if tests_pass else FAILING_TEST)


def make_tar(tree):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for root, _, files in os.walk(tree):
            for f in files:
                p = os.path.join(root, f)
                tar.add(p, arcname=os.path.relpath(p, tree))
    return buf.getvalue()


class UpdaterTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.root = os.path.join(self.tmp, "streaming")
        self.chan = os.path.join(self.tmp, "channel")
        os.makedirs(self.chan)
        os.makedirs(os.path.join(self.root, "releases"))
        os.makedirs(os.path.join(self.root, "state", "data"))
        build_tree(os.path.join(self.root, "releases", "v0"), "v0")
        updater.link_state(os.path.join(self.root, "releases", "v0"), os.path.join(self.root, "state"))
        os.symlink("releases/v0", os.path.join(self.root, "current"))
        with open(os.path.join(self.root, "state", "rules.json"), "w") as f:
            json.dump({"version": "r0", "chains": {}, "crawl": {}}, f)
        with open(os.path.join(self.root, "state", "release.pub"), "w") as f:
            f.write(PK.hex())
        self.now = 1_000_000
        self.health_reply = {"ok": True, "version": "v0"}

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def publish(self, published, rules=None, code=None, tamper_sig=False, bad_sha=False):
        ch = {"published": published}
        if rules:
            data = json.dumps({"version": rules, "chains": {}, "crawl": {}}).encode()
            with open(os.path.join(self.chan, f"rules-{rules}.json"), "wb") as f:
                f.write(data)
            ch["rules"] = {"version": rules, "file": f"rules-{rules}.json", "sha256": updater.sha256(data)}
        if code:
            ver, ok = code
            tree = os.path.join(self.tmp, "tree-" + ver)
            build_tree(tree, ver, tests_pass=ok)
            data = make_tar(tree)
            with open(os.path.join(self.chan, f"code-{ver}.tar.gz"), "wb") as f:
                f.write(data)
            ch["code"] = {"version": ver, "file": f"code-{ver}.tar.gz",
                          "sha256": "0" * 64 if bad_sha else updater.sha256(data)}
        raw = json.dumps(ch).encode()
        with open(os.path.join(self.chan, "channel.json"), "wb") as f:
            f.write(raw)
        sig = ed25519.sign(raw, SK, PK)
        if tamper_sig:
            sig = bytes([sig[0] ^ 1]) + sig[1:]
        with open(os.path.join(self.chan, "channel.json.sig"), "w") as f:
            f.write(sig.hex())

    def fetch(self, url):
        with open(os.path.join(self.chan, url.rsplit("/", 1)[1]), "rb") as f:
            return f.read()

    def updater(self):
        return updater.Updater(self.root, fetch=self.fetch, now=self.now, channel="http://chan/",
                               health=lambda: self.health_reply, log=lambda s: None)

    def current(self):
        return os.path.basename(os.readlink(os.path.join(self.root, "current")))

    def kinds(self, u):
        return [e["kind"] for e in u.status["events"]]

    def test_good_release_applies_rules_and_installs_code(self):
        self.publish(100, rules="r1", code=("v1", True))
        u = self.updater()
        u.check()
        self.assertEqual(json.load(open(os.path.join(self.root, "state", "rules.json")))["version"], "r1")
        self.assertEqual(self.current(), "v1")
        self.assertEqual(u.current_version(), "v1")
        self.assertTrue(os.path.islink(os.path.join(self.root, "releases", "v1", "se-site", "data")))
        self.assertTrue(os.path.exists(os.path.join(self.root, "state", "restart-services")))
        self.assertEqual(u.st["pending_canary"]["version"], "v1")
        self.assertEqual(self.kinds(u), ["installed", "applied_rules"])   # code first
        self.assertEqual(u.st["published"], 100)

    def test_bad_signature_changes_nothing(self):
        self.publish(100, rules="r1", code=("v1", True), tamper_sig=True)
        u = self.updater()
        u.check()
        self.assertEqual(self.current(), "v0")
        self.assertEqual(u.rules_version(), "r0")
        self.assertEqual(self.kinds(u), ["rejected"])
        self.assertNotIn("last_ok_check", u.status)

    def test_sha_mismatch_is_refused(self):
        self.publish(100, code=("v1", True), bad_sha=True)
        u = self.updater()
        u.check()
        self.assertEqual(self.current(), "v0")
        self.assertEqual(self.kinds(u), ["failed"])
        self.assertFalse(os.path.exists(os.path.join(self.root, "releases", "v1")))

    def test_older_channel_is_ignored(self):
        self.publish(100, rules="r1")
        self.updater().check()
        self.publish(50, rules="r2")
        u = self.updater()
        u.check()
        self.assertEqual(u.rules_version(), "r1")

    def test_release_whose_tests_fail_is_not_installed(self):
        self.publish(100, code=("v1", False))
        u = self.updater()
        u.check()
        self.assertEqual(self.current(), "v0")
        self.assertIn("v1", u.st["blocked"])
        self.assertEqual(self.kinds(u), ["failed"])
        self.assertFalse(os.path.exists(os.path.join(self.root, "releases", "v1")))
        # and it isn't retried on the next check
        self.publish(101, code=("v1", False))
        u2 = self.updater()
        u2.check()
        self.assertEqual(self.kinds(u2), ["failed"])      # the earlier event, nothing new

    def write_cycle(self, ts, crawl_rc=0, build_rc=0, resolved=1, total_live=1):
        with open(os.path.join(self.root, "state", "data", "cycle_status.json"), "w") as f:
            json.dump({"ts": ts, "crawl_rc": crawl_rc, "build_rc": build_rc}, f)
        with open(os.path.join(self.root, "state", "data", "resolve_status.json"), "w") as f:
            json.dump({"ts": ts, "resolved": resolved, "total_live": total_live}, f)

    def install_v1(self):
        self.write_cycle(self.now - 10, resolved=2, total_live=3)
        self.publish(100, code=("v1", True))
        self.updater().check()
        self.assertEqual(self.current(), "v1")

    def test_canary_passes_when_cycle_and_relay_are_healthy(self):
        self.install_v1()
        self.now += 60
        self.assertEqual(self.updater().canary(), "waiting")       # too early to judge
        self.now += 200
        self.write_cycle(self.now - 5, resolved=2, total_live=3)
        self.health_reply = {"ok": True, "version": "v1"}
        u = self.updater()
        self.assertEqual(u.canary(), "passed")
        self.assertNotIn("pending_canary", u.st)
        self.assertEqual(self.kinds(u)[-1], "applied_code")

    def test_canary_waits_while_old_relay_still_serves(self):
        self.install_v1()
        self.now += 300
        self.write_cycle(self.now - 5, resolved=2, total_live=3)
        self.health_reply = {"ok": True, "version": "v0"}         # restart deferred: a game is on
        self.assertEqual(self.updater().canary(), "waiting")

    def test_canary_rolls_back_on_crashing_cycle(self):
        self.install_v1()
        os.unlink(os.path.join(self.root, "state", "restart-services"))
        self.now += 300
        self.write_cycle(self.now - 5, crawl_rc=1)
        u = self.updater()
        self.assertEqual(u.canary(), "rolled_back")
        self.assertEqual(self.current(), "v0")
        self.assertIn("v1", u.st["blocked"])
        self.assertTrue(os.path.exists(os.path.join(self.root, "state", "restart-services")))
        self.assertEqual(self.kinds(u)[-1], "rolled_back")

    def test_canary_rolls_back_when_games_stop_resolving(self):
        self.install_v1()
        self.now += 300
        self.write_cycle(self.now - 5, resolved=0, total_live=3)
        self.assertEqual(self.updater().canary(), "rolled_back")
        self.assertEqual(self.current(), "v0")

    def test_canary_rolls_back_when_no_cycle_ever_completes(self):
        self.install_v1()
        self.now += updater.CANARY_MAX_S + 1
        self.assertEqual(self.updater().canary(), "rolled_back")

    def test_rules_wait_while_their_code_is_in_canary(self):
        self.install_v1()                                   # v1 pending canary
        self.publish(200, rules="r9", code=("v2", True))
        u = self.updater()
        u.check()
        self.assertEqual(u.rules_version(), "r0")           # not applied to the old code
        self.assertEqual(self.current(), "v1")
        self.assertNotEqual(u.st["published"], 200)         # channel re-read next time

    def test_rules_only_release(self):
        self.publish(100, rules="r5")
        u = self.updater()
        u.check()
        self.assertEqual(u.rules_version(), "r5")
        self.assertEqual(self.current(), "v0")
        self.assertEqual(self.kinds(u), ["applied_rules"])

    def test_tick_runs_check_only_when_due(self):
        self.publish(100, rules="r1")
        u = self.updater()
        u.tick()
        self.assertEqual(u.rules_version(), "r1")
        self.publish(101, rules="r2")
        u = self.updater()
        u.tick()                                                   # 0s later: not due
        self.assertEqual(u.rules_version(), "r1")
        self.now += updater.CHECK_EVERY_S + 1
        u = self.updater()
        u.tick()
        self.assertEqual(u.rules_version(), "r2")


if __name__ == "__main__":
    unittest.main()
