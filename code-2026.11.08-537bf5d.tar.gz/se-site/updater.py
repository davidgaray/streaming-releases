#!/usr/bin/env python3
"""updater.py - the stick updates itself from a signed release channel.

Why: every fix so far needed the Mac, adb and a person. Mom's stick is on her
own network; the only way to fix it is for it to fetch the fix. The site
changes weekly, so most fixes are rules.json edits that must land without a
restart; code changes must land without killing a game and must undo
themselves if they don't work.

Layout on the stick (~/streaming):
    current -> releases/<version>        atomic switch = rename the symlink
    releases/<version>/{se-site,resolver,tests}
    state/{data,dist,rules.json,notify.conf,*.log,release.pub,updater_state.json}
Each release's se-site/ has symlinks (data, dist, rules.json, notify.conf,
logs) into state/, so releases are disposable and state survives them.

Channel (a public GitHub repo, read via raw.githubusercontent.com):
    channel.json       {"published": <unix ts>, "rules": {version, sha256, file},
                        "code": {version, sha256, file}}
    channel.json.sig   hex ed25519 signature over channel.json's exact bytes
    rules-<v>.json, code-<v>.tar.gz
The signature is checked against state/release.pub (installed at
provisioning, never fetched). Anything unsigned, mis-signed, with a wrong
sha256, or older than what's already applied is ignored and reported.

Tiers:
  rules  -> atomic replace of state/rules.json. crawl/resolve are fresh
            processes each cycle and the relay re-reads rules when its
            mtime changes, so this takes effect within one cycle, no restart.
  code   -> download, verify, unpack to releases/<v>/, link state, run the
            bundled offline tests ON THE STICK, flip `current`, ask the
            watchdog to restart services (refresh-loop now, itself now, the
            relay when no stream is playing), then run a canary over the next
            minutes: a crawl+build cycle must succeed, the relay must come up
            healthy on the new version, and if games were resolving before
            they must still resolve. Fail -> flip back, block that version,
            restart again, alert.

Run by watchdog.sh every minute as `updater.py --tick` (canary if one is
pending, full check every CHECK_EVERY_S); `--now` forces a full check.
Status for notify.py goes to state/data/update_status.json.
"""
import fcntl, hashlib, io, json, os, shutil, subprocess, sys, tarfile, tempfile, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import ed25519, fsutil  # noqa: E402

DEFAULT_CHANNEL = "https://raw.githubusercontent.com/davidgaray/streaming-releases/main/"
CHECK_EVERY_S = 30 * 60
CANARY_MIN_S = 180          # don't judge a release before it has had a cycle
CANARY_MAX_S = 20 * 60      # no successful cycle by then = broken
CANARY_RELAY_MAX_S = 7 * 3600   # the relay restart waits for an idle moment (<= 6h), then +1h grace
KEEP_RELEASES = 2           # current + previous
STATE_LINKS = ["data", "dist", "rules.json", "notify.conf", "watchdog.log", "relay.log",
               "refresh-loop.log", "http.log", "updater.log"]
_TERMUX_CURL = "/data/data/com.termux/files/usr/bin/curl"
CURL = _TERMUX_CURL if os.path.exists(_TERMUX_CURL) else "curl"


class Rejected(Exception):
    """The channel can't be trusted (bad signature, no key, malformed)."""


def find_root(here=HERE):
    """~/streaming for both layouts: releases/<v>/se-site (physical path),
    current/se-site (logical) and the legacy flat se-site/."""
    p = os.path.dirname(here)
    if os.path.islink(p):
        return os.path.dirname(p)
    if os.path.basename(os.path.dirname(p)) == "releases":
        return os.path.dirname(os.path.dirname(p))
    return p


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def curl_fetch(url, timeout=90):
    r = subprocess.run([CURL, "-fsSL", "-m", str(timeout), "-A", "se-site-updater", url],
                       capture_output=True, timeout=timeout + 10)
    if r.returncode != 0:
        raise IOError(f"curl {r.returncode} for {url}: {r.stderr.decode(errors='replace')[:200]}")
    return r.stdout


def http_health(port=8080):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=5) as r:
            return json.loads(r.read().decode())
    except Exception:
        return None


def link_state(release_dir, state_dir):
    """Point the release's se-site state paths into state/ (created empty if missing)."""
    site = os.path.join(release_dir, "se-site")
    os.makedirs(os.path.join(state_dir, "data"), exist_ok=True)
    os.makedirs(os.path.join(state_dir, "dist"), exist_ok=True)
    for name in STATE_LINKS:
        target = os.path.join(state_dir, name)
        link = os.path.join(site, name)
        if name == "rules.json" and not os.path.exists(target) and os.path.isfile(link) and not os.path.islink(link):
            shutil.copy2(link, target)          # first release seeds the state copy
        if os.path.islink(link) or os.path.isfile(link):
            os.unlink(link)
        elif os.path.isdir(link):
            shutil.rmtree(link)
        os.symlink(os.path.relpath(target, site), link)


def _safe_members(tar):
    for m in tar.getmembers():
        if m.name.startswith("/") or ".." in m.name.split("/") or m.issym() or m.islnk():
            raise ValueError(f"unsafe path in release: {m.name}")
        yield m


class Updater:
    def __init__(self, root, fetch=None, now=None, health=None, run_tests=True, channel=None, log=None):
        self.root = root
        self.state_dir = os.path.join(root, "state")
        self.releases = os.path.join(root, "releases")
        self.current = os.path.join(root, "current")
        self.fetch = fetch or curl_fetch
        self.health = health or http_health
        self.run_tests = run_tests
        self._now = now
        self._log = log or (lambda s: print(f"[updater] {s}", file=sys.stderr))
        os.makedirs(os.path.join(self.state_dir, "data"), exist_ok=True)
        self.state_path = os.path.join(self.state_dir, "updater_state.json")
        self.status_path = os.path.join(self.state_dir, "data", "update_status.json")
        self.st = self._load(self.state_path, {})
        self.status = self._load(self.status_path, {"events": []})
        self.channel = channel or self._conf().get("CHANNEL_URL") or DEFAULT_CHANNEL
        if not self.channel.endswith("/"):
            self.channel += "/"

    # -- plumbing --------------------------------------------------------
    def now(self):
        return time.time() if self._now is None else self._now

    @staticmethod
    def _load(path, default):
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return default

    def _conf(self):
        out = {}
        try:
            for line in open(os.path.join(self.state_dir, "update.conf"), encoding="utf-8"):
                if "=" in line and not line.lstrip().startswith("#"):
                    k, v = line.split("=", 1)
                    out[k.strip()] = v.strip()
        except FileNotFoundError:
            pass
        return out

    def save(self):
        fsutil.write_json_atomic(self.state_path, self.st)
        self.status["events"] = self.status["events"][-20:]
        fsutil.write_json_atomic(self.status_path, self.status)

    def log(self, msg):
        self._log(msg)

    def event(self, kind, text):
        self.log(f"{kind}: {text}")
        self.status["events"].append({"ts": int(self.now()), "kind": kind, "text": text})

    def pubkey(self):
        for p in (os.path.join(self.state_dir, "release.pub"), os.path.join(HERE, "release.pub")):
            try:
                with open(p, encoding="utf-8") as f:
                    return bytes.fromhex(f.read().strip())
            except (OSError, ValueError):
                continue
        return None

    def current_target(self):
        try:
            return os.path.basename(os.readlink(self.current))
        except OSError:
            return None

    def current_version(self):
        try:
            with open(os.path.join(self.current, "se-site", "VERSION"), encoding="utf-8") as f:
                return f.read().strip()
        except OSError:
            return None

    def rules_path(self):
        p = os.path.join(self.state_dir, "rules.json")
        return p if os.path.exists(p) else os.path.join(self.current, "se-site", "rules.json")

    def rules_version(self):
        return (self._load(self.rules_path(), {}) or {}).get("version")

    def request_restart(self, reason):
        """Ask the watchdog to restart services (it does the relay when idle)."""
        fsutil.write_atomic(os.path.join(self.state_dir, "deploying"), reason)
        fsutil.write_atomic(os.path.join(self.state_dir, "restart-services"), reason)

    # -- the channel -----------------------------------------------------
    def read_channel(self):
        """The verified channel dict, None when it isn't newer than what we
        have, Rejected when it can't be trusted."""
        pk = self.pubkey()
        if pk is None:
            raise Rejected("no release.pub on this stick - can't verify updates")
        raw = self.fetch(self.channel + "channel.json")
        try:
            sig = bytes.fromhex(self.fetch(self.channel + "channel.json.sig").decode().strip())
        except ValueError:
            raise Rejected("channel.json.sig is not a hex signature")
        if not ed25519.verify(sig, raw, pk):
            raise Rejected("channel.json signature does not verify - ignoring it")
        ch = json.loads(raw)
        if not isinstance(ch.get("published"), int):
            raise Rejected("channel.json has no 'published' timestamp")
        if ch["published"] <= self.st.get("published", 0):
            self.log(f"channel published {ch['published']} is not newer than {self.st.get('published')} - nothing to do")
            return None
        return ch

    def fetch_artifact(self, entry):
        data = self.fetch(self.channel + entry["file"])
        if sha256(data) != entry["sha256"]:
            raise ValueError(f"{entry['file']}: sha256 mismatch")
        return data

    # -- rules tier ------------------------------------------------------
    def apply_rules(self, entry):
        if entry["version"] == self.rules_version():
            return False
        data = self.fetch_artifact(entry)
        rules = json.loads(data)
        if rules.get("version") != entry["version"] or "chains" not in rules or "crawl" not in rules:
            raise ValueError("rules file doesn't look like rules.json")
        fsutil.write_atomic(self.rules_path(), data)
        self.event("applied_rules", f"rules {entry['version']} applied (hot, no restart)")
        return True

    # -- code tier -------------------------------------------------------
    def apply_code(self, entry):
        ver = entry["version"]
        if ver == self.current_version():
            return False
        if ver in self.st.get("blocked", []):
            self.log(f"code {ver} was rolled back before - not trying it again")
            return False
        data = self.fetch_artifact(entry)
        os.makedirs(self.releases, exist_ok=True)
        tmp = tempfile.mkdtemp(prefix=".new-", dir=self.releases)
        try:
            with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tar:
                tar.extractall(tmp, members=_safe_members(tar))
            for must in ("se-site/relay_server.py", "se-site/watchdog.sh", "se-site/updater.py", "tests"):
                if not os.path.exists(os.path.join(tmp, must)):
                    raise ValueError(f"release is missing {must}")
            fsutil.write_atomic(os.path.join(tmp, "se-site", "VERSION"), ver)
            for f in os.listdir(os.path.join(tmp, "se-site")):
                if f.endswith((".sh", ".py")) or f == "se-resolve":
                    os.chmod(os.path.join(tmp, "se-site", f), 0o700)
            for f in os.listdir(os.path.join(tmp, "resolver")) if os.path.isdir(os.path.join(tmp, "resolver")) else []:
                os.chmod(os.path.join(tmp, "resolver", f), 0o700)
            link_state(tmp, self.state_dir)
            if self.run_tests:
                r = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", os.path.join(tmp, "tests")],
                                   capture_output=True, text=True, timeout=300, cwd=tmp)
                if r.returncode != 0:
                    tail = "\n".join(r.stderr.strip().splitlines()[-6:])
                    self.st.setdefault("blocked", []).append(ver)
                    self.event("failed", f"code {ver}: its own tests fail on this stick - not installed. {tail[:400]}")
                    return False
            dest = os.path.join(self.releases, ver)
            if os.path.exists(dest):
                shutil.rmtree(dest)
            os.rename(tmp, dest)
            tmp = None
        finally:
            if tmp and os.path.exists(tmp):
                shutil.rmtree(tmp, ignore_errors=True)
        prev = self.current_target()
        status = self._load(os.path.join(self.state_dir, "data", "resolve_status.json"), {})
        self.flip(ver)
        self.st["pending_canary"] = {"version": ver, "prev": prev, "since": self.now(),
                                     "pre_resolved": status.get("resolved", 0), "relay_misses": 0}
        self.event("installed", f"code {ver} installed; services restarting, canary running")
        self.request_restart(f"update {ver}")
        return True

    def flip(self, ver):
        tmp_link = self.current + ".tmp"
        if os.path.lexists(tmp_link):
            os.unlink(tmp_link)
        os.symlink(os.path.join("releases", ver), tmp_link)
        os.replace(tmp_link, self.current)      # rename(2): atomic swap of the symlink
        self.log(f"current -> releases/{ver}")

    # -- canary ----------------------------------------------------------
    def canary(self):
        pc = self.st.get("pending_canary")
        if not pc:
            return None
        age = self.now() - pc["since"]
        if age < CANARY_MIN_S:
            return "waiting"
        cycle = self._load(os.path.join(self.state_dir, "data", "cycle_status.json"), {})
        status = self._load(os.path.join(self.state_dir, "data", "resolve_status.json"), {})
        fresh_cycle = cycle.get("ts", 0) > pc["since"]
        if fresh_cycle and (cycle.get("crawl_rc") or cycle.get("build_rc")):
            return self.rollback(f"crawl/build exit codes {cycle.get('crawl_rc')}/{cycle.get('build_rc')} on {pc['version']}")
        if not fresh_cycle and age > CANARY_MAX_S:
            return self.rollback(f"no refresh cycle completed in {int(age / 60)} min on {pc['version']}")
        if fresh_cycle and pc["pre_resolved"] > 0 and status.get("total_live", 0) > 0 and not status.get("resolved"):
            return self.rollback(f"games stopped resolving on {pc['version']} ({status.get('total_live')} live, 0 playable)")
        h = self.health()
        if h is None:
            pc["relay_misses"] = pc.get("relay_misses", 0) + 1
            if pc["relay_misses"] >= 3:
                return self.rollback(f"relay not answering on {pc['version']}")
            return "waiting"
        pc["relay_misses"] = 0
        if h.get("version") != pc["version"]:
            # The old relay is still serving: its restart waits for an idle moment.
            if age > CANARY_RELAY_MAX_S:
                return self.rollback(f"relay never came up on {pc['version']}")
            return "waiting"
        if not h.get("ok"):
            return self.rollback(f"relay reports not ok on {pc['version']}")
        if not fresh_cycle:
            return "waiting"
        del self.st["pending_canary"]
        self.event("applied_code", f"code {pc['version']} is live and healthy")
        self.prune()
        return "passed"

    def rollback(self, reason):
        pc = self.st.pop("pending_canary")
        self.st.setdefault("blocked", []).append(pc["version"])
        if pc.get("prev") and os.path.isdir(os.path.join(self.releases, pc["prev"])):
            self.flip(pc["prev"])
            self.request_restart(f"rollback to {pc['prev']}: {reason}")
            self.event("rolled_back", f"code {pc['version']} rolled back to {pc['prev']}: {reason}")
        else:
            self.event("rolled_back", f"code {pc['version']} failed ({reason}) and there is no previous release to go back to")
        return "rolled_back"

    def prune(self):
        keep = {self.current_target()}
        pc = self.st.get("pending_canary")
        if pc and pc.get("prev"):
            keep.add(pc["prev"])
        try:
            dirs = sorted((os.path.getmtime(os.path.join(self.releases, d)), d) for d in os.listdir(self.releases)
                          if not d.startswith("."))
        except OSError:
            return
        for _, d in dirs[:-KEEP_RELEASES]:
            if d not in keep:
                shutil.rmtree(os.path.join(self.releases, d), ignore_errors=True)
                self.log(f"removed old release {d}")

    # -- entry points ----------------------------------------------------
    def check(self):
        """Full check: read the channel, apply what's new."""
        self.status["last_check"] = int(self.now())
        try:
            ch = self.read_channel()
            if ch is None:
                self.status["last_ok_check"] = int(self.now())
                return
            did = False
            # Code first: new rules may use a chain type only the new code
            # knows (2026-11-08: rules landed a cycle before the code that
            # understood them, and that cycle every NHL game was 'unknown
            # type'). If the code can't be installed now, its rules wait too.
            code_new = ch.get("code") and ch["code"]["version"] != self.current_version() \
                and ch["code"]["version"] not in self.st.get("blocked", [])
            if code_new and not self.st.get("pending_canary"):
                did |= bool(self.apply_code(ch["code"]))
            code_waiting = code_new and ch["code"]["version"] != self.current_version()
            if ch.get("rules") and not code_waiting:
                did |= bool(self.apply_rules(ch["rules"]))
            elif ch.get("rules") and code_waiting:
                self.log("new rules wait for their code release")
                self.st["published"] = self.st.get("published", 0)   # re-read the channel next check
                self.save()
                return
            self.st["published"] = ch["published"]
            self.status["last_ok_check"] = int(self.now())
            if not did:
                self.log("channel read fine; already up to date")
        except Rejected as e:
            self.event("rejected", str(e))
        except Exception as e:
            self.status["last_error"] = f"{type(e).__name__}: {e}"[:300]
            self.event("failed", f"update check failed: {type(e).__name__}: {str(e)[:200]}")
        finally:
            self.status["current"] = self.current_version()
            self.status["rules"] = self.rules_version()
            self.save()

    def tick(self):
        """Once a minute from the watchdog: canary if pending, else a check when due."""
        if self.st.get("pending_canary"):
            res = self.canary()
            self.status["current"] = self.current_version()
            self.save()
            if res in ("waiting",):
                return
        if self.now() - self.st.get("last_check", 0) >= CHECK_EVERY_S:
            self.st["last_check"] = self.now()
            self.check()


def main(argv):
    if argv[:1] == ["--link-state"]:          # used by the deploy bootstrap
        rel = os.path.abspath(argv[1])
        link_state(rel, os.path.join(find_root(os.path.join(rel, "se-site")), "state"))
        return 0
    root = find_root()
    lock = open(os.path.join(root, "state", ".updater.lock") if os.path.isdir(os.path.join(root, "state"))
                else os.path.join(root, ".updater.lock"), "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        return 0                                   # another updater run is still going
    u = Updater(root)
    if "--now" in argv:
        u.check()
    elif "--canary" in argv:
        print(u.canary())
    else:
        u.tick()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
