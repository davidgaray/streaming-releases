#!/system/bin/sh
# Relaunches VLC on whatever it was playing when playback dies on its own.
# Runs as root on the stick, started (and kept alive) by the Magisk boot
# supervisor (service.d/boot_start_watchdog.sh).
#
# Two ways VLC ends a stream that the viewer didn't ask for:
#   - native crash: "Fatal signal ... (org.videolan.vlc)" - e.g. the
#     SegmentList.cpp "duration" assertion in its HLS parser (2026-10-04)
#   - starvation abort: "buffer deadlock prevented" followed within seconds
#     by PlaylistManager "invalid next index, aborted" - VLC gives up the
#     session when segments stop arriving (2026-11-02, every 3-4 min on a bad
#     CDN night). A viewer pressing Back logs neither.
# The URI to relaunch is the last one VLC logged opening ("Expanding uri").
# Only relay URLs (127.0.0.1:8080) are relaunched; at most MAX_RELAUNCHES per
# WINDOW_S, after which it gives up so a dead stream can't loop forever.
# Each relaunch / give-up is appended to $EVENTS for the notifier.
#
#   sh vlc_keeper.sh            run (the supervisor does this)
#   touch /data/local/tmp/vlc_keeper.stop   stop

DIR=/data/local/tmp
LOG=$DIR/vlc_keeper.log
EVENTS=$DIR/supervisor.events
STOP=$DIR/vlc_keeper.stop
MAX_RELAUNCHES=3
WINDOW_S=600
DEADLOCK_TO_ABORT_S=5

log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; }

launch() {
  am start -a android.intent.action.VIEW -d "$1" -t application/vnd.apple.mpegurl \
    -n org.videolan.vlc/.StartActivity >/dev/null 2>&1
}

uri="" deadlock_at=0 recent="" launched_at=0
rm -f "$STOP"
# Keep the log small (the others are capped by watchdog.sh / the supervisor).
[ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 200000 ] && tail -c 50000 "$LOG" > "$LOG.k" && mv "$LOG.k" "$LOG"
log "watching"
# -T 1: only lines from now on, not the backlog. epoch timestamps are easy to compare.
logcat -v epoch -T 1 VLC:* VLC/PlaylistManager:* FileUtils:* libc:F DEBUG:F '*:S' 2>/dev/null |
while IFS= read -r line; do
  [ -f "$STOP" ] && { log "stopped"; exit 0; }
  set -- $line; now=${1%%.*}   # epoch seconds (logcat pads with spaces)
  case "$line" in
    *"Expanding uri: http://127.0.0.1:8080/"*)
      uri=${line#*Expanding uri: }; uri=${uri%% *}
      # A play we didn't just launch is the user picking a game: start the
      # relaunch budget over instead of giving up on their first hiccup.
      [ $((now - launched_at)) -gt 15 ] && recent=""
      # VLC launched from the board sometimes plays audio only, with the
      # board still on screen (2026-11-08): it started in background mode.
      # If its video screen isn't in front 10s after playback began, bring
      # it there. Detached so the logcat read loop isn't held up.
      ( sleep 10
        if ! dumpsys activity activities 2>/dev/null | grep -q "mResumedActivity.*org.videolan.vlc"; then
          if pidof org.videolan.vlc >/dev/null 2>&1; then
            log "playback started but VLC isn't on screen - bringing the player forward"
            am start -n org.videolan.vlc/.gui.video.VideoPlayerActivity >/dev/null 2>&1
          fi
        fi ) & ;;
    *"buffer deadlock prevented"*)
      deadlock_at=$now ;;
    *"invalid next index, aborted"*|*"Fatal signal"*"org.videolan.vlc"*)
      case "$line" in
        *"invalid next index"*) [ $((now - deadlock_at)) -le $DEADLOCK_TO_ABORT_S ] || continue ;;
      esac
      [ -n "$uri" ] || continue
      kept=""; n=0
      for t in $recent; do [ $((now - t)) -lt $WINDOW_S ] && { kept="$kept $t"; n=$((n + 1)); }; done
      recent=$kept
      if [ $n -ge $MAX_RELAUNCHES ]; then
        log "playback died again; already relaunched $n times in ${WINDOW_S}s - giving up"
        echo "$now vlc_gave_up" >> "$EVENTS"
        uri=""
        continue
      fi
      recent="$recent $now"
      log "playback died ($( echo "$line" | grep -q 'Fatal signal' && echo crash || echo starvation )) - relaunching"
      echo "$now vlc_relaunched" >> "$EVENTS"
      sleep 2
      launched_at=$(date +%s)
      launch "$uri" ;;
  esac
done
