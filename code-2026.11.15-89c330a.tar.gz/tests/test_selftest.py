"""Offline tests for selftest.py (fake HTTP) and its alerts in notify.py.

    python3 -m unittest discover -s tests
"""
import json, os, shutil, sys, tempfile, time, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "se-site"))
import fsutil, notify, selftest  # noqa: E402

TS = (b"\x47" + bytes(187)) * 3
PLAYLIST = b"#EXTM3U\n#EXTINF:6,\n/relay?url=https%3A%2F%2Fcdn%2Fa.ts&ref=x\n"


def fake_http(routes):
    """routes: url prefix -> (status, body). Records calls."""
    calls = []

    def get(url, timeout):
        calls.append(url)
        for prefix, (code, body) in routes.items():
            if url.startswith(prefix):
                return code, body, 0.5
        return 0, b"connection refused", 0.1
    get.calls = calls
    return get


class SelftestTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.orig = selftest.DATA
        selftest.DATA = self.tmp
        fsutil.write_json_atomic(os.path.join(self.tmp, "play_links.json"), [
            {"slug": "a-vs-b", "title": "NFL - A vs B", "url": "http://127.0.0.1:8080/vttp.m3u8?embed=x"},
            {"slug": "c-vs-d", "title": "NHL - C vs D", "url": "http://127.0.0.1:8080/relay?url=y"}])

    def tearDown(self):
        selftest.DATA = self.orig
        shutil.rmtree(self.tmp)

    def test_real_video_passes_and_html_fails(self):
        get = fake_http({
            "http://127.0.0.1:8080/health": (200, b'{"active_streams": 0}'),
            "http://127.0.0.1:8080/vttp.m3u8": (200, PLAYLIST),
            "http://127.0.0.1:8080/relay?url=https%3A%2F%2Fcdn%2Fa.ts": (200, TS),
            "http://127.0.0.1:8080/relay?url=y": (502, b"embed page: HTTP Error 403: Forbidden"),
        })
        rep = selftest.run(get)
        res = {r["slug"]: r for r in rep["results"]}
        self.assertTrue(res["a-vs-b"]["ok"])
        self.assertEqual(res["a-vs-b"]["detail"][:2], "ts")
        self.assertFalse(res["c-vs-d"]["ok"])
        self.assertEqual(res["c-vs-d"]["stage"], "playlist")
        self.assertIn("403", res["c-vs-d"]["detail"])
        saved = json.load(open(os.path.join(self.tmp, "selftest.json")))
        self.assertEqual(len(saved["results"]), 2)

    def test_segment_that_is_not_video_fails(self):
        get = fake_http({
            "http://127.0.0.1:8080/health": (200, b'{"active_streams": 0}'),
            "http://127.0.0.1:8080/vttp.m3u8": (200, PLAYLIST),
            "http://127.0.0.1:8080/relay?url=https%3A%2F%2Fcdn%2Fa.ts": (200, b"<html>blocked</html>"),
        })
        res = selftest.run(get)["results"][0]
        self.assertEqual((res["ok"], res["stage"]), (False, "segment"))

    def test_skips_while_someone_is_watching(self):
        get = fake_http({"http://127.0.0.1:8080/health":
                         (200, b'{"active_streams": 1, "last_segment_ok_age_s": 3}')})
        rep = selftest.run(get)
        self.assertEqual(rep["skipped"], "someone is watching")
        self.assertEqual(get.calls, ["http://127.0.0.1:8080/health"])

    def test_a_stuck_viewer_does_not_block_the_test(self):
        get = fake_http({"http://127.0.0.1:8080/health":
                         (200, b'{"active_streams": 1, "last_segment_ok_age_s": null}')})
        self.assertIsNone(selftest.run(get)["skipped"])


class SelftestAlertTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.orig = notify.DATA, notify.DIST, notify.EVENTS, notify.REFRESH_LOG, notify.vpn_active
        notify.DATA, notify.DIST = os.path.join(self.tmp, "data"), os.path.join(self.tmp, "dist")
        notify.EVENTS, notify.REFRESH_LOG = os.path.join(self.tmp, "ev"), os.path.join(self.tmp, "log")
        notify.vpn_active = lambda: False
        os.makedirs(notify.DATA)
        os.makedirs(notify.DIST)
        now = time.time()
        for rel, obj in (("data/site.json", {"games": [], "mirror_health": [{"ok": True}]}),
                         ("data/cycle_status.json", {"ts": 1, "crawl_rc": 0, "build_rc": 0}),
                         ("dist/index.html", "<html>")):
            fsutil.write_atomic(os.path.join(self.tmp, rel), obj if isinstance(obj, str) else json.dumps(obj))
        self.now, self.st, self.sent, self.ts = now, {}, [], 100

    def tearDown(self):
        notify.DATA, notify.DIST, notify.EVENTS, notify.REFRESH_LOG, notify.vpn_active = self.orig
        shutil.rmtree(self.tmp)

    def run_with(self, results):
        self.ts += 1
        fsutil.write_json_atomic(os.path.join(notify.DATA, "selftest.json"),
                                 {"ts": self.ts, "skipped": None, "results": results})

        def send(title, body, prio, tags):
            self.sent.append((title, body))
            return True
        return notify.run({"TOPIC": "t"}, self.st, self.now, send, local_hour=8)

    def test_two_failures_alert_once_then_recovery(self):
        bad = [{"slug": "a", "title": "NFL - A vs B", "ok": False, "stage": "playlist", "detail": "HTTP 502"}]
        self.assertEqual(self.run_with(bad), [])
        self.assertEqual(self.run_with(bad), ["selftest:a"])
        self.assertIn("NFL - A vs B", self.sent[-1][1])
        self.assertEqual(self.run_with(bad), [])
        self.assertEqual(self.run_with([dict(bad[0], ok=True, stage="ok")]), ["selftest_ok:a"])

    def test_game_that_ends_is_dropped_quietly(self):
        bad = [{"slug": "a", "title": "A", "ok": False, "stage": "segment", "detail": "x"}]
        self.run_with(bad)
        self.run_with(bad)
        self.assertEqual(self.run_with([]), [])
        self.assertNotIn("a", self.st["selftest_fails"])

    def test_one_flaky_run_does_not_alert(self):
        bad = [{"slug": "a", "title": "A", "ok": False, "stage": "segment", "detail": "x"}]
        good = [dict(bad[0], ok=True)]
        for r in (bad, good, bad, good):
            self.assertEqual(self.run_with(r), [])


if __name__ == "__main__":
    unittest.main()
