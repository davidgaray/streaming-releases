"""Offline tests for relay_server.py's observability: /health, stream
activity tracking, idle-state eviction and the rules.json hot reload.

    python3 -m unittest discover -s tests
"""
import json, os, sys, tempfile, threading, time, unittest, urllib.parse, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "se-site"))
import relay_server, unwrap  # noqa: E402


class HealthTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = relay_server.Server(("127.0.0.1", 0), relay_server.Handler)
        cls.port = cls.httpd.server_address[1]
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()

    def setUp(self):
        with relay_server._activity_lock:
            relay_server._activity.clear()

    def get(self, path):
        with urllib.request.urlopen(f"http://127.0.0.1:{self.port}{path}", timeout=5) as r:
            return r.status, r.headers.get("Content-Type"), r.read()

    def test_health_reports_state(self):
        status, ctype, body = self.get("/health")
        self.assertEqual(status, 200)
        self.assertEqual(ctype, "application/json")
        h = json.loads(body)
        self.assertTrue(h["ok"])
        self.assertEqual(h["active_streams"], 0)
        self.assertIn("version", h)
        self.assertEqual(h["rules_version"], json.load(open(relay_server.RULES_PATH))["version"])
        self.assertGreaterEqual(h["uptime_s"], 0)

    def test_active_streams_counts_recent_polls_only(self):
        relay_server._touch("match-a")
        relay_server._touch("vttp:embed-b")
        self.assertEqual(relay_server.active_streams(), 2)
        self.assertEqual(json.loads(self.get("/health")[2])["active_streams"], 2)
        self.assertEqual(relay_server.active_streams(time.time() + relay_server.ACTIVE_S + 1), 0)

    def test_vttp_embed_on_the_match_page_uses_the_resolver_fetcher(self):
        """2026-11-15: the NFL vttp player moved onto the stream site's match
        page, which 403s urllib. The relay must fetch it like the resolver
        does, and accept a 429 that still carries the page."""
        html = open(os.path.join(HERE, "fixtures", "vttp_embed.html"), encoding="utf-8").read()
        calls = []

        class FakeChannel:
            def __init__(self, hosts, channel, masterinf, origin):
                self.alive, self.updated = True, time.time()
                self.ready = threading.Event()
                self.ready.set()
                self.origin = origin

            def best(self):
                return "r.m3u8", "#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXTINF:6.0,\nhttps://cdn.example/a.ts\n"

        orig = relay_server.fetch_page, relay_server.VttpChannel, relay_server.build_live_playlist
        relay_server.fetch_page = lambda url, ref: calls.append((url, ref)) or (429, html)
        relay_server.VttpChannel = FakeChannel
        relay_server.build_live_playlist = lambda *a: None     # segment release is tested elsewhere
        embed = "https://v2.streameast.ga/nfl/nfl-redzone-32/"
        try:
            q = urllib.parse.urlencode({"embed": embed, "ref": "https://v2.streameast.ga/"})
            status, ctype, body = self.get("/vttp.m3u8?" + q)
        finally:
            relay_server.fetch_page, relay_server.VttpChannel, relay_server.build_live_playlist = orig
            with relay_server._vttp_lock:
                relay_server._vttp.pop(embed, None)
        self.assertEqual(status, 200)
        self.assertIn(b"#EXTM3U", body)
        self.assertEqual(calls, [(embed, "https://v2.streameast.ga/")])

    def test_housekeeping_evicts_idle_streams_but_not_busy_ones(self):
        now = time.time()
        old = now - relay_server.EVICT_AFTER_S - 1
        with relay_server._streams_lock:
            relay_server._streams["idle"] = {"busy": False, "polled": old}
            relay_server._streams["busy"] = {"busy": True, "polled": old}
            relay_server._streams["fresh"] = {"busy": False, "polled": now}
        with relay_server._lives_lock:
            relay_server._lives["idle-live"] = {"polled": old}
        dropped = relay_server.housekeep(now)
        self.assertEqual(dropped, 2)
        self.assertEqual(sorted(relay_server._streams), ["busy", "fresh"])
        self.assertEqual(relay_server._lives, {})


class WarmTest(unittest.TestCase):
    def setUp(self):
        self.seen = []
        self.orig = relay_server.urllib.request.urlopen
        test = self

        class Resp:
            def __enter__(self): return self
            def __exit__(self, *a): return False
            def read(self): return b"#EXTM3U\n"

        def fake_urlopen(url, timeout=None):
            test.seen.append(url)
            return Resp()
        relay_server.urllib.request.urlopen = fake_urlopen
        with relay_server._warmed_lock:
            relay_server._warmed.clear()

    def tearDown(self):
        relay_server.urllib.request.urlopen = self.orig

    def test_warm_requests_the_stream_once_per_minute(self):
        path = "/vttp.m3u8?embed=https%3A%2F%2Fv2.streameast.ga%2Fnfl%2Fx%2F&ref=y"
        self.assertTrue(relay_server.warm(path, 8080))
        self.assertFalse(relay_server.warm(path, 8080))         # debounced
        for _ in range(50):
            if self.seen:
                break
            time.sleep(0.02)
        self.assertEqual(self.seen, ["http://127.0.0.1:8080" + path])

    def test_only_stream_paths_can_be_warmed(self):
        self.assertIsNone(relay_server.warm("/health", 8080))
        self.assertIsNone(relay_server.warm("http://evil.example/", 8080))
        self.assertIsNone(relay_server.warm("/../etc/passwd", 8080))


class ReleaseWindowTest(unittest.TestCase):
    """_release() against short upstream windows (u.steast.io lists only 3)."""

    def setUp(self):
        self.urls = []

    def segs(self, first, n):
        out = []
        for seq in range(first, first + n):
            url = f"https://cdn.example/seg_{seq}.txt"
            out.append((seq, "#EXTINF:5.0,", url, False))
            with relay_server._segs_lock:
                relay_server._segs.setdefault(url, {"event": relay_server.threading.Event(), "body": b"x",
                                                    "ctype": "video/mp2t", "error": None, "t0": time.time()})
            self.urls.append(url)
        return out

    def tearDown(self):
        with relay_server._segs_lock:
            for u in self.urls:
                relay_server._segs.pop(u, None)

    def run_polls(self, window):
        st = {"next": 100, "our_seq": 100, "released": [], "disc_seq": 0, "gap": False}
        released_seqs = []
        for first in range(100, 110):              # upstream advances one segment per poll
            relay_server._release(st, self.segs(first, window), time.time())
            released_seqs = [r[1] for r in st["released"]]
        return released_seqs

    def test_three_segment_window_keeps_releasing(self):
        seqs = self.run_polls(3)
        self.assertTrue(seqs, "nothing released")
        self.assertGreaterEqual(max(seqs), 109)     # keeps up with the live edge (last listed is 111)

    def test_evicted_segment_that_left_upstream_is_skipped_not_waited_on(self):
        st = {"next": 100, "our_seq": 100, "released": [], "disc_seq": 0, "gap": False}
        relay_server._release(st, self.segs(100, 3), time.time())          # remembers 100-102
        with relay_server._segs_lock:
            relay_server._segs.pop("https://cdn.example/seg_101.txt")       # evicted from the cache
        st["next"] = 101
        relay_server._release(st, self.segs(103, 3), time.time())          # 101 has left upstream
        self.assertGreater(st["next"], 102)
        self.assertIn(103, [r[1] for r in st["released"]])

    def test_long_window_still_holds_back(self):
        seqs = self.run_polls(10)
        self.assertEqual(max(seqs), 109 + 9 - relay_server.HOLD_BACK)


class TsSniffTest(unittest.TestCase):
    def test_ts_detected_by_sync_bytes(self):
        pkt = b"\x47" + bytes(187)
        self.assertTrue(relay_server.is_ts(pkt * 4))
        self.assertFalse(relay_server.is_ts(b"#EXTM3U\n" + bytes(400)))
        self.assertFalse(relay_server.is_ts(pkt + b"\x00" + bytes(187)))   # second packet has no sync
        self.assertFalse(relay_server.is_ts(b"\x47"))


class VttpStaleTest(unittest.TestCase):
    class Ch:
        def __init__(self, updated):
            self.updated, self.alive = updated, True

    def test_channel_that_stopped_painting_is_stale(self):
        now = 1000.0
        self.assertFalse(relay_server.vttp_stale(self.Ch(0.0), now))          # never painted: not judged here
        self.assertFalse(relay_server.vttp_stale(self.Ch(now - 10), now))
        self.assertTrue(relay_server.vttp_stale(self.Ch(now - relay_server.VTTP_STALE_S - 1), now))


class UnwrapReloadTest(unittest.TestCase):
    def setUp(self):
        self.orig = unwrap.RULES_PATH, unwrap.TIKTIK_MAGIC, unwrap._rules_mtime
        self.tmp = tempfile.NamedTemporaryFile("w", suffix=".json", delete=False)
        self.tmp.close()
        unwrap.RULES_PATH = self.tmp.name

    def tearDown(self):
        unwrap.RULES_PATH, unwrap.TIKTIK_MAGIC, unwrap._rules_mtime = self.orig
        os.unlink(self.tmp.name)

    def write(self, magic):
        with open(self.tmp.name, "w") as f:
            json.dump({"transport": {"png_magic": magic}}, f)
        os.utime(self.tmp.name, (time.time() + 5, time.time() + 5))   # guarantee a new mtime

    def test_reload_picks_up_a_changed_magic(self):
        self.write("NEWMAGIC")
        self.assertTrue(unwrap.reload())
        self.assertEqual(unwrap.TIKTIK_MAGIC, b"NEWMAGIC")
        self.assertFalse(unwrap.reload())            # unchanged file: nothing to do

    def test_broken_rules_fall_back_to_default(self):
        with open(self.tmp.name, "w") as f:
            f.write("{not json")
        os.utime(self.tmp.name, (time.time() + 5, time.time() + 5))
        unwrap.reload()
        self.assertEqual(unwrap.TIKTIK_MAGIC, b"TIKTIKPX")


if __name__ == "__main__":
    unittest.main()
