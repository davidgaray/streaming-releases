#!/system/bin/sh
# Relaunches VLC on whatever it was playing when playback dies on its own.
# Runs as root on the stick, started (and kept alive) by the Magisk boot
# supervisor (service.d/boot_start_watchdog.sh).
#
# Two ways VLC ends a stream that the viewer didn't ask for:
#   - native crash: "Fatal signal ... (org.videolan.vlc)" - e.g. the
#     SegmentList.cpp "duration" assertion in its HLS parser (2026-10-04)
#   - starvation abort: "buffer deadlock prevented" followed within seconds
#     by PlaylistManager "invalid next index, aborted" - VLC gives up the
#     session when segments stop arriving (2026-11-02, every 3-4 min on a bad
#     CDN night). A viewer pressing Back logs neither.
# The URI to relaunch is the last one VLC logged opening ("Expanding uri").
# Only relay URLs (127.0.0.1:8080) are relaunched; at most MAX_RELAUNCHES per
# WINDOW_S, after which it gives up so a dead stream can't loop forever.
# Each relaunch / give-up is appended to $EVENTS for the notifier.
#
#   sh vlc_keeper.sh            run (the supervisor does this)
#   touch /data/local/tmp/vlc_keeper.stop   stop

DIR=/data/local/tmp
LOG=$DIR/vlc_keeper.log
EVENTS=$DIR/supervisor.events
STOP=$DIR/vlc_keeper.stop
MAX_RELAUNCHES=3
WINDOW_S=600
DEADLOCK_TO_ABORT_S=5

log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; }

# Our own launches are stamped so the next "Expanding uri" isn't mistaken for
# the viewer pressing Play (it's a file: the start watcher runs in a subshell).
LAUNCHED=$DIR/keeper.launched
ATTEMPT=$DIR/keeper.attempt
launch() {
  date +%s > "$LAUNCHED"
  am start -a android.intent.action.VIEW -d "$1" -t application/vnd.apple.mpegurl \
    -n org.videolan.vlc/.StartActivity >/dev/null 2>&1
}
last_launch() { cat "$LAUNCHED" 2>/dev/null || echo 0; }

# --- Start watcher: an automatic second press -----------------------------
# A cold start can take the relay 20-40s, and VLC sometimes gives up first,
# or plays audio with the board still on screen. The viewer's fix was always
# "press Play again" - which works because the relay is warm by then. So for
# each press: if VLC isn't showing video AND receiving segments 25s later,
# launch the SAME address again, once. (Never VideoPlayerActivity without an
# address: VLC then replays its last media, a dead stream - 2026-11-08..15.)
CURL=/data/data/com.termux/files/usr/bin/curl
RETRY_AFTER_S=25
WATCH_FOR_S=45
video_in_front() { dumpsys activity activities 2>/dev/null | grep -m1 mResumedActivity | grep -q "org.videolan.vlc/.gui.video.VideoPlayerActivity"; }
relay_served_recently() {
  local age
  age=$($CURL -s -m 3 http://127.0.0.1:8080/health 2>/dev/null | sed -n 's/.*"last_served_age_s": \([0-9]*\).*/\1/p')
  [ -n "$age" ] && [ "$age" -le 8 ]
}
watch_start() {
  local u="$1" id="$2" t0 t
  t0=$(date +%s)
  while :; do
    sleep 3
    [ "$(cat "$ATTEMPT" 2>/dev/null)" = "$id" ] || return 0   # a newer press took over
    t=$(( $(date +%s) - t0 ))
    if video_in_front && relay_served_recently; then
      log "start OK after ${t}s"
      return 0
    fi
    [ $t -ge $WATCH_FOR_S ] && return 0
    [ $t -lt $RETRY_AFTER_S ] && continue
    if ! pidof org.videolan.vlc >/dev/null 2>&1; then why="VLC gave up"
    elif ! video_in_front; then why="no video on screen"
    else why="video screen up but no segments arriving"
    fi
    log "no picture ${t}s after Play ($why) - pressing Play again"
    echo "$(date +%s) vlc_retry" >> "$EVENTS"
    launch "$u"
    return 0
  done
}

uri="" deadlock_at=0 recent="" watch_uri="" watch_at=0
rm -f "$STOP"
# Keep the log small (the others are capped by watchdog.sh / the supervisor).
[ -f "$LOG" ] && [ "$(wc -c < "$LOG")" -gt 200000 ] && tail -c 50000 "$LOG" > "$LOG.k" && mv "$LOG.k" "$LOG"
log "watching"
# -T 1: only lines from now on, not the backlog. epoch timestamps are easy to compare.
logcat -v epoch -T 1 VLC:* VLC/PlaylistManager:* FileUtils:* libc:F DEBUG:F '*:S' 2>/dev/null |
while IFS= read -r line; do
  [ -f "$STOP" ] && { log "stopped"; exit 0; }
  set -- $line; now=${1%%.*}   # epoch seconds (logcat pads with spaces)
  case "$line" in
    *"Expanding uri: http://127.0.0.1:8080/"*)
      uri=${line#*Expanding uri: }; uri=${uri%% *}
      # Our own relaunch: no new watcher, so a press gets one retry at most.
      [ $((now - $(last_launch))) -le 15 ] && continue
      # VLC re-expands the same address while it retries internally; that's
      # still the same press, not a new one.
      [ "$uri" = "$watch_uri" ] && [ $((now - watch_at)) -lt $WATCH_FOR_S ] && continue
      # The viewer picked a game: fresh relaunch budget, and watch this start.
      recent=""
      watch_uri=$uri watch_at=$now
      echo "$now" > "$ATTEMPT"
      watch_start "$uri" "$now" &
      ;;
    *"buffer deadlock prevented"*)
      deadlock_at=$now ;;
    *"invalid next index, aborted"*|*"Fatal signal"*"org.videolan.vlc"*)
      case "$line" in
        *"invalid next index"*) [ $((now - deadlock_at)) -le $DEADLOCK_TO_ABORT_S ] || continue ;;
      esac
      [ -n "$uri" ] || continue
      kept=""; n=0
      for t in $recent; do [ $((now - t)) -lt $WINDOW_S ] && { kept="$kept $t"; n=$((n + 1)); }; done
      recent=$kept
      if [ $n -ge $MAX_RELAUNCHES ]; then
        log "playback died again; already relaunched $n times in ${WINDOW_S}s - giving up"
        echo "$now vlc_gave_up" >> "$EVENTS"
        uri=""
        continue
      fi
      recent="$recent $now"
      log "playback died ($( echo "$line" | grep -q 'Fatal signal' && echo crash || echo starvation )) - relaunching"
      echo "$now vlc_relaunched" >> "$EVENTS"
      sleep 2
      launch "$uri" ;;
  esac
done
