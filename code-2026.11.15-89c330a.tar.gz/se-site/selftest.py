#!/usr/bin/env python3
"""selftest.py - press Play on every board game, without a TV.

For each Play-in-VLC link on the board (data/play_links.json, written by
build.py) it does what VLC does: fetch the playlist through the relay, then
the first segment, and checks the segment is real video (MPEG-TS sync bytes
or fragmented MP4). Results, with how long each step took, go to
data/selftest.json; notify.py pages David when a game fails two runs in a
row. Run by watchdog.sh every 15 minutes.

Why: on 2026-11-15 every NFL game failed in the relay (the site moved the
player; the relay's fetch was blocked) and nothing noticed until a viewer
pressed Play. The crawl and resolve steps all succeeded - only an
end-to-end fetch through the relay shows that a link really plays.

It skips the run while someone is watching (the relay's /health shows a
stream delivering segments), so it never competes with a real viewer for
bandwidth. A probe also warms the relay for that game, which makes the
next real press start faster.

    selftest.py            run once, write data/selftest.json
    selftest.py --print    same, and print a line per game
"""
import json, os, sys, time, urllib.error, urllib.parse, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fsutil  # noqa: E402

DATA = os.path.join(HERE, "data")
RELAY = "http://127.0.0.1:8080"
MAX_GAMES = 6
PLAYLIST_TIMEOUT_S = 60      # the relay may wait ~20s for a socket + ~20s for first segments
SEGMENT_TIMEOUT_S = 45


def http_get(url, timeout):
    """(status, body bytes, seconds). Status 0 = no answer."""
    t0 = time.time()
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return r.status, r.read(), time.time() - t0
    except urllib.error.HTTPError as e:
        return e.code, e.read() or b"", time.time() - t0
    except Exception as e:
        return 0, str(e).encode(), time.time() - t0


def is_media(body):
    if len(body) >= 189 and body[0] == 0x47 and body[188] == 0x47:
        return "ts"
    if len(body) >= 8 and body[4:8] in (b"ftyp", b"moof", b"styp", b"sidx"):
        return "fmp4"
    return None


def first_segment(playlist_text):
    for line in playlist_text.splitlines():
        s = line.strip()
        if s and not s.startswith("#"):
            return s if s.startswith("http") else RELAY + s
    return None


def probe(link, get=http_get):
    """One game: {"slug", "title", "ok", "stage", "detail", "playlist_s", "segment_s"}."""
    out = {"slug": link["slug"], "title": link.get("title", link["slug"]), "ok": False}
    code, body, secs = get(link["url"], PLAYLIST_TIMEOUT_S)
    out["playlist_s"] = round(secs, 1)
    text = body.decode("utf-8", "replace")
    if code != 200 or "#EXTM3U" not in text[:200]:
        out.update(stage="playlist", detail=f"HTTP {code}: {text[:120].strip()}")
        return out
    seg = first_segment(text)
    if not seg:
        out.update(stage="playlist", detail="playlist has no segments yet")
        return out
    if seg.endswith(".m3u8") or "m3u8" in urllib.parse.urlsplit(seg).path:
        # A master playlist: follow the first variant once.
        code, body, s2 = get(seg, PLAYLIST_TIMEOUT_S)
        out["playlist_s"] = round(secs + s2, 1)
        seg = first_segment(body.decode("utf-8", "replace")) if code == 200 else None
        if not seg:
            out.update(stage="playlist", detail=f"variant playlist HTTP {code}")
            return out
    code, body, secs = get(seg, SEGMENT_TIMEOUT_S)
    out["segment_s"] = round(secs, 1)
    kind = is_media(body) if code == 200 else None
    if not kind:
        out.update(stage="segment", detail=f"HTTP {code}, {len(body)} bytes, starts {body[:8]!r}")
        return out
    out.update(ok=True, stage="ok", detail=f"{kind}, {len(body) // 1024} KB")
    return out


def someone_watching(get=http_get):
    code, body, _ = get(RELAY + "/health", 5)
    if code != 200:
        return False
    try:
        h = json.loads(body)
    except ValueError:
        return False
    age = h.get("last_segment_ok_age_s")
    return h.get("active_streams", 0) > 0 and age is not None and age <= 60


def run(get=http_get):
    try:
        with open(os.path.join(DATA, "play_links.json"), encoding="utf-8") as f:
            links = json.load(f)
    except (OSError, ValueError):
        links = []
    report = {"ts": int(time.time()), "skipped": None, "results": []}
    if someone_watching(get):
        report["skipped"] = "someone is watching"
    else:
        for link in links[:MAX_GAMES]:
            report["results"].append(probe(link, get))
    fsutil.write_json_atomic(os.path.join(DATA, "selftest.json"), report)
    return report


if __name__ == "__main__":
    rep = run()
    if "--print" in sys.argv:
        if rep["skipped"]:
            print(f"skipped: {rep['skipped']}")
        for r in rep["results"]:
            print(f"{'OK  ' if r['ok'] else 'FAIL'} {r.get('playlist_s', '-'):>5}s {r.get('segment_s', '-'):>5}s  "
                  f"{r['title']}  [{r['stage']}: {r['detail']}]")
