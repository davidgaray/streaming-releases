#!/usr/bin/env python3
"""
relay_server.py — serves dist/ exactly like `python3 -m http.server`, plus a
/relay?url=<encoded>&ref=<encoded>&match=<encoded> endpoint that fetches an
upstream URL with the Referer/User-Agent the edge CDN requires and streams
the response back.

`match` (the original match-page URL, optional) is what lets a failing
manifest fetch recover instead of just dying: a CDN edge node going bad
mid-playback is a real, observed failure mode (one node failed its TLS
handshake for 14+ minutes straight, 2026-10-01/02) that a same-URL retry
can't fix, since the node itself - not the request - is the problem. On a
manifest fetch that's still failing after the quick retry, `_relay()` calls
se-resolve fresh against `match` to get a different edge node + token, then
retries against that instead - the player never sees the failure as long as
this resolves within its own patience window (an increasingly likely
stall/rebuffer, not a hard error, the longer this needs to go on). Segments
aren't retried this way - see `_relay()`'s own comment for why.

`ref` is the per-game Referer se-resolve already computes (see build.py's
resolve_live_games) - the live player iframe host varies per game/mirror
(streame<suffix>.center, per crawl.py's own LIVE_IFRAME_RE), so this is not
hardcoded to a single guessed value. Falls back to REFERER below only for
manual/ad-hoc testing when a caller omits ref.

Why this exists: VLC's m3u #EXTVLCOPT:http-referrer / http-user-agent
directives are the documented way to pass headers for a network stream, but
on this device's VLC build they are not reliably applied when the playlist
is opened via an Android VIEW intent - confirmed 2026-09-29 by fetching the
same edgestreamN.pro URL directly: 200 + a real HLS manifest with the
Referer set, 403 + a 146-byte HTML error without it, and libvlc's own demux
log ("does not look like an MPEG PS stream", "garbage at input from 356")
is exactly what parsing that 146-byte error page as media would produce.
Injecting the header ourselves, server-side, sidesteps VLC's header handling
entirely - VLC only ever talks to 127.0.0.1 and needs no special options.

Segment/variant URIs inside a fetched .m3u8 are rewritten to also route
through /relay, so the whole chain (manifest + every .ts segment) carries
the header, not just the first request.

Two more optional params, both straight from se-resolve's --print output:
`org` is an Origin header some upstreams require instead of a Referer
(the edge-token chain refuses Referer-only requests outright), and `exp` is
the epoch second the manifest URL stops working (its token is short-lived,
~2 minutes). With `exp` set, the relay re-resolves in the background
before the token runs out and keeps serving the fresh URL to every later
poll - VLC keeps polling the original link and never notices the swap.

Segments pass through unwrap.py first: a segment recognised as a transport
wrapper (currently: TS hidden inside PNG pixels on an image CDN) is
unwrapped to plain TS; anything else passes through untouched.

Segments are prefetched, not fetched when the player asks. The image CDN
behind the edge-token chain is flaky on fresh segments - measured during a
live game 2026-11-02, about 1 in 3 new segments either hung (no response for
20s+) or 404'd for 12-30s after first appearing in the playlist, then usually
came good. Fetching on demand (15s timeout, twice, same URL) left VLC with
nothing for half a minute; its buffer drained and it abandoned the stream.
Now every segment starts downloading the moment the playlist lists it, with
short-timeout retries until it arrives, and the playlist VLC sees is built by
build_live_playlist(): it lists only segments already downloaded (so every
segment request VLC makes is answered instantly from the cache), and a
segment that still hasn't arrived SKIP_AFTER_S after it appeared is dropped
and marked #EXT-X-DISCONTINUITY. That last part matters: VLC also abandons
the session when a segment request fails or stalls - answering "skip it"
(504) after a wait killed it just the same - but it plays straight through
a discontinuity (a ~6s jump), which is how the site's own player handles
these holes too.
"""
import http.server, json, os, re, socketserver, subprocess, sys, threading, time, urllib.error, urllib.parse, urllib.request

import unwrap
from unwrap import PNG_MAGIC, unwrap_segment
from vttp import UA as VTTP_UA, VttpChannel, parse_embed

HERE = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(HERE, "dist")
RULES_PATH = os.path.join(HERE, "rules.json")
VERSION_PATH = os.path.join(HERE, "VERSION")   # written by the deploy/release step
STARTED = time.time()
DEFAULT_REFERER = "https://streame.center"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")

RESOLVER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "resolver", "se-resolve")
_TERMUX_BASH = "/data/data/com.termux/files/usr/bin/bash"
BASH = _TERMUX_BASH if os.path.exists(_TERMUX_BASH) else "bash"

ABS_URL_RE = re.compile(r"^https?://", re.I)

# Start a background re-resolve once a manifest's token has this little life
# left; a full resolve takes ~5-10s on the stick, so this leaves plenty of
# margin. Below BLOCKING_LEFT_S the poll waits for the fresh URL instead.
REFRESH_AHEAD_S = 60
BLOCKING_LEFT_S = 5
# Don't re-run a resolve that just failed on every 6s manifest poll.
RETRY_AFTER_FAILURE_S = 15

# match url -> {"url", "ref", "org", "exp", "busy", "event", "failed_at", "polled"}
_streams = {}
_streams_lock = threading.Lock()

# Observability for the watchdog, the deploy script and the updater (see
# GET /health): which streams are being polled right now, and when a segment
# last came through intact. A stream counts as active while its manifest was
# polled within ACTIVE_S - VLC polls every ~6s.
ACTIVE_S = 30
EVICT_AFTER_S = 600          # forget per-stream state nobody has polled for this long
_activity = {}               # stream key -> last manifest poll time
_activity_lock = threading.Lock()
_last_seg_ok = [0.0]


def _touch(key):
    with _activity_lock:
        _activity[key] = time.time()


def active_streams(now=None):
    now = time.time() if now is None else now
    with _activity_lock:
        return sum(1 for t in _activity.values() if now - t < ACTIVE_S)


def housekeep(now=None):
    """Evict per-stream state that hasn't been polled for EVICT_AFTER_S and
    pick up rules.json changes. Returns the number of entries dropped."""
    now = time.time() if now is None else now
    dropped = 0
    with _activity_lock:
        for k in [k for k, t in _activity.items() if now - t > EVICT_AFTER_S]:
            del _activity[k]
    with _streams_lock:
        for k in [k for k, st in _streams.items()
                  if not st.get("busy") and now - st.get("polled", now) > EVICT_AFTER_S]:
            del _streams[k]
            dropped += 1
    with _lives_lock:
        for k in [k for k, st in _lives.items() if now - st.get("polled", now) > EVICT_AFTER_S]:
            del _lives[k]
            dropped += 1
    with _vttp_lock:
        for k in [k for k, ch in _vttp.items() if not ch.alive]:
            del _vttp[k]
            dropped += 1
    if unwrap.reload():
        print(f"[relay] rules.json changed - PNG wrapper magic is now {unwrap.TIKTIK_MAGIC!r}", file=sys.stderr)
    return dropped


def _housekeeper():
    while True:
        time.sleep(30)
        try:
            n = housekeep()
            if n:
                print(f"[relay] housekeeping: dropped {n} idle stream entries", file=sys.stderr)
        except Exception as e:
            print(f"[relay] housekeeping failed: {e}", file=sys.stderr)


def _read(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return None


def health():
    rules_version = None
    try:
        rules_version = json.loads(_read(RULES_PATH) or "{}").get("version")
    except ValueError:
        pass
    now = time.time()
    return {"ok": True, "version": _read(VERSION_PATH) or "dev", "rules_version": rules_version,
            "active_streams": active_streams(now),
            "last_segment_ok_age_s": int(now - _last_seg_ok[0]) if _last_seg_ok[0] else None,
            "uptime_s": int(now - STARTED), "pid": os.getpid()}

# Segment prefetch + release - see the module docstring and build_live_playlist().
# VLC only ever sees segments that are already downloaded: a segment is
# released into VLC's playlist once it's ready AND at least HOLD_BACK newer
# ones exist upstream. One still not ready SKIP_AFTER_S after it first showed
# up is dropped (marked as a discontinuity) so the stream moves on - VLC
# aborts the whole session on a failed or stalled segment request, but plays
# straight through a discontinuity. The site's own player does the same
# ("hole_skip_ms") on this CDN.
HOLD_BACK = 3
SKIP_AFTER_S = 24
LIVE_WINDOW = 6
STARTUP_WAIT_S = 20
SEG_ATTEMPT_TIMEOUT_S = 8
SEG_RETRY_PAUSE_S = 2
SEG_GIVE_UP_S = 60
SEG_WAIT_S = 8
SEG_CACHE_MAX = 16
SEG_PARALLEL = 3
SEG_PERMANENT = (401, 403, 410)  # bad signature etc. - retrying won't help

# upstream segment url -> {"event", "body", "ctype", "error", "t0"}
_segs = {}
_segs_lock = threading.Lock()
_seg_slots = threading.BoundedSemaphore(SEG_PARALLEL)


def _short(url):
    p = urllib.parse.urlsplit(url)
    return p.netloc.split(".")[0] + "/…" + p.path[-12:]


def _seg_job(url, referer, origin, entry):
    headers = {"Referer": referer, "User-Agent": UA}
    if origin:
        headers["Origin"] = origin
    attempt = 0
    while True:
        attempt += 1
        try:
            with _seg_slots:
                with urllib.request.urlopen(urllib.request.Request(url, headers=headers),
                                            timeout=SEG_ATTEMPT_TIMEOUT_S) as r:
                    body = r.read()
                    ctype = r.headers.get("Content-Type", "application/octet-stream")
            if body.startswith(PNG_MAGIC):
                media = unwrap_segment(body)
                if media is not None:
                    body, ctype = media, "video/mp2t"
            entry.update(body=body, ctype=ctype, error=None)
            _last_seg_ok[0] = time.time()
            if attempt > 1:
                print(f"[relay] segment ok on try {attempt}, {time.time() - entry['t0']:.0f}s "
                      f"after it appeared: {_short(url)}", file=sys.stderr)
            break
        except Exception as e:
            entry["error"] = e
            permanent = isinstance(e, urllib.error.HTTPError) and e.code in SEG_PERMANENT
            if permanent or time.time() + SEG_RETRY_PAUSE_S >= entry["t0"] + SEG_GIVE_UP_S:
                print(f"[relay] segment failed after {attempt} tries: {_short(url)} ({e})",
                      file=sys.stderr)
                break
            time.sleep(SEG_RETRY_PAUSE_S)
    entry["event"].set()


def prefetch(url, referer, origin):
    """Start fetching a segment unless it's already cached or in flight;
    returns its cache entry either way."""
    with _segs_lock:
        entry = _segs.get(url)
        if entry is not None:
            return entry
        entry = _segs[url] = {"event": threading.Event(), "body": None, "ctype": None,
                              "error": None, "t0": time.time()}
        done = sorted((e["t0"], u) for u, e in _segs.items() if e["event"].is_set())
        while len(_segs) > SEG_CACHE_MAX and done:
            del _segs[done.pop(0)[1]]
    threading.Thread(target=_seg_job, args=(url, referer, origin, entry), daemon=True).start()
    return entry


# upstream playlist (host + path, stable across token refreshes) ->
# {"next": next upstream seq to decide on, "our_seq": next seq number to give VLC,
#  "released": [(our_seq, upstream seq, extinf, url, discontinuity)], "disc_seq": int,
#  "gap": True if the last decided segment was dropped}
_lives = {}
_lives_lock = threading.Lock()

# vttp embed url -> VttpChannel (see vttp.py)
_vttp = {}
_vttp_lock = threading.Lock()
VTTP_STALE_S = 90       # live playlists repaint every few seconds; this long without one is a dead socket


def vttp_stale(ch, now=None):
    """A channel that once delivered playlists but has stopped (its socket is
    nominally alive). A channel that never delivered yet is judged by the
    ready-wait timeout instead."""
    now = time.time() if now is None else now
    return bool(ch.updated) and now - ch.updated > VTTP_STALE_S


def _parse_media_playlist(text, base_url):
    """(header tag lines, first upstream seq, [(seq, extinf, abs url, discontinuity)])"""
    header, segs, pending, first, seq = [], [], [], 0, None
    for line in text.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("#EXT-X-MEDIA-SEQUENCE:"):
            first = int(s.split(":", 1)[1])
        elif s.startswith("#"):
            if s.startswith(("#EXTINF", "#EXT-X-DISCONTINUITY", "#EXT-X-PROGRAM-DATE-TIME")):
                pending.append(s)
            elif not segs and not pending and s.startswith(("#EXT-X-TARGETDURATION", "#EXT-X-VERSION")):
                header.append(s)
        else:
            seq = first + len(segs)
            extinf = next((p for p in pending if p.startswith("#EXTINF")), "#EXTINF:6.0,")
            disc = any(p.startswith("#EXT-X-DISCONTINUITY") and not p.startswith("#EXT-X-DISCONTINUITY-SEQUENCE")
                       for p in pending)
            url = s if ABS_URL_RE.match(s) else urllib.parse.urljoin(base_url, s)
            segs.append((seq, extinf, url, disc))
            pending = []
    return header, first, segs


def _release(st, segs, now):
    """Advance one stream's release point as far as it can go right now."""
    # Remembered across polls: a segment can slide out of the upstream window
    # before its turn here (a late poll) and still be sitting ready in the cache.
    known = st.setdefault("known", {})
    for seq, extinf, url, disc in segs:
        known[seq] = (extinf, url, disc)
    for seq in [s for s in known if s < st["next"] - LIVE_WINDOW]:
        del known[seq]
    by_seq = known
    first, last = segs[0][0], segs[-1][0]
    # Entries older than this are stale (e.g. VLC came back to a stream
    # after a long idle) - normally the LIVE_WINDOW trim below has the same effect.
    while st["released"] and st["released"][0][1] < first - HOLD_BACK:
        if st["released"].pop(0)[4]:
            st["disc_seq"] += 1
    while st["next"] <= last - HOLD_BACK:
        seq = st["next"]
        if seq not in by_seq:            # slid out of the upstream window undecided
            st["next"] += 1
            st["gap"] = True
            continue
        extinf, url, disc = by_seq[seq]
        with _segs_lock:
            entry = _segs.get(url)
        if entry is None:
            break
        if entry["body"] is not None:
            st["released"].append((st["our_seq"], seq, extinf, url, disc or st["gap"]))
            st["our_seq"] += 1
            st["gap"] = False
        elif entry["event"].is_set() or now - entry["t0"] > SKIP_AFTER_S:
            print(f"[relay] dropping segment {seq} ({'failed' if entry['event'].is_set() else 'still not there'} "
                  f"{now - entry['t0']:.0f}s after it appeared): {_short(url)}", file=sys.stderr)
            st["gap"] = True
        else:
            break
        st["next"] += 1
    while len(st["released"]) > LIVE_WINDOW:
        if st["released"].pop(0)[4]:
            st["disc_seq"] += 1


def build_live_playlist(key, text, base_url, referer, origin):
    """VLC's copy of a live media playlist: only segments already downloaded,
    renumbered so dropped ones leave no hole in the sequence, with a
    discontinuity wherever one was dropped."""
    header, first, segs = _parse_media_playlist(text, base_url)
    if not segs:
        return None
    for _, _, url, _ in segs:
        prefetch(url, referer, origin)
    deadline = time.time() + STARTUP_WAIT_S
    while True:
        with _lives_lock:
            st = _lives.get(key)
            if st is None or segs[-1][0] < st["next"] - 50:   # new stream, or upstream restarted
                st = _lives[key] = {"next": first, "our_seq": first, "released": [],
                                    "disc_seq": 0, "gap": False}
            st["polled"] = time.time()
            _release(st, segs, time.time())
            released = list(st["released"])
            disc_seq = st["disc_seq"]
        # First request for a stream: everything was only just queued for
        # download - give it a moment rather than hand VLC an empty playlist.
        if released or time.time() >= deadline:
            break
        time.sleep(0.5)
    out = ["#EXTM3U"] + header
    out.append(f"#EXT-X-MEDIA-SEQUENCE:{released[0][0] if released else st['our_seq']}")
    if disc_seq:
        out.append(f"#EXT-X-DISCONTINUITY-SEQUENCE:{disc_seq}")
    for _, _, extinf, url, disc in released:
        if disc:
            out.append("#EXT-X-DISCONTINUITY")
        out.append(extinf)
        line = "/relay?url=" + urllib.parse.quote(url, safe="") + "&ref=" + urllib.parse.quote(referer, safe="")
        if origin:
            line += "&org=" + urllib.parse.quote(origin, safe="")
        out.append(line)
    return ("\n".join(out) + "\n").encode("utf-8")


def _is_manifest_url(url):
    return urllib.parse.urlsplit(url).path.lower().endswith(".m3u8")


def _bust(url):
    """Fresh value for an existing `_=` cache-buster param, so an upstream
    cache can't hand back a stale live playlist. URLs without one are left
    alone - adding params to a signed URL can invalidate it."""
    parts = urllib.parse.urlsplit(url)
    if not parts.query:
        return url
    params = parts.query.split("&")
    changed = False
    for i, p in enumerate(params):
        if p.startswith("_="):
            params[i] = "_=%d" % int(time.time() * 1000)
            changed = True
    return urllib.parse.urlunsplit(parts._replace(query="&".join(params))) if changed else url


def re_resolve(match_url):
    """Fresh se-resolve call for the original match page - a new edge node +
    token, independent of whatever (possibly now-dead) one the player was
    handed originally. Returns {"url", "ref", "org", "exp"} or None.

    Duplicates build.py's resolve_stream() rather than importing it -
    relay_server.py is meant to run standalone. Explicit bash, not
    se-resolve's own `#!/usr/bin/env bash` shebang, for the same reason as
    build.py's own copy of this call: subprocess.run() execs directly with no
    shebang-fixup hook behind it (see docs/TROUBLESHOOTING.md in
    firestick-build for the full story - a different call site, same root
    cause as the RUN_COMMAND version of this issue)."""
    try:
        result = subprocess.run(
            [BASH, RESOLVER, match_url, "--print"],
            capture_output=True, text=True, timeout=30,
        )
    except Exception as e:
        print(f"[relay] re-resolve failed for {match_url}: {e}", file=sys.stderr)
        return None
    if result.returncode != 0:
        print(f"[relay] re-resolve exited {result.returncode} for {match_url} "
              f"(game likely ended)", file=sys.stderr)
        return None
    fields = dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)
    if not fields.get("M3U8") or not fields.get("REFERER"):
        return None
    exp = fields.get("EXPIRES")
    return {"url": fields["M3U8"], "ref": fields["REFERER"], "org": fields.get("ORIGIN") or None,
            "exp": float(exp) if exp and exp.isdigit() else None}


def _do_refresh(match_url, st, ev):
    try:
        print(f"[relay] re-resolving {match_url}…", file=sys.stderr)
        fresh = re_resolve(match_url)
        with _streams_lock:
            if fresh:
                st.update(fresh)
                st["failed_at"] = 0
            else:
                st["failed_at"] = time.time()
        if fresh:
            print(f"[relay] re-resolved -> {fresh['url']}", file=sys.stderr)
    finally:
        with _streams_lock:
            st["busy"] = False
        ev.set()


def refresh_stream(match_url, blocking):
    """Re-resolve one stream - at most one resolve in flight per stream;
    a blocking caller that finds one already running waits for it."""
    with _streams_lock:
        st = _streams[match_url]
        if st["busy"]:
            ev, run = st["event"], False
        elif time.time() - st["failed_at"] < RETRY_AFTER_FAILURE_S:
            return
        else:
            st["busy"] = True
            ev = st["event"] = threading.Event()
            run = True
    if run and not blocking:
        threading.Thread(target=_do_refresh, args=(match_url, st, ev), daemon=True).start()
    elif run:
        _do_refresh(match_url, st, ev)
    elif blocking:
        ev.wait(40)


def current_upstream(match_url, url, ref, org, exp):
    """The freshest known manifest URL for this stream. Seeds the cache from
    the request (a newer board link beats an older cached one), then kicks
    off a re-resolve if the token is close to expiring."""
    with _streams_lock:
        st = _streams.get(match_url)
        if st is None:
            st = _streams[match_url] = {"url": url, "ref": ref, "org": org, "exp": exp,
                                        "busy": False, "event": None, "failed_at": 0}
        elif exp and (st["exp"] or 0) < exp:
            st.update(url=url, ref=ref, org=org, exp=exp)
        st["polled"] = time.time()
        left = st["exp"] - time.time() if st["exp"] else None
    if left is not None and left <= BLOCKING_LEFT_S:
        refresh_stream(match_url, blocking=True)
    elif left is not None and left <= REFRESH_AHEAD_S:
        refresh_stream(match_url, blocking=False)
    with _streams_lock:
        return st["url"], st["ref"], st["org"]


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=DIST, **kw)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/relay":
            return self._relay(parsed)
        if parsed.path == "/vttp.m3u8":
            return self._vttp(parsed)
        if parsed.path == "/health":
            return self._send_body(200, "application/json", json.dumps(health()).encode("utf-8"))
        return super().do_GET()

    def _vttp(self, parsed):
        """Live HLS playlist for a vttp embed page (see vttp.py): keeps one
        WebSocket per embed open while someone's polling, then runs its
        playlist through build_live_playlist() like any other live stream."""
        qs = urllib.parse.parse_qs(parsed.query)
        embed = (qs.get("embed") or [None])[0]
        referer = (qs.get("ref") or [DEFAULT_REFERER])[0]
        if not embed:
            return self._safe_send_error(400, "missing embed param")
        _touch("vttp:" + embed)
        with _vttp_lock:
            ch = _vttp.get(embed)
            if ch is not None and vttp_stale(ch):
                # The socket is up but hasn't painted a new playlist in ages:
                # every poll then waits the full startup timeout and VLC gives
                # up (2026-11-08, after a relay restart mid-game). Rebuild it.
                print(f"[relay] vttp channel for {_short(embed)} stale for "
                      f"{int(time.time() - ch.updated)}s - reconnecting", file=sys.stderr)
                ch.alive = False
                ch = None
                with _lives_lock:
                    _lives.pop("vttp:" + embed, None)
            if ch is None or not ch.alive:
                ch = None
        if ch is None:
            try:
                req = urllib.request.Request(embed, headers={"User-Agent": VTTP_UA, "Referer": "https://v2.streameast.ga/"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    info = parse_embed(r.read().decode("utf-8", "replace"))
            except Exception as e:
                return self._safe_send_error(502, f"embed page: {e}")
            if not info:
                return self._safe_send_error(502, "embed page has no vttp player")
            origin = "/".join(embed.split("/")[:3])
            with _vttp_lock:
                ch = _vttp[embed] = VttpChannel(*info, origin)
        if not ch.ready.wait(20):
            return self._safe_send_error(504, "no playlist from the vttp socket yet")
        _, text = ch.best()
        if not text:
            return self._safe_send_error(502, "vttp socket has no playable rendition")
        body = build_live_playlist("vttp:" + embed, text, embed, referer, None)
        self._send_body(200, "application/vnd.apple.mpegurl", body or text.encode())

    def _safe_send_error(self, code, message):
        # send_error() itself writes to self.wfile - if the client (VLC) has
        # already given up and closed its side (exactly what it does right
        # after the upstream fetch below times out), that write raises its
        # own BrokenPipeError/ConnectionResetError, which propagated
        # unhandled, confirmed live 2026-10-01: a real upstream failure was
        # buried under an unrelated-looking crash traceback in relay.log,
        # noise that made the actual cause (CDN edge-node TLS timeout) harder
        # to spot. Doesn't change behavior - the client's gone either way,
        # there was never anything useful left to send it.
        try:
            self.send_error(code, message)
        except (BrokenPipeError, ConnectionResetError):
            pass

    @staticmethod
    def _fetch(target, referer, origin=None, retries=2, retry_delay=1.0):
        """Returns (response, error) - error is the last exception (HTTPError
        included) when every attempt failed, response is None in that case.
        Doesn't special-case HTTPError out of the retry loop here (unlike the
        first version of this code) - a 403 is exactly what an expired token
        or missing Referer looks like (see resolver/README.md), and that's
        precisely what a caller's re-resolve fallback can fix. Retrying the
        *same* URL/token on a 403 would still be pointless, which is why this
        only retries - it doesn't re-resolve itself; see _relay() for that."""
        headers = {"Referer": referer, "User-Agent": UA}
        if origin:
            headers["Origin"] = origin
        req = urllib.request.Request(target, headers=headers)
        last_err = None
        for attempt in range(retries):
            try:
                return urllib.request.urlopen(req, timeout=15), None
            except Exception as e:
                last_err = e
                if attempt < retries - 1:
                    time.sleep(retry_delay)
        return None, last_err

    def _relay(self, parsed):
        qs = urllib.parse.parse_qs(parsed.query)
        target = (qs.get("url") or [None])[0]
        referer = (qs.get("ref") or [DEFAULT_REFERER])[0]
        origin = (qs.get("org") or [None])[0]
        match_url = (qs.get("match") or [None])[0]
        exp = (qs.get("exp") or [None])[0]
        exp = float(exp) if exp and exp.isdigit() else None
        if not target:
            self._safe_send_error(400, "missing url param")
            return
        # Manifests only, not segments - see module docstring additions
        # below for why. Confirmed live 2026-10-01: a single TLS handshake
        # timeout talking to one edge node (edgestream5.pro) killed an
        # otherwise-fine live playback session outright, and it stayed dead
        # for 14+ minutes straight - long enough that a quick same-URL retry
        # was never going to help, but a *fresh* resolve immediately got
        # handed a different, healthy edge node. The manifest is what VLC
        # polls repeatedly and can't proceed without, so it's the one place
        # worth paying for a full re-resolve (a few real seconds) rather than
        # just failing - a single missed segment is a much cheaper, more
        # tolerable loss and heals on its own at the next manifest poll once
        # that poll is pointed at a working host again.
        # Path, not the whole URL: manifest URLs carry query strings (tokens,
        # cache-busters), so target.endswith(".m3u8") never matched them and
        # the re-resolve below silently never ran.
        is_manifest = _is_manifest_url(target)
        if not is_manifest:
            return self._serve_segment(target, referer, origin)
        parts = urllib.parse.urlsplit(target)
        _touch(match_url or parts.netloc + parts.path)
        if match_url:
            target, referer, origin = current_upstream(match_url, target, referer, origin, exp)
        r, err = self._fetch(_bust(target) if is_manifest else target, referer, origin)
        if r is None and is_manifest and match_url:
            print(f"[relay] {target} still failing ({err}) - "
                  f"re-resolving {match_url}…", file=sys.stderr)
            refresh_stream(match_url, blocking=True)
            with _streams_lock:
                st = _streams[match_url]
                fresh = (st["url"], st["ref"], st["org"])
            if fresh[0] != target:
                target, referer, origin = fresh
                r, err = self._fetch(_bust(target), referer, origin)
            else:
                print(f"[relay] re-resolve gave no new stream for {match_url}",
                      file=sys.stderr)
        if r is None:
            code = err.code if isinstance(err, urllib.error.HTTPError) else 502
            self._safe_send_error(code, str(err))
            return
        with r:
            raw = r.read()
        text = raw.decode("utf-8", "replace")
        body = None
        if "#EXTINF" in text and "#EXT-X-STREAM-INF" not in text and "#EXT-X-ENDLIST" not in text:
            parts = urllib.parse.urlsplit(target)
            body = build_live_playlist(parts.netloc + parts.path, text, target, referer, origin)
        if body is None:
            body = self._rewrite_manifest(raw, target, referer, origin)
        self._send_body(200, "application/vnd.apple.mpegurl", body)

    def _serve_segment(self, target, referer, origin):
        # Normally already prefetched (or in flight) from the playlist poll
        # that listed it; a cold request just goes through the same
        # fetch-with-retries machinery. Segments used to be streamed through
        # unbuffered because fetching on demand and buffering added a fetch's
        # worth of latency to every segment (2026-09-29: VLC's clock drifted
        # and never recovered) - with prefetch the fetch happens before VLC
        # asks, so a buffered, already-unwrapped copy is the fast path now.
        entry = prefetch(target, referer, origin)
        if not entry["event"].wait(SEG_WAIT_S):
            print(f"[relay] segment still loading after {SEG_WAIT_S}s, telling the player "
                  f"to skip it: {_short(target)}", file=sys.stderr)
            self._safe_send_error(504, "segment still loading")
            return
        if entry["body"] is None:
            err = entry["error"]
            self._safe_send_error(err.code if isinstance(err, urllib.error.HTTPError) else 502, str(err))
            return
        body, ctype = entry["body"], entry["ctype"]
        if "mpegurl" in (ctype or "").lower():
            # A nested playlist on a non-.m3u8 path - rewrite it, and don't
            # keep it: playlists change on every poll.
            with _segs_lock:
                _segs.pop(target, None)
            body, ctype = self._rewrite_manifest(body, target, referer, origin), "application/vnd.apple.mpegurl"
        self._send_body(200, ctype, body)

    def _send_body(self, code, ctype, body):
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    @staticmethod
    def _rewrite_manifest(body, base_url, referer, origin=None):
        """Any non-comment line in an HLS manifest is a URI (segment or
        nested variant playlist), possibly relative to the manifest's own
        URL - resolve it, then route it back through /relay (carrying the
        same referer/origin) so it also gets the headers when the player
        fetches it next. Live media playlists go through
        build_live_playlist() instead; this handles everything else."""
        out = []
        for line in body.decode("utf-8", "replace").splitlines():
            s = line.strip()
            if s and not s.startswith("#"):
                url = s if ABS_URL_RE.match(s) else urllib.parse.urljoin(base_url, s)
                line = "/relay?url=" + urllib.parse.quote(url, safe="") + "&ref=" + urllib.parse.quote(referer, safe="")
                if origin:
                    line += "&org=" + urllib.parse.quote(origin, safe="")
            out.append(line)
        return ("\n".join(out) + "\n").encode("utf-8")

    def log_message(self, fmt, *args):
        sys.stderr.write(f"[relay] {self.address_string()} {fmt % args}\n")


class Server(socketserver.ThreadingMixIn, socketserver.TCPServer):
    # VLC can poll the live manifest and fetch the next segment at close to
    # the same moment - a plain TCPServer handles one request at a time and
    # would queue the second behind the first, adding to the same live-edge
    # latency problem the chunked segment streaming above fixes. daemon_threads
    # so a slow/hung client request can't block process shutdown.
    daemon_threads = True
    allow_reuse_address = True


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    threading.Thread(target=_housekeeper, daemon=True).start()
    with Server(("127.0.0.1", port), Handler) as httpd:
        print(f"[relay] serving {DIST} + /relay + /health on 127.0.0.1:{port} "
              f"(version {health()['version']}, rules {health()['rules_version']})", file=sys.stderr)
        httpd.serve_forever()
