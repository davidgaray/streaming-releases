#!/system/bin/sh
# Magisk late_start service script (runs as root, once per boot). Starts
# se-site's watchdog.sh and then keeps it alive for the rest of the boot.
#
# watchdog.sh restarts the board's crawler and relay when they die, but it
# runs inside Termux - when Android kills the whole Termux app the watchdog
# goes down with everything it supervises and nothing brings any of it back
# (confirmed 2026-11-08: Termux killed ~10 min after boot, board dead until a
# manual restart 40 min later). This script runs outside Termux, as root, so
# it survives that and relaunches the watchdog through Termux's RUN_COMMAND
# service. Bash is invoked explicitly rather than via watchdog.sh's own
# shebang - see TROUBLESHOOTING.md "RUN_COMMAND silently does nothing".
#
# Each relaunch is appended to $EVENTS so the stick's notifier can report it.
#
# Install: 80_deploy_se_site.sh copies this to /data/adb/service.d/ (root:root,
# 700). Verify after a real reboot: watchdog.log's first line is near boot
# time; `am force-stop com.termux` -> watchdog back within ~2 min.

ROOT=/data/data/com.termux/files/home/streaming
# Releases live under releases/<v> with `current` pointing at the live one
# (see se-site/updater.py); the flat se-site/ is the pre-update-channel layout.
BASE=$ROOT/current/se-site
[ -d "$BASE" ] || BASE=$ROOT/se-site
STATE=$ROOT/state
LOG=/data/local/tmp/supervisor.log
EVENTS=/data/local/tmp/supervisor.events
CHECK_S=60

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }

start_watchdog() {
  am startservice --user 0 -n com.termux/com.termux.app.RunCommandService \
    -a com.termux.RUN_COMMAND \
    --es com.termux.RUN_COMMAND_PATH /data/data/com.termux/files/usr/bin/bash \
    --esa com.termux.RUN_COMMAND_ARGUMENTS "$BASE/watchdog.sh,180,8080,60" \
    --ez com.termux.RUN_COMMAND_BACKGROUND true >/dev/null 2>&1
}

watchdog_running() { pgrep -f "se-site/watchdog.sh" >/dev/null 2>&1; }

# Relaunches VLC when playback dies on its own (see vlc_keeper.sh).
KEEPER=/data/local/tmp/vlc_keeper.sh
keeper_running() { pgrep -f "sh $KEEPER" >/dev/null 2>&1; }
start_keeper() { [ -f "$KEEPER" ] && setsid sh "$KEEPER" </dev/null >/dev/null 2>&1 & }

# The stick has 1.7GB of RAM and lives in swap; Android's low-memory killer
# takes processes in oom_score_adj order, and Termux plus everything it runs
# sit at 200 (a background service) while VLC sits at 0 (foreground). That's
# why the board kept dying under load (measured 2026-11-08). Root can pin them
# below every app so lmkd never picks them: -900 is what Android gives its own
# persistent services. Children forked later inherit Termux's value, so this
# runs every minute and catches them within a cycle.
OOM_ADJ=-900
PINNED=" "
pin_oom() {
  local p adj newly=0
  for p in $(pidof com.termux 2>/dev/null) \
           $(pgrep -f 'streaming/(current|releases|se-site)|relay_server\.py|refresh-loop\.sh|crawl\.py|build\.py|resolve\.py|updater\.py' 2>/dev/null); do
    adj=$(cat "/proc/$p/oom_score_adj" 2>/dev/null) || continue
    [ "$adj" = "$OOM_ADJ" ] && continue
    echo "$OOM_ADJ" > "/proc/$p/oom_score_adj" 2>/dev/null || continue
    case "$PINNED" in *" $p "*) ;; *) PINNED="$PINNED$p "; newly=$((newly + 1)) ;; esac
  done
  [ "$newly" -gt 0 ] && log "pinned oom_score_adj=$OOM_ADJ on $newly new board process(es)"
  # Keep the seen-list from growing forever: pids are reused, so just reset it.
  [ ${#PINNED} -gt 4000 ] && PINNED=" "
}

# If Termux itself is gone (uninstalled, data wiped, app disabled) nothing
# above can run - notify.py and its python live inside Termux. Magisk's own
# busybox can still reach ntfy (https works; no cert check, which is fine for
# a one-line alarm). The topic is mirrored out of Termux while it exists.
BB=/data/adb/magisk/busybox
CONF_MIRROR=/data/local/tmp/notify.conf
raw_alert() {
  local topic name
  topic=$(sed -n 's/^TOPIC=//p' "$CONF_MIRROR" 2>/dev/null | head -1)
  name=$(sed -n 's/^NAME=//p' "$CONF_MIRROR" 2>/dev/null | head -1)
  [ -n "$topic" ] || return 1
  $BB wget -q -O /dev/null --timeout=15 --header "Title: ${name:-Stick}: $1" --header "Priority: high" \
    --header "Tags: rotating_light" --post-data "$2" "https://ntfy.sh/$topic" 2>/dev/null
}

wait_for_network() {
  # Fixed sleeps don't survive a slow Wi-Fi reconnect after a power cut.
  local i=0
  while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ] && [ $i -lt 60 ]; do sleep 2; i=$((i + 1)); done
  i=0
  while ! $BB nslookup ntfy.sh >/dev/null 2>&1 && [ $i -lt 90 ]; do sleep 2; i=$((i + 1)); done
  sleep 10   # Termux needs the app framework settled before it accepts RUN_COMMAND
}

# Root-side scripts update over the signed channel too: each release carries
# device/boot_start_watchdog.sh and device/vlc_keeper.sh (tools/release.py),
# and when the current release's copy differs from the installed one it is
# syntax-checked, installed, and the process restarted. Without this a fix to
# either needed adb - impossible on a stick at someone else's house.
SELF=/data/adb/service.d/boot_start_watchdog.sh
self_update() {
  local new="$ROOT/current/device/vlc_keeper.sh" p
  if [ -f "$new" ] && ! cmp -s "$new" "$KEEPER"; then
    if sh -n "$new" 2>/dev/null; then
      cp "$new" "$KEEPER.new" && chmod 755 "$KEEPER.new" && mv -f "$KEEPER.new" "$KEEPER"
      log "vlc_keeper.sh updated from the current release - restarting it"
      for p in $(pgrep -f "sh $KEEPER" 2>/dev/null); do kill -9 "$p" 2>/dev/null; done
    else
      log "current release's vlc_keeper.sh fails sh -n - keeping the installed one"
    fi
  fi
  new="$ROOT/current/device/boot_start_watchdog.sh"
  if [ -f "$new" ] && ! cmp -s "$new" "$SELF"; then
    if sh -n "$new" 2>/dev/null; then
      cp -f "$SELF" "$SELF.prev"
      cp "$new" "$SELF.new" && chown root:root "$SELF.new" && chmod 700 "$SELF.new" && mv -f "$SELF.new" "$SELF"
      if cmp -s "$new" "$SELF"; then
        log "supervisor updated from the current release - re-executing (previous kept as .prev)"
        SUPERVISOR_RESTART=1 exec sh "$SELF"
      fi
      log "supervisor update didn't install cleanly - carrying on with the running copy"
    else
      log "current release's boot_start_watchdog.sh fails sh -n - keeping the installed one"
    fi
  fi
}

supervise() {
  if [ "${SUPERVISOR_RESTART:-0}" = "1" ]; then
    log "supervisor restarted after a self-update"
  else
    wait_for_network
    log "boot: network up, starting watchdog"
    start_watchdog
  fi
  missing=0
  while true; do
    sleep "$CHECK_S"
    pin_oom
    self_update
    [ -f "$BASE/notify.conf" ] && cp "$BASE/notify.conf" "$CONF_MIRROR" 2>/dev/null
    # Phone alerts for anything not fixed above (notify.py dedupes itself).
    PATH=/data/data/com.termux/files/usr/bin:$PATH python3 "$BASE/notify.py" >> "$LOG" 2>&1
    if ! keeper_running && [ ! -f /data/local/tmp/vlc_keeper.stop ]; then
      log "starting vlc_keeper"
      start_keeper
    fi
    if watchdog_running; then
      missing=0
    else
      missing=$((missing + 1))
      if [ $missing -eq 5 ]; then
        log "watchdog has not come back after 5 relaunch attempts - Termux broken or missing?"
        raw_alert "board is down and can't restart" \
          "The board's services won't start after 5 attempts. Termux may be missing or broken on this stick - it needs a look (adb or reinstall)." \
          && log "raw alert sent" || log "raw alert failed (no topic or no network)"
      fi
      log "watchdog not running (Termux killed?) - relaunching"
      # A deploy/update stops the watchdog on purpose; it leaves a marker
      # so the relaunch isn't reported as Android killing the board.
      marker=""
      for m in "$STATE/deploying" /data/local/tmp/deploying; do
        [ -f "$m" ] && [ $(( $(date +%s) - $(stat -c %Y "$m") )) -lt 900 ] && marker=$m
      done
      if [ -n "$marker" ]; then
        log "(deploy/update in progress - not counting it as a crash)"
      else
        echo "$(date +%s) watchdog_relaunched" >> "$EVENTS"
      fi
      start_watchdog
      # Give Termux time to come back before judging it again.
      sleep 60
    fi
    # Keep these small: one line per event at most once a minute anyway.
    # (The keeper only trims its own log when it starts, so it's capped here too.)
    for f in "$LOG" "$EVENTS" /data/local/tmp/vlc_keeper.log; do
      [ -f "$f" ] && [ "$(wc -c < "$f")" -gt 200000 ] && tail -c 50000 "$f" > "$f.k" && mv "$f.k" "$f"
    done
  done
}

supervise &
